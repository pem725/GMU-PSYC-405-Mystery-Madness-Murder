# PSYC 405 Section 002 - Quiz 5: Fight Club
## CONFIDENTIAL ANSWER KEY

---

## Quiz 5: Fight Club (1999)

---

### Question 1

**Question:** The Narrator creates Tyler Durden as an idealized alter ego embodying everything he wishes he could be. According to Gross (2015), what emotion regulation failure precipitates this dissociation?

**Answer Choices:**
- A) Excessive cognitive reappraisal
- B) Over-reliance on situation selection
- C) Chronic suppression of authentic emotional experience combined with alienation, leading to psychological fragmentation ✓
- D) Attentional deployment to external stimuli

**Correct Answer: C**

**Rationale for Correct Answer:**
The Narrator suppresses his authentic emotions while living an unfulfilling consumerist life. Gross's research shows chronic suppression is costly and ultimately ineffective. The Narrator can't express his rage, frustration, or authentic desires through normal channels, so they fragment off into Tyler - a persona who can express everything the Narrator suppresses. Alienation from authentic self, combined with chronic suppression, creates conditions for dissociation.

**Distractor Analysis:**
- **A** (Excessive reappraisal) - The Narrator doesn't reappraise; he suppresses and denies.
- **B** (Over-reliance on situation selection) - He doesn't select situations; he passively accepts his life.
- **D** (Attentional deployment) - Tyler represents MORE than redirected attention; he's a fragmented identity.

**Course Connection:**
- **Film:** Fight Club - The Narrator's creation of Tyler
- **Readings:** Gross (2015) on suppression and its consequences
- **Integration:** Applies regulation research to understand dissociation

---

### Question 2

**Question:** The Narrator obsessively purchases IKEA furniture to feel "complete." According to McKnight & Kashdan (2009), why does consumerism fail as a source of purpose?

**Answer Choices:**
- A) Material goods are inherently meaningless
- B) The Narrator's specific choices are aesthetically poor
- C) Purpose requires self-organizing systems that create sustained meaning; consumption provides hedonic pleasure but not the enduring direction characteristic of purpose ✓
- D) Only relationships can provide purpose

**Correct Answer: C**

**Rationale for Correct Answer:**
McKnight & Kashdan describe purpose as a self-organizing system that provides sustained direction. Consumption provides hedonic spikes (pleasure from acquiring) but not eudaimonic meaning (sense that life matters). Each purchase provides temporary satisfaction that fades, requiring more consumption. This differs from purpose, which generates sustained meaning and direction. The Narrator's "nest" can never provide what purpose would.

**Distractor Analysis:**
- **A** (Material goods inherently meaningless) - Goods CAN have meaning in context; the issue is their failure to provide PURPOSE specifically.
- **B** (Aesthetically poor choices) - The specific aesthetics are irrelevant to the psychological failure.
- **D** (Only relationships) - Purpose can come from many sources; relationships aren't uniquely required.

**Course Connection:**
- **Film:** Fight Club - The Narrator's consumerism
- **Readings:** McKnight & Kashdan (2009) on purpose vs. hedonic pleasure
- **Integration:** Distinguishes consumption from purpose

---

### Question 3

**Question:** Tyler Durden states: "It's only after we've lost everything that we're free to do anything." According to Shermer's (2002) analysis of belief formation, what makes this philosophy appealing despite its irrationality?

**Answer Choices:**
- A) The statement is actually rational
- B) Tyler is inherently charismatic
- C) The philosophy offers a simple explanation for complex dissatisfaction and an actionable solution - characteristics that make beliefs "sticky" regardless of truth value ✓
- D) Audiences are uniquely susceptible to nihilism

**Correct Answer: C**

**Rationale for Correct Answer:**
Shermer describes "sticky" beliefs as those offering simple explanations and clear actions. Tyler's philosophy: (1) explains why people are unhappy (possessions), (2) offers simple solution (destroy possessions), and (3) provides clear action (fight, destroy). This simplicity and actionability make the belief appealing regardless of whether it's true. Complex dissatisfaction gets a simple diagnosis and treatment plan.

**Distractor Analysis:**
- **A** (Actually rational) - The philosophy has logical problems; its appeal isn't based on rationality.
- **B** (Charisma) - Charisma helps spread the message but doesn't explain WHY the message resonates.
- **D** (Unique susceptibility to nihilism) - The mechanisms apply to any appealing belief, not just nihilism.

**Course Connection:**
- **Film:** Fight Club - Tyler's philosophy
- **Readings:** Shermer (2002) on "sticky" beliefs
- **Integration:** Applies belief analysis to understand the film's appeal

---

### Question 4

**Question:** The film suggests that chronic insomnia triggered the Narrator's dissociation. According to research on sleep deprivation and reality testing, this portrayal is:

**Answer Choices:**
- A) Completely inaccurate - sleep deprivation has no psychological effects
- B) Partially accurate - severe sleep deprivation impairs reality monitoring and can contribute to dissociative and psychotic symptoms ✓
- C) Perfectly accurate - insomnia always causes DID
- D) Relevant only to the film's narrative

**Correct Answer: B**

**Rationale for Correct Answer:**
Sleep deprivation research shows impaired reality monitoring, increased susceptibility to hallucinations, and cognitive deficits that could contribute to dissociative experiences. The film's portrayal is PARTIALLY accurate: chronic insomnia could contribute to reality testing failures and dissociative phenomena. However, it's not PERFECTLY accurate because insomnia alone doesn't typically cause full dissociative identity disorder; other factors (trauma, predisposition) typically contribute.

**Distractor Analysis:**
- **A** (No psychological effects) - Sleep deprivation has well-documented psychological effects.
- **C** (Always causes DID) - DID is complex and multi-determined; insomnia alone isn't sufficient.
- **D** (Only narrative) - The portrayal has scientific basis, not just narrative convenience.

**Course Connection:**
- **Film:** Fight Club - insomnia and Tyler's emergence
- **Readings:** Sleep deprivation and reality monitoring research
- **Integration:** Evaluates film portrayal against scientific evidence

---

### Question 5

**Question:** Fight Club members follow increasingly destructive orders without question. According to social dominance research (Pratto et al., 1994), what does Project Mayhem reveal about the relationship between rejecting one hierarchy and creating another?

**Answer Choices:**
- A) Anarchism prevents new hierarchies from forming
- B) Fight Club successfully eliminates social dominance
- C) Anti-hierarchy movements often reproduce dominance structures; SDO may manifest as rejection of some hierarchies while embracing others ✓
- D) Only corporations create hierarchies

**Correct Answer: C**

**Rationale for Correct Answer:**
Pratto et al.'s SDO framework predicts that dominance orientation is a stable trait that finds expression across contexts. Fight Club's members reject corporate/consumer hierarchy but create a NEW hierarchy with Tyler at top. The anti-hierarchy rhetoric masks a new power structure. This illustrates how rejecting one hierarchy doesn't eliminate the psychological tendency toward hierarchy; it redirects it. Project Mayhem has ranks, rules, and punishments - it's a hierarchy denouncing hierarchy.

**Distractor Analysis:**
- **A** (Anarchism prevents hierarchy) - The film directly contradicts this by showing new hierarchy emerging.
- **B** (Successfully eliminates SDO) - Project Mayhem IS an expression of SDO, just directed differently.
- **D** (Only corporations) - The film shows that anti-corporate movements can also create hierarchies.

**Course Connection:**
- **Film:** Fight Club - Project Mayhem's structure
- **Readings:** Pratto et al. (1994) on social dominance orientation
- **Integration:** Applies SDO theory to revolutionary movements

---

*Last updated: January 2026*
*For Instructor Use Only*
