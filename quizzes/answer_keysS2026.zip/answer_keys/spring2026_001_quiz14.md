# PSYC 405 Section 001 - Quiz 14: Final Reflection
## CONFIDENTIAL ANSWER KEY

---

## Quiz 14: Final Reflection - What Did You Learn?

---

### Question 1

**Question:** You encounter a friend who believes in a conspiracy theory despite strong contrary evidence. Based on Boudry & Braeckman (2012) and Shermer (2002), which approach is LEAST likely to change their mind?

**Answer Choices:**
- A) Acknowledging emotional reasons why the belief might be appealing
- B) Exploring what evidence would, in principle, convince them otherwise
- C) Presenting more factual counter-evidence, as self-validating belief systems reinterpret contradictory evidence as confirmation ✓
- D) Understanding the social context in which the belief developed

**Correct Answer: C**

**Rationale for Correct Answer:**
This is a "least likely" question testing whether students understand the MECHANISM of belief persistence. Boudry & Braeckman's central insight is that self-validating beliefs REINTERPRET contradictory evidence as support. More facts don't help; they're absorbed into the belief system. Options A, B, and D might work because they address the belief's function (A), its falsifiability (B), and its origins (D). Only C directly feeds the self-validating cycle.

**Distractor Analysis:**
- **A** (Acknowledge emotional reasons) - MIGHT help by addressing why the belief is held, not just what it claims.
- **B** (Explore falsifiability) - MIGHT help by testing whether the belief is even theoretically disprovable.
- **D** (Understand social context) - MIGHT help by revealing how the belief was acquired and maintained.

**Course Connection:**
- **Film:** Application to real life
- **Readings:** Boudry & Braeckman (2012); Shermer (2002)
- **Integration:** Tests ability to apply course concepts to real-world situations

---

### Question 2

**Question:** A clinician must evaluate whether a defendant is malingering a mental disorder. According to Vrij et al. (2019) and the course material on Primal Fear, what should the clinician understand about their detection abilities?

**Answer Choices:**
- A) Clinical training provides excellent deception detection
- B) Behavioral cues reliably distinguish genuine from feigned symptoms
- C) Detection accuracy is likely near chance levels; systematic evaluation of symptom consistency and collateral information is more reliable than cue-based judgment ✓
- D) Malingerers always eventually reveal themselves

**Correct Answer: C**

**Rationale for Correct Answer:**
Vrij et al.'s meta-analysis shows detection accuracy near chance (54%) regardless of training. Primal Fear illustrates a sophisticated malingerer fooling trained evaluators. The clinician should understand their intuitions are unreliable and instead rely on systematic methods: checking symptom consistency over time, gathering collateral information, looking for impossible or rare symptom combinations. Process, not intuition, offers the best hope.

**Distractor Analysis:**
- **A** (Training provides detection) - Directly contradicted by Vrij et al.'s findings.
- **B** (Behavioral cues reliable) - The core finding is that cues are "faint and unreliable."
- **D** (Malingerers reveal themselves) - Aaron never revealed himself until he chose to gloat.

**Course Connection:**
- **Film:** Primal Fear - Clinical evaluation failure
- **Readings:** Vrij et al. (2019)
- **Integration:** Applies research to clinical forensic practice

---

### Question 3

**Question:** Based on the emotion regulation literature (Gross, 2015; Kashdan et al., 2015), which intervention approach would be most appropriate for someone like Nina Sayers (Black Swan)?

**Answer Choices:**
- A) Encouraging more intense practice to achieve her goals
- B) Suppressing emotional responses to reduce distress
- C) Removing her from the ballet context entirely
- D) Building emotion differentiation skills before attempting cognitive reappraisal or situation modification ✓

**Correct Answer: D**

**Rationale for Correct Answer:**
Kalokerinos et al. (2019) showed that for low differentiators, ALL regulation strategies are ineffective. The implication is that differentiation must be developed FIRST before other strategies can work. Nina's problem isn't that she uses the wrong strategy; it's that no strategy works because she can't identify what she's feeling. Building differentiation skills creates the foundation for effective regulation.

**Distractor Analysis:**
- **A** (More practice) - Would intensify her destructive pattern without addressing the underlying issue.
- **B** (Suppression) - Already failing for Nina; suppression doesn't work for low differentiators.
- **C** (Remove from ballet) - Might remove triggers but doesn't build the skills she needs for any context.

**Course Connection:**
- **Film:** Black Swan - Treatment implications
- **Readings:** Gross (2015); Kashdan et al. (2015); Kalokerinos et al. (2019)
- **Integration:** Applies research to treatment planning

---

### Question 4

**Question:** Research shows happiness may predict subsequent purpose rather than purpose predicting happiness (McKnight et al., 2025). Which implication for personal development is most supported by this finding?

**Answer Choices:**
- A) Pursuing purpose is futile
- B) Only happy people can have purpose
- C) Purpose is unrelated to well-being
- D) Cultivating positive emotional experiences may facilitate purpose development more effectively than directly pursuing purpose ✓

**Correct Answer: D**

**Rationale for Correct Answer:**
McKnight et al. (2025) found that happiness at Time 1 predicted purpose at Time 2, but not vice versa. The implication isn't that purpose is worthless (A), that unhappy people can't have purpose (B), or that they're unrelated (C). Rather, if happiness facilitates purpose development, then cultivating positive experiences may be a more effective path to purpose than directly pursuing meaning. Experience joy first; purpose may follow.

**Distractor Analysis:**
- **A** (Pursuing purpose futile) - The finding doesn't say purpose is worthless, just that the causal direction may be reversed.
- **B** (Only happy people can have purpose) - Too absolute; the research shows a predictive relationship, not an absolute requirement.
- **C** (Unrelated to well-being) - Contradicts the finding that they ARE related; the question is about direction.

**Course Connection:**
- **Film:** Multiple character arcs
- **Readings:** McKnight et al. (2025)
- **Integration:** Applies recent research to personal development implications

---

### Question 5

**Question:** The course examined psychological phenomena through both fictional films and scientific research. What is the primary VALUE of analyzing fictional portrayals alongside empirical findings?

**Answer Choices:**
- A) Films accurately represent psychological disorders
- B) Entertainment value makes learning more pleasant
- C) Film analysis develops observational and critical thinking skills; comparing fictional portrayals to research illuminates both the accuracy and the limitations of popular understanding ✓
- D) There is no value; fiction should be separated from science

**Correct Answer: C**

**Rationale for Correct Answer:**
The course's pedagogical value comes from the COMPARISON between fiction and research. Films show how psychological phenomena are popularly understood (often inaccurately), while research shows what science actually knows. Analyzing both develops critical thinking: students learn to observe behavior, apply theoretical frameworks, evaluate accuracy, and understand why popular portrayals differ from scientific evidence. The gap between fiction and fact is itself instructive.

**Distractor Analysis:**
- **A** (Films are accurate) - Films are often inaccurate; the value is in analyzing the inaccuracy.
- **B** (Entertainment value) - While true, entertainment isn't the PRIMARY pedagogical value.
- **D** (No value) - The entire course demonstrates substantial pedagogical value.

**Course Connection:**
- **Film:** Course methodology
- **Readings:** Course synthesis
- **Integration:** Articulates the course's pedagogical approach and value

---

*Last updated: January 2026*
*For Instructor Use Only*
