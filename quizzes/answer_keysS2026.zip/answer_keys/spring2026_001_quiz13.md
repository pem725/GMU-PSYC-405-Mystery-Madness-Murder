# PSYC 405 Section 001 - Quiz 13: Course Integration
## CONFIDENTIAL ANSWER KEY

---

## Quiz 13: Wrap-up and Review

---

### Question 1

**Question:** Across the films we studied (Shutter Island, North by Northwest, Sunset Boulevard, Black Swan, Good Will Hunting, What's Eating Gilbert Grape, Primal Fear, The Hurricane), which psychological construct appeared most consistently as a source of character dysfunction?

**Answer Choices:**
- A) Low intelligence
- B) Genetic predisposition
- C) Disrupted or distorted self-representation - whether through delusion, trauma, or external misattribution ✓
- D) Lack of financial resources

**Correct Answer: C**

**Rationale for Correct Answer:**
Across all eight films, identity disturbance emerges as the central theme:
- Shutter Island: Andrew creates Teddy identity
- North by Northwest: Thornhill assigned Kaplan identity
- Sunset Boulevard: Norma's delusional star identity
- Black Swan: Nina's fragmented self
- Good Will Hunting: Will's defense-constructed identity
- Gilbert Grape: Gilbert trapped in caregiver identity
- Primal Fear: Aaron/Roy fabricated identity
- The Hurricane: Carter's identity defined by false conviction

**Distractor Analysis:**
- **A** (Low intelligence) - Most characters are highly intelligent; intelligence doesn't protect against dysfunction.
- **B** (Genetic predisposition) - Genetics rarely mentioned; environmental factors predominate in these films.
- **D** (Financial lack) - Several characters have wealth (Norma, Thornhill); poverty isn't the common factor.

**Course Connection:**
- **Film:** All semester films
- **Readings:** Course synthesis
- **Integration:** Tests ability to identify cross-film patterns

---

### Question 2

**Question:** Emotion differentiation research (Kashdan et al., 2015; Kalokerinos et al., 2019) predicts that low differentiators will show ineffective emotion regulation. Which film character best exemplifies this pattern?

**Answer Choices:**
- A) Roger Thornhill (competent adaptation to threat)
- B) Sean Maguire (effective therapeutic processing)
- C) Nina Sayers (all regulation attempts increase rather than decrease distress) ✓
- D) Rubin Carter (sustained resistance under pressure)

**Correct Answer: C**

**Rationale for Correct Answer:**
Kalokerinos et al.'s key finding is that low differentiators show REVERSED effects - all regulation strategies increase negative affect. Nina exemplifies this: she tries practice (increases anxiety), perfectionism (increases anxiety), isolation (increases anxiety), seeking help from Thomas (increases anxiety). Every strategy fails because she can't identify what she's actually feeling. Her regulation attempts make her worse, not better.

**Distractor Analysis:**
- **A** (Thornhill) - Adapts effectively to changing situations; shows regulatory competence.
- **B** (Sean Maguire) - Demonstrates differentiated emotional processing and effective regulation.
- **D** (Rubin Carter) - Maintains regulation under extreme pressure; shows regulatory success, not failure.

**Course Connection:**
- **Film:** Black Swan - Nina's escalating symptoms
- **Readings:** Kashdan et al. (2015); Kalokerinos et al. (2019)
- **Integration:** Applies research to identify best exemplar across films

---

### Question 3

**Question:** According to the purpose literature (McKnight & Kashdan, 2009; Kashdan et al., 2024), authentic purpose requires self-concordance - alignment between goals and personal values. Which character's arc best demonstrates the DEVELOPMENT of self-concordant purpose?

**Answer Choices:**
- A) Norma Desmond (maintained consistent goals)
- B) Will Hunting (moved from externally imposed expectations to self-chosen direction) ✓
- C) Aaron Stampler (achieved his goals effectively)
- D) Teddy Daniels (pursued his mission relentlessly)

**Correct Answer: B**

**Rationale for Correct Answer:**
Will's arc shows purpose DEVELOPMENT. He starts with goals imposed by others (Lambeau's career expectations, his friends' assumptions) and moves toward self-chosen direction (pursuing Skylar, embracing vulnerability). This transformation from external to internal motivation represents the development of self-concordant purpose. He's not just achieving goals; he's choosing goals that align with his authentic values.

**Distractor Analysis:**
- **A** (Norma's consistent goals) - Norma's goals are delusional and don't develop; she maintains static dysfunction.
- **C** (Aaron achieved goals) - Aaron's goals are manipulative; effectiveness isn't the same as self-concordance.
- **D** (Teddy's mission) - Teddy pursues delusion, not authentic purpose; his mission is a defensive construct.

**Course Connection:**
- **Film:** Good Will Hunting - Will's character arc
- **Readings:** McKnight & Kashdan (2009); Kashdan et al. (2024)
- **Integration:** Identifies purpose development across films

---

### Question 4

**Question:** Shermer (2002) and Boudry & Braeckman (2012) both emphasize that intelligent people can construct sophisticated defenses for irrational beliefs. Which film most explicitly dramatizes this "smart person's folly"?

**Answer Choices:**
- A) What's Eating Gilbert Grape
- B) The Hurricane
- C) Shutter Island (Andrew constructs an elaborate, internally consistent delusional system) ✓
- D) North by Northwest

**Correct Answer: C**

**Rationale for Correct Answer:**
Shutter Island most explicitly shows intelligent rationalization of irrational belief. Andrew is clearly intelligent - he constructs an elaborate, internally consistent delusional system complete with conspiracy theories, fake investigations, and interpretive frameworks. Every piece of contradictory evidence is reinterpreted to support the delusion. This is Shermer's "smart person's folly" dramatized: intelligence creating better defenses, not better truth-detection.

**Distractor Analysis:**
- **A** (Gilbert Grape) - Characters aren't particularly sophisticated in their belief defenses.
- **B** (The Hurricane) - Carter maintains TRUE beliefs; this isn't about defending irrationality.
- **D** (North by Northwest) - Thornhill is confused by others' beliefs, not constructing elaborate defenses of his own.

**Course Connection:**
- **Film:** Shutter Island - Andrew's delusional system
- **Readings:** Shermer (2002); Boudry & Braeckman (2012)
- **Integration:** Identifies best film exemplar of key theoretical concept

---

### Question 5

**Question:** The course examined six governing areas of inquiry: BELIEF, PURPOSE, MOTIVATION, UNCERTAINTY, DISCOMFORT, and EMOTION. According to the psychological research we reviewed, how do these areas relate to each other?

**Answer Choices:**
- A) They are independent, modular systems with no interaction
- B) They form a strict hierarchy with belief at the top
- C) They are reducible to a single underlying construct
- D) They interact dynamically - uncertainty affects belief, emotion affects motivation, purpose organizes the others - forming an integrated psychological system ✓

**Correct Answer: D**

**Rationale for Correct Answer:**
The course emphasized interconnection among all six constructs:
- Uncertainty strengthens certain beliefs (Boudry & Braeckman)
- Emotion differentiation affects regulation and motivation (Kashdan et al.)
- Purpose organizes behavior and provides meaning (McKnight & Kashdan)
- Discomfort motivates belief change or defense
- Motivation is shaped by emotional states

These aren't separate modules but an integrated system where changes in one area ripple through others.

**Distractor Analysis:**
- **A** (Independent modules) - Contradicts extensive evidence for interconnection.
- **B** (Strict hierarchy) - No evidence for a single top construct; relationships are bidirectional.
- **C** (Single underlying construct) - The constructs are related but meaningfully distinct.

**Course Connection:**
- **Film:** All semester films
- **Readings:** Course synthesis across all readings
- **Integration:** Tests understanding of course framework as integrated system

---

*Last updated: January 2026*
*For Instructor Use Only*
