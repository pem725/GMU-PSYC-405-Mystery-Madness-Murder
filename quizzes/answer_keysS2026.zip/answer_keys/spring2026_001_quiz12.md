# PSYC 405 Section 001 - Quiz 12: The Hurricane
## CONFIDENTIAL ANSWER KEY

---

## Quiz 12: The Hurricane (1999)

---

### Question 1

**Question:** Rubin Carter was convicted largely based on eyewitness testimony that was later discredited. According to research on belief formation (Matthews, 2005), why might juries rationally accept flawed testimony?

**Answer Choices:**
- A) Juries are inherently irrational
- B) Eyewitnesses are always believed over defendants
- C) Given the information available at trial (without knowledge of eyewitness memory limitations), accepting confident testimony may have been statistically reasonable inference ✓
- D) Racial bias explains all wrongful convictions

**Correct Answer: C**

**Rationale for Correct Answer:**
Matthews' argument about rational inference from "weird evidence" applies here. Without contemporary knowledge of eyewitness memory limitations, confident eyewitness testimony seemed like strong evidence. Juries in 1967 didn't know that confidence doesn't correlate with accuracy, that memory is reconstructive, or that cross-racial identification is particularly error-prone. Given their available knowledge, accepting the testimony was reasonable, even though it led to error.

**Distractor Analysis:**
- **A** (Juries inherently irrational) - Too broad. The point is they were rational given LIMITED information.
- **B** (Eyewitnesses always believed) - Not universal; the specific context matters.
- **D** (Racial bias explains all) - Racial bias was a factor, but the question focuses on the epistemic process.

**Course Connection:**
- **Film:** The Hurricane - The wrongful conviction
- **Readings:** Matthews (2005) on rational inference from limited evidence
- **Integration:** Explains how reasonable-seeming decisions can lead to injustice

---

### Question 2

**Question:** Detective Vincent Della Pesca pursues Carter with obsessive intensity. According to Pratto et al. (1994), which aspect of social dominance orientation best explains his behavior?

**Answer Choices:**
- A) Low SDO seeking to protect victims
- B) In-group loyalty to fellow officers
- C) High SDO combined with legitimizing beliefs about Black criminality, making Carter's guilt a foregone conclusion requiring evidence to confirm rather than test ✓
- D) Personal animosity unrelated to social dominance

**Correct Answer: C**

**Rationale for Correct Answer:**
Pratto et al. describe how high SDO operates through "legitimizing myths" that justify hierarchy. Della Pesca's pursuit of Carter reflects beliefs that Black men are inherently criminal, making Carter's guilt presumed rather than investigated. The investigation sought evidence to CONFIRM the presumption rather than objectively TEST it. This is how high SDO combines with legitimizing myths to produce injustice while feeling justified.

**Distractor Analysis:**
- **A** (Low SDO protecting victims) - The victims' families were not Della Pesca's primary motivation based on film evidence.
- **B** (In-group loyalty) - This doesn't explain the obsessive focus on Carter specifically.
- **D** (Personal animosity) - While personal animosity existed, it was SHAPED by racial beliefs, not independent of them.

**Course Connection:**
- **Film:** The Hurricane - Della Pesca's persecution
- **Readings:** Pratto et al. (1994) on SDO and legitimizing myths
- **Integration:** Applies social dominance theory to explain institutional racism

---

### Question 3

**Question:** Carter maintained his innocence for 19 years despite enormous pressure to confess in exchange for parole. According to McKnight et al. (2025), what does this suggest about the relationship between purpose and happiness?

**Answer Choices:**
- A) Purpose requires happiness to sustain itself
- B) Happiness must precede purpose chronologically
- C) Purpose can sustain behavior even in the absence of happiness; however, research suggests that purpose alone may not be self-sustaining indefinitely ✓
- D) Purpose and happiness are identical constructs

**Correct Answer: C**

**Rationale for Correct Answer:**
McKnight et al. (2025) found that happiness predicts subsequent purpose, raising questions about whether purpose can sustain itself without positive emotional experience. Carter maintained purpose (proving innocence) for 19 years despite minimal happiness. This suggests purpose CAN drive behavior without happiness, but the finding that happiness facilitates purpose suggests this state may not be indefinitely sustainable without external support (like the Canadians who eventually helped him).

**Distractor Analysis:**
- **A** (Purpose requires happiness) - Carter's case shows purpose CAN persist without happiness, though perhaps not forever.
- **B** (Happiness must precede) - This is the McKnight et al. finding, but Carter's case shows purpose CAN exist without prior happiness.
- **D** (Identical constructs) - Research shows they're related but distinct; Carter had purpose without happiness.

**Course Connection:**
- **Film:** The Hurricane - Carter's 19-year resistance
- **Readings:** McKnight et al. (2025) on purpose-happiness relationship
- **Integration:** Uses Carter's case to test limits of purpose research

---

### Question 4

**Question:** Lesra Martin and the Canadian activists become invested in Carter's freedom despite having no prior connection to him. According to purpose research (Kashdan et al., 2024), what distinguishes their motivation from simple altruism?

**Answer Choices:**
- A) Financial incentives drove their involvement
- B) Guilt motivated their action
- C) Their involvement became self-concordant - aligned with deeply held values - transforming from external interest to integrated purpose ✓
- D) Altruism and purpose are synonymous

**Correct Answer: C**

**Rationale for Correct Answer:**
Kashdan et al. (2024) emphasize self-concordance - goals aligned with authentic personal values. The Canadians' involvement began as interest in a book but became integrated purpose when it aligned with their values about justice, truth, and human dignity. This transforms simple helping into purpose: the activity becomes central to who they are and what they're about, not just something they're doing.

**Distractor Analysis:**
- **A** (Financial incentives) - No evidence for financial motivation; they spent their own resources.
- **B** (Guilt) - No indication of guilt-driven motivation in the film.
- **D** (Altruism equals purpose) - Purpose involves integration with identity; altruism can be momentary.

**Course Connection:**
- **Film:** The Hurricane - The Canadians' commitment
- **Readings:** Kashdan et al. (2024) on self-concordance
- **Integration:** Distinguishes purpose from other prosocial motivations

---

### Question 5

**Question:** The film depicts how confirmation bias affected the investigation - evidence supporting Carter's guilt was emphasized while exculpatory evidence was dismissed. According to Boudry et al. (2015), this pattern represents which broader phenomenon?

**Answer Choices:**
- A) Individual investigator incompetence
- B) Deliberate conspiracy to frame Carter
- C) The epidemiology of belief - how false beliefs can spread through institutions via normal cognitive processes without requiring malicious intent ✓
- D) Standard investigative procedure

**Correct Answer: C**

**Rationale for Correct Answer:**
Boudry et al.'s "epidemiology of pseudoscience" framework explains how false beliefs spread through normal cognitive mechanisms. The investigation's confirmation bias wasn't necessarily deliberate conspiracy or individual incompetence - it was how NORMAL cognitive processes operated within an institutional context. Each person processed information through their existing beliefs, and these biased interpretations accumulated into institutional conviction. No single villain; just cognitive normalcy producing injustice.

**Distractor Analysis:**
- **A** (Individual incompetence) - The process operated through normal cognition, not exceptional failure.
- **B** (Deliberate conspiracy) - While some may have acted with malice, the framework explains how injustice can occur without conspiracy.
- **D** (Standard procedure) - This critique: these ARE standard procedures, which is the problem.

**Course Connection:**
- **Film:** The Hurricane - Institutional confirmation bias
- **Readings:** Boudry et al. (2015) on belief epidemiology
- **Integration:** Applies belief spread theory to institutional contexts

---

*Last updated: January 2026*
*For Instructor Use Only*
