# PSYC 405 Section 001 - Quiz 9: What's Eating Gilbert Grape
## CONFIDENTIAL ANSWER KEY

---

## Quiz 9: What's Eating Gilbert Grape (1993)

---

### Question 1

**Question:** Gilbert Grape has assumed the caregiver role for his entire family, including his intellectually disabled brother Arnie. According to McKnight & Kashdan (2009), how might this role affect his sense of purpose?

**Answer Choices:**
- A) Caregiving provides automatic, healthy purpose
- B) Externally imposed obligations can substitute for authentic purpose, creating meaning without self-concordance ✓
- C) Family responsibilities always enhance well-being
- D) Purpose cannot develop in constraining environments

**Correct Answer: B**

**Rationale for Correct Answer:**
McKnight & Kashdan distinguish between imposed obligations and self-concordant purpose. Gilbert didn't CHOOSE his caregiver role; it was imposed by family circumstances after his father's suicide. While caregiving provides structure and meaning, it lacks self-concordance - alignment with personally chosen values and goals. Gilbert has purpose-like structure without authentic purpose, which explains his dissatisfaction despite having clear direction.

**Distractor Analysis:**
- **A** (Automatic healthy purpose) - Too simple. Purpose quality depends on self-concordance, not just having direction.
- **C** (Family responsibilities always enhance well-being) - Research shows obligations can be stressful when not freely chosen.
- **D** (Purpose cannot develop in constraints) - Purpose CAN develop even in difficult circumstances, but imposed obligations aren't the same as authentic purpose.

**Course Connection:**
- **Film:** What's Eating Gilbert Grape - Gilbert's caregiver burden
- **Readings:** McKnight & Kashdan (2009) on self-concordance and purpose
- **Integration:** Distinguishes between having direction and having authentic purpose

---

### Question 2

**Question:** Gilbert's affair with Betty Carver appears to serve a psychological function. According to emotion differentiation research (Kashdan et al., 2015), what does the affair reveal about Gilbert's emotional processing?

**Answer Choices:**
- A) High differentiation enabling strategic mood repair
- B) Low differentiation - seeking stimulation to escape undifferentiated negative affect rather than addressing specific emotions ✓
- C) Successful compartmentalization of life domains
- D) Adaptive coping through distraction

**Correct Answer: B**

**Rationale for Correct Answer:**
Gilbert's affair appears to serve an escape function - seeking excitement to avoid his mundane, trapped existence. But he's not escaping a specific emotion; he's escaping general malaise. Kashdan et al. show that low differentiators seek broad escape mechanisms rather than targeted solutions because they can't identify what specifically is wrong. Gilbert can't articulate his unhappiness precisely enough to address it, so he seeks global stimulation instead.

**Distractor Analysis:**
- **A** (High differentiation for mood repair) - High differentiators would target specific emotions with specific strategies, not seek general escape.
- **C** (Successful compartmentalization) - The affair creates complications that spill into other areas, suggesting failed compartmentalization.
- **D** (Adaptive coping) - The affair creates more problems than it solves, suggesting maladaptive rather than adaptive coping.

**Course Connection:**
- **Film:** What's Eating Gilbert Grape - Gilbert's affair
- **Readings:** Kashdan et al. (2015) on emotion differentiation and coping strategies
- **Integration:** Applies differentiation research to understand self-destructive behavior

---

### Question 3

**Question:** Arnie's intellectual disability is portrayed with specific behavioral characteristics (climbing the water tower, fixations, limited verbal ability). Which contemporary understanding would critique the film's portrayal?

**Answer Choices:**
- A) All portrayals of disability are inherently problematic
- B) The actor should have had an intellectual disability
- C) The film focuses on caregiver burden rather than Arnie's inner experience, potentially reinforcing deficit-focused views of disability ✓
- D) Arnie is portrayed too positively

**Correct Answer: C**

**Rationale for Correct Answer:**
Contemporary disability scholarship critiques portrayals that focus primarily on how disability affects caregivers rather than the subjective experience of disabled individuals. The film centers Gilbert's burden rather than Arnie's inner life. We learn what Arnie DOES but rarely what he FEELS or THINKS. This perspective potentially reinforces deficit-focused views where disability is primarily understood as a burden rather than a different mode of existence.

**Distractor Analysis:**
- **A** (All portrayals problematic) - Too absolute. Good disability portrayals exist and are important.
- **B** (Actor should be disabled) - A valid critique but not the CENTRAL contemporary concern addressed here.
- **D** (Portrayed too positively) - Arnie's portrayal includes challenging behaviors; the critique isn't about positive vs. negative.

**Course Connection:**
- **Film:** What's Eating Gilbert Grape - Arnie's portrayal
- **Readings:** Methodological considerations for analyzing film representations
- **Integration:** Applies critical analysis skills to evaluate psychological portrayals

---

### Question 4

**Question:** Gilbert's mother has become housebound due to obesity following her husband's suicide. According to Gross (2015), her withdrawal represents which emotion regulation pattern?

**Answer Choices:**
- A) Healthy situation selection avoiding triggers
- B) Maladaptive situation selection - avoidance that provides short-term relief but maintains long-term dysfunction ✓
- C) Cognitive reappraisal of her circumstances
- D) Expressive suppression of grief

**Correct Answer: B**

**Rationale for Correct Answer:**
Gross distinguishes adaptive from maladaptive situation selection. Bonnie Grape's complete withdrawal from the world is situation selection taken to an extreme - she avoids ALL situations that might trigger emotional responses. This provides short-term relief (no confrontations, no judgments) but maintains her depression, obesity, and family dysfunction. She's not selecting situations strategically; she's eliminating situations entirely.

**Distractor Analysis:**
- **A** (Healthy avoidance) - The avoidance is so extreme it prevents necessary life functioning. This is clearly maladaptive.
- **C** (Reappraisal) - No evidence she's reinterpreting her situation; she's simply avoiding.
- **D** (Expressive suppression) - Suppression involves inhibiting emotional expression. Bonnie isn't suppressing emotion in interactions; she's avoiding interactions entirely.

**Course Connection:**
- **Film:** What's Eating Gilbert Grape - Bonnie's withdrawal
- **Readings:** Gross (2015) on situation selection as emotion regulation
- **Integration:** Applies the distinction between adaptive and maladaptive situation selection

---

### Question 5

**Question:** When Arnie accidentally hits their mother, she slaps him - her first physical act in years. According to research on emotion (Feldman Barrett et al., 2001), what does this moment reveal about the relationship between behavioral inhibition and emotional experience?

**Answer Choices:**
- A) Suppressed emotions eventually disappear
- B) Physical immobility eliminates emotional reactivity
- C) Extreme suppression does not eliminate emotional capacity; intense provocation can overwhelm even long-standing inhibition ✓
- D) Maternal instinct overrides all other responses

**Correct Answer: C**

**Rationale for Correct Answer:**
Feldman Barrett et al.'s research shows that emotions remain even when not expressed or processed. Bonnie's years of immobility didn't eliminate her emotional capacity; it suppressed expression while emotions accumulated. The slap reveals that intense emotional provocation can break through even extreme, long-standing behavioral inhibition. The emotional response was always present; it just needed sufficient trigger to override the inhibition.

**Distractor Analysis:**
- **A** (Suppression eliminates emotions) - This is what the moment CONTRADICTS. If suppression eliminated emotions, she couldn't have reacted.
- **B** (Immobility eliminates reactivity) - The slap proves this false. Immobility suppressed but didn't eliminate emotional reactivity.
- **D** (Maternal instinct overrides) - This doesn't explain the mechanism. The question is about behavioral inhibition and emotional experience, not maternal instinct specifically.

**Course Connection:**
- **Film:** What's Eating Gilbert Grape - Bonnie's slap
- **Readings:** Feldman Barrett et al. (2001) on emotional experience and expression
- **Integration:** Uses a dramatic moment to illustrate the persistence of emotion despite suppression

---

*Last updated: January 2026*
*For Instructor Use Only*
