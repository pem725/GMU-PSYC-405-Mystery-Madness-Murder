# PSYC 405 Section 001 - Quiz 3: Shutter Island / North by Northwest
## CONFIDENTIAL ANSWER KEY

---

## Quiz 3: Transition - Reality and Identity

---

### Question 1

**Question:** At the end of Shutter Island, Andrew asks: "Which would be worse - to live as a monster, or to die as a good man?" This question most directly engages which psychological construct from the purpose literature (McKnight & Kashdan, 2009)?

**Answer Choices:**
- A) Self-efficacy and competence beliefs
- B) The relationship between identity coherence and meaningful existence ✓
- C) Hedonic versus eudaimonic well-being
- D) Goal-directed behavior and motivation

**Correct Answer: B**

**Rationale for Correct Answer:**
Andrew's question goes to the heart of purpose: can life be meaningful when identity is fragmented or monstrous? McKnight & Kashdan's model of purpose as a self-organizing system requires coherent identity - the system needs a stable "self" to organize around. Andrew recognizes that living as a "monster" (his true self) might preclude meaningful existence, while dying as a "good man" (the delusional Teddy) preserves narrative coherence at the cost of truth.

**Distractor Analysis:**
- **A** (Self-efficacy) - This is about believing you CAN do things. Andrew's question is about whether you SHOULD exist, not whether you're capable.
- **C** (Hedonic vs. eudaimonic) - While relevant, this distinction doesn't capture the identity coherence issue. Both monster and good man could experience either type of well-being.
- **D** (Goal-directed behavior) - Too narrow. Andrew isn't asking about goals but about the fundamental worth of existence under different identity conditions.

**Course Connection:**
- **Film:** Shutter Island - Andrew's final philosophical choice
- **Readings:** McKnight & Kashdan (2009) on purpose as requiring integrated identity
- **Integration:** The film's ending illustrates how purpose requires identity coherence that Andrew cannot achieve

---

### Question 2

**Question:** Roger Thornhill in North by Northwest is mistaken for "George Kaplan," who doesn't actually exist. According to Shermer's analysis of belief formation, what makes this false identity so readily accepted by others?

**Answer Choices:**
- A) People inherently trust government agencies
- B) Thornhill's behavior confirms their pre-existing expectations
- C) The identity fills a cognitive schema that observers already possess, making confirmation bias more powerful than contradictory evidence ✓
- D) Mistaken identity is statistically common in espionage contexts

**Correct Answer: C**

**Rationale for Correct Answer:**
Shermer's analysis emphasizes that beliefs are often adopted because they fit existing cognitive schemas. The villains already BELIEVE Kaplan exists (the CIA created that belief). When Thornhill appears where they expect Kaplan, their pre-existing schema interprets his presence as confirmation. Shermer notes that once a belief exists, evidence is interpreted to support it - this is exactly what happens with the "Kaplan" identity.

**Distractor Analysis:**
- **A** (Trust government agencies) - The villains are OPPOSING the government, not trusting it. This reverses the dynamic.
- **B** (Behavior confirms expectations) - Partially true but misses the key point. It's the SCHEMA that drives interpretation, not specific behaviors.
- **D** (Statistically common) - No evidence for this claim, and it doesn't explain the psychological mechanism.

**Course Connection:**
- **Film:** North by Northwest - The George Kaplan mistaken identity
- **Readings:** Shermer (2002) on confirmation bias and belief formation
- **Integration:** Shows how the same cognitive mechanisms that create delusional beliefs (Shutter Island) also operate in "normal" contexts

---

### Question 3

**Question:** Both Teddy Daniels and Roger Thornhill experience profound uncertainty about their identities, but the psychological source differs. What is the KEY distinction?

**Answer Choices:**
- A) Teddy's uncertainty is externally imposed; Roger's is internally generated
- B) Roger experiences identity confusion; Teddy experiences identity delusion
- C) Teddy's identity crisis stems from motivated self-deception; Roger's stems from others' misattribution ✓
- D) Both represent equivalent forms of dissociative experience

**Correct Answer: C**

**Rationale for Correct Answer:**
The critical distinction is the source of the identity confusion. Teddy/Andrew actively constructs a false identity to protect himself from unbearable truth - this is MOTIVATED self-deception serving psychological protection. Roger is ASSIGNED a false identity by others - he knows who he really is but cannot convince anyone else. One is internal defensive mechanism; the other is external misattribution.

**Distractor Analysis:**
- **A** (External vs. internal) - Reverses the correct direction. Teddy's is internally generated (self-deception); Roger's is externally imposed (others' beliefs).
- **B** (Confusion vs. delusion) - Imprecise. "Confusion" doesn't capture Teddy's state, which is delusional certainty, not confusion.
- **D** (Equivalent dissociative experience) - Clinically incorrect. Roger doesn't have a dissociative condition; he has a communication problem.

**Course Connection:**
- **Film:** Shutter Island and North by Northwest - contrasting identity crises
- **Readings:** Boudry & Braeckman (2012) on self-deception versus external deception
- **Integration:** Helps students distinguish between different psychological mechanisms that can produce similar surface appearances

---

### Question 4

**Question:** Hitchcock deliberately sets the famous crop-duster scene in an open, mundane environment. According to research on emotion and context (Kashdan et al., 2015), why does this setting intensify rather than diminish fear?

**Answer Choices:**
- A) Rural settings activate evolutionary threat detection systems
- B) The contrast between mundane context and lethal threat creates emotional differentiation difficulties, amplifying distress ✓
- C) Isolation increases objective danger levels
- D) Audiences have learned associations between fields and violence

**Correct Answer: B**

**Rationale for Correct Answer:**
Kashdan et al.'s research on emotion differentiation suggests that unexpected emotional situations create processing difficulties. The open field SHOULD be safe - our schemas tell us danger lurks in dark alleys, not sunny cornfields. When lethal threat appears in a "safe" context, the mismatch between expected and actual emotional significance creates confusion that amplifies the fear response. The audience can't rely on contextual cues to calibrate their emotional response.

**Distractor Analysis:**
- **A** (Evolutionary threat detection) - No evidence that rural settings specifically activate threat detection. Dark, enclosed spaces are more evolutionarily associated with predators.
- **C** (Isolation increases danger) - Objectively, isolation might reduce help availability, but this doesn't explain the EMOTIONAL intensification, which is the question's focus.
- **D** (Learned associations) - No such learned association exists; this is exactly why the scene is surprising.

**Course Connection:**
- **Film:** North by Northwest - crop-duster scene
- **Readings:** Kashdan et al. (2015) on emotion differentiation and context
- **Integration:** Applies emotion research to understand Hitchcock's filmmaking technique

---

### Question 5

**Question:** The psychiatric institution in Shutter Island and the government conspiracy in North by Northwest both represent external systems that control individual reality. Which concept from social dominance research (Pratto et al., 1994) is most relevant?

**Answer Choices:**
- A) In-group favoritism and out-group derogation
- B) Legitimizing myths that justify hierarchical systems
- C) Institutional power's capacity to define and enforce what counts as "truth" ✓
- D) Individual differences in preference for equality

**Correct Answer: C**

**Rationale for Correct Answer:**
Both films dramatize how powerful institutions can define reality for individuals. In Shutter Island, the psychiatric institution determines what is "sane" and "insane." In North by Northwest, the CIA and Vandamm's organization both construct "realities" (Kaplan exists/doesn't exist) that override individual truth. This connects to SDO research showing how dominant groups control not just resources but the frameworks for interpreting reality.

**Distractor Analysis:**
- **A** (In-group/out-group) - While present in both films, this doesn't capture the reality-defining function of institutional power.
- **B** (Legitimizing myths) - Partially relevant but focuses on justification rather than active reality construction.
- **D** (Individual SDO differences) - The question is about institutional power, not individual differences in dominance orientation.

**Course Connection:**
- **Film:** Both Shutter Island and North by Northwest - institutional control of reality
- **Readings:** Pratto et al. (1994) on social dominance and institutional power
- **Integration:** Bridges the two films through a common theoretical framework

---

*Last updated: January 2026*
*For Instructor Use Only*
