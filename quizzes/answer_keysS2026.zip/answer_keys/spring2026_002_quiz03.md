# PSYC 405 Section 002 - Quiz 3: The Machinist / Identity
## CONFIDENTIAL ANSWER KEY

---

## Quiz 3: Transition - Fragmented Selves

---

### Question 1

**Question:** Both Trevor Reznik and Malcolm Rivers (Identity) experience fragmented identity, but the films portray this differently. What is the KEY diagnostic distinction?

**Answer Choices:**
- A) Trevor is psychotic; Malcolm is neurotic
- B) Trevor's fragment is external hallucination; Malcolm's fragments are alternate personalities
- C) Trevor creates one externalized guilt projection; Malcolm's "personalities" are portrayed as separate identities within one mind - the latter represents dissociative identity disorder ✓
- D) Only Malcolm's condition is real; Trevor is simply sleep deprived

**Correct Answer: C**

**Rationale for Correct Answer:**
The key distinction is the TYPE of fragmentation. Trevor creates ONE external projection (Ivan) that represents his repressed guilt - this is closer to psychotic projection or hallucination. Malcolm is portrayed as having MULTIPLE distinct identities (the motel guests) existing within one mind - this is the film's depiction of dissociative identity disorder. Trevor's self remains intact while projecting; Malcolm's self is depicted as actually fragmented into separate personalities.

**Distractor Analysis:**
- **A** (Psychotic vs. neurotic) - Both conditions are more severe than neurosis; the distinction is about fragmentation TYPE.
- **B** (External vs. internal) - Partially correct but doesn't capture the full distinction between projection and dissociation.
- **D** (Only Malcolm's is real) - Both characters have genuine psychological conditions, just different types.

**Course Connection:**
- **Film:** The Machinist and Identity - different fragmentation types
- **Readings:** Diagnostic distinctions between psychosis and dissociation
- **Integration:** Teaches students to distinguish between different psychological mechanisms

---

### Question 2

**Question:** Identity depicts dissociative identity disorder (DID) with multiple distinct "alters." According to current scientific understanding, what does the film get MOST wrong about DID?

**Answer Choices:**
- A) DID never involves multiple personalities
- B) Trauma is unrelated to DID
- C) DID rarely presents with dramatically distinct personalities aware of each other; the "host knows nothing" trope is cinematically convenient but clinically uncommon ✓
- D) DID cannot involve violence

**Correct Answer: C**

**Rationale for Correct Answer:**
Clinical DID typically involves subtle personality shifts rather than dramatically distinct personalities. Alters in actual DID often share some awareness of each other, and complete amnesia between states is less common than portrayed. The film's depiction of alters as completely separate people with no overlap, meeting in a motel, dramatically overstates the separateness for narrative purposes. The "host knows nothing" trope serves plot but misrepresents typical presentation.

**Distractor Analysis:**
- **A** (DID never involves multiple personalities) - DID does involve alternate identity states; the issue is HOW they're portrayed.
- **B** (Trauma unrelated) - Trauma is strongly associated with DID; the film correctly includes traumatic history.
- **D** (Cannot involve violence) - Violence is possible; the issue isn't whether violence occurs but how DID is portrayed.

**Course Connection:**
- **Film:** Identity - DID portrayal
- **Readings:** Scientific understanding of DID
- **Integration:** Develops critical evaluation of film portrayals vs. research

---

### Question 3

**Question:** In Identity, psychiatrists attempt to "integrate" Malcolm's personalities by eliminating the dangerous ones. According to research on belief systems (Boudry & Braeckman, 2012), what problem does this approach face?

**Answer Choices:**
- A) Integration is always impossible
- B) Dangerous personalities cannot be eliminated
- C) The assumption that "bad" alters can be simply removed reflects a self-validating belief about treatment that may not match the complexity of dissociative systems ✓
- D) Only medication can treat DID

**Correct Answer: C**

**Rationale for Correct Answer:**
The psychiatrists in the film operate from a self-validating belief: they assume that identifying and eliminating "bad" personalities will cure Malcolm. This belief is self-validating because: (1) it provides a clear treatment plan, (2) any failure can be attributed to incomplete elimination, and (3) it doesn't require questioning the underlying theory. However, dissociative systems are more complex than this model assumes; alters often serve protective functions that can't be simply eliminated.

**Distractor Analysis:**
- **A** (Integration always impossible) - Integration IS sometimes achieved; the issue is the oversimplified approach.
- **B** (Dangerous personalities can't be eliminated) - The issue isn't impossibility but conceptual oversimplification.
- **D** (Only medication treats DID) - Therapy is the primary treatment; medication is adjunctive at best.

**Course Connection:**
- **Film:** Identity - psychiatric treatment approach
- **Readings:** Boudry & Braeckman (2012) on self-validating beliefs
- **Integration:** Applies belief theory to critique film's treatment portrayal

---

### Question 4

**Question:** Both films use unreliable narration - viewers cannot trust what they see. According to Shermer (2002), how does this narrative technique parallel the psychology of belief?

**Answer Choices:**
- A) Unreliable narration is simply a storytelling trick
- B) Viewers are too easily deceived
- C) Just as film viewers construct coherent narratives from incomplete information, people construct beliefs from limited evidence and resist revising them even when contradicted ✓
- D) Unreliable narration prevents psychological analysis

**Correct Answer: C**

**Rationale for Correct Answer:**
Shermer describes how people construct beliefs from limited evidence and then defend these beliefs even when contradicted. The films replicate this experience: viewers construct a coherent narrative (Trevor is being stalked; the motel guests are separate people), then resist revising this understanding even as contradictory evidence mounts. The twist reveals that their constructed belief was wrong - just as real-world beliefs can be confidently held yet mistaken.

**Distractor Analysis:**
- **A** (Storytelling trick) - It's a technique that parallels real cognitive processes, not just a gimmick.
- **B** (Viewers too easily deceived) - The point isn't about viewer gullibility but about normal cognitive processes.
- **D** (Prevents analysis) - Unreliable narration actually enables analysis of belief formation.

**Course Connection:**
- **Film:** The Machinist and Identity - unreliable narration
- **Readings:** Shermer (2002) on belief formation
- **Integration:** Uses film technique to illustrate belief construction

---

### Question 5

**Question:** Trevor eventually confesses to the police, achieving relief. Malcolm's "cure" is ambiguous (the surviving personality may also be murderous). According to McKnight & Kashdan (2009), what does Trevor's confession achieve that Malcolm's treatment does not?

**Answer Choices:**
- A) Legal punishment as moral cleansing
- B) Authentic integration of traumatic experience into identity, allowing purpose and meaning to resume - versus continued fragmentation ✓
- C) External validation of innocence
- D) Nothing - both outcomes are equally therapeutic

**Correct Answer: B**

**Rationale for Correct Answer:**
McKnight & Kashdan's purpose framework requires integrated identity for purpose to function. Trevor's confession achieves integration - he acknowledges the trauma, accepts responsibility, and can rebuild identity around this truth. His purpose system can reorganize around authentic experience. Malcolm's treatment doesn't achieve integration; the fragmentation continues (possibly with a still-dangerous alter). Without authentic integration, purpose cannot develop.

**Distractor Analysis:**
- **A** (Legal punishment as cleansing) - The therapeutic value isn't punishment but integration of experience.
- **C** (Validation of innocence) - Trevor isn't innocent; he confesses to guilt. The value is in accepting truth.
- **D** (Equally therapeutic) - The outcomes are explicitly different in the films; Trevor achieves peace while Malcolm's fate is ominous.

**Course Connection:**
- **Film:** The Machinist and Identity - contrasting outcomes
- **Readings:** McKnight & Kashdan (2009) on purpose and identity integration
- **Integration:** Uses contrasting endings to illustrate role of integration in recovery

---

*Last updated: January 2026*
*For Instructor Use Only*
