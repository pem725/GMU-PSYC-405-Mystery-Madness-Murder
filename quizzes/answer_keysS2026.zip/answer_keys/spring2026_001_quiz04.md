# PSYC 405 Section 001 - Quiz 4: North by Northwest
## CONFIDENTIAL ANSWER KEY

---

## Quiz 4: North by Northwest (1959)

---

### Question 1

**Question:** Roger Thornhill's mother dismisses his claims about being kidnapped and nearly killed, even when presented with evidence. According to Matthews (2005), why might her "irrational" skepticism actually represent reasonable inference?

**Answer Choices:**
- A) Maternal instinct overrides logical evaluation
- B) Given base rates, a son's fantastic story about spies is less probable than alternative explanations, making skepticism statistically defensible ✓
- C) Emotional attachment prevents objective assessment
- D) Older adults are generally more skeptical of younger generations

**Correct Answer: B**

**Rationale for Correct Answer:**
Matthews' (2005) key argument is that seemingly "irrational" dismissal of weird evidence can actually be Bayesian-rational given prior probabilities. The base rate of advertising executives being kidnapped by foreign spies is extremely low. The base rate of sons exaggerating, being drunk, or seeking attention is much higher. Given these priors, skepticism about the spy story is statistically defensible even when some evidence supports it.

**Distractor Analysis:**
- **A** (Maternal instinct) - Vague appeal to instinct without psychological mechanism. Maternal instinct could equally predict believing or protecting the son.
- **C** (Emotional attachment prevents objectivity) - Could explain either belief OR disbelief. Doesn't specify direction.
- **D** (Age-based skepticism) - No evidence for this claim, and his mother shows skepticism about THIS claim, not general skepticism.

**Course Connection:**
- **Film:** North by Northwest - Mrs. Thornhill's dismissal of Roger's story
- **Readings:** Matthews (2005) "Rational Inference from Weird Evidence"
- **Integration:** Challenges students to consider when "irrational" responses might actually be rational given prior beliefs

---

### Question 2

**Question:** Vandamm and his associates maintain the fiction of "George Kaplan" despite mounting evidence that Thornhill is not their target. This persistence demonstrates which cognitive phenomenon described in Boudry et al. (2015)?

**Answer Choices:**
- A) Sunk cost fallacy in decision-making
- B) Motivated cognition that preserves a useful belief despite contradictory evidence ✓
- C) Fundamental attribution error in person perception
- D) Availability heuristic in probability judgment

**Correct Answer: B**

**Rationale for Correct Answer:**
Vandamm's belief that Thornhill is Kaplan serves his purposes - it provides a target for his counterintelligence efforts. Boudry et al. describe how useful beliefs are maintained through motivated cognition even when evidence contradicts them. Vandamm NEEDS a Kaplan to exist, so he interprets Thornhill's denials as deception rather than truth. The belief's utility drives its persistence.

**Distractor Analysis:**
- **A** (Sunk cost fallacy) - This would apply to continuing an action because of past investment. Vandamm's belief persistence isn't about sunk costs but about utility.
- **C** (Fundamental attribution error) - This is about over-attributing behavior to personality vs. situation. Not directly relevant here.
- **D** (Availability heuristic) - This is about judging probability by ease of recall. Vandamm's persistence isn't about probability judgment.

**Course Connection:**
- **Film:** North by Northwest - Vandamm's persistent misidentification
- **Readings:** Boudry et al. (2015) on motivated cognition and belief persistence
- **Integration:** Shows how even villains operate through normal cognitive mechanisms, not special "evil" psychology

---

### Question 3

**Question:** Eve Kendall operates as a triple agent, deceiving Thornhill, Vandamm, and (initially) the CIA. According to Vrij et al. (2019) on deception detection, why is she successful?

**Answer Choices:**
- A) Women are inherently better at deception than men
- B) Romantic contexts disable normal lie detection abilities
- C) Nonverbal cues to deception are "faint and unreliable," and people are mediocre lie detectors regardless of the deceiver's characteristics ✓
- D) Trained agents develop unique physiological control over deception cues

**Correct Answer: C**

**Rationale for Correct Answer:**
Vrij et al.'s meta-analysis demonstrates that deception detection accuracy is typically near chance (54%) regardless of training, relationship, or deceiver characteristics. Eve succeeds not because of special skills but because everyone is bad at detecting lies. The "faint and unreliable" nature of deception cues means that confident, consistent lying is rarely detected - and Eve is both confident and consistent.

**Distractor Analysis:**
- **A** (Women better at deception) - No evidence for sex differences in deception ability. This is a stereotype.
- **B** (Romance disables detection) - Romantic contexts might INCREASE motivation to detect deception, though they don't improve accuracy.
- **D** (Trained agents control cues) - The research shows training doesn't significantly improve either deception OR detection. If there were controllable cues, training would help.

**Course Connection:**
- **Film:** North by Northwest - Eve Kendall's multiple deceptions
- **Readings:** Vrij et al. (2019) on deception detection accuracy
- **Integration:** Applies deception research to understand why film characters (and real people) are so easily deceived

---

### Question 4

**Question:** Thornhill transforms from a self-interested advertising executive to someone who risks his life for others. According to McKnight et al. (2025) on purpose and happiness, what is the most likely causal direction?

**Answer Choices:**
- A) Finding purpose through helping Eve led to his increased positive affect
- B) Positive emotional experiences with Eve may have preceded and facilitated his sense of purpose ✓
- C) Purpose and happiness developed simultaneously and independently
- D) External threats eliminated his capacity for both purpose and happiness

**Correct Answer: B**

**Rationale for Correct Answer:**
McKnight et al. (2025) present evidence that happiness predicts subsequent purpose development, challenging the common assumption that purpose leads to happiness. In Thornhill's case, his positive emotional experiences with Eve (attraction, excitement, connection) may have created the conditions that allowed purpose (protecting her, serving the mission) to develop. The happiness came first and enabled the purpose.

**Distractor Analysis:**
- **A** (Purpose led to happiness) - This is the reverse of what McKnight et al. (2025) found. While intuitively appealing, the research suggests the opposite causal direction.
- **C** (Simultaneous independent development) - The research suggests they're related, not independent. Simultaneous but unrelated development doesn't match the evidence.
- **D** (Threats eliminated both) - Contradicts what we see in the film. Thornhill develops BOTH purpose and positive affect during the threatening adventure.

**Course Connection:**
- **Film:** North by Northwest - Thornhill's character arc
- **Readings:** McKnight et al. (2025) on happiness-purpose causal direction
- **Integration:** Uses the film to illustrate contemporary research on purpose development

---

### Question 5

**Question:** The film's famous Mount Rushmore climax places the protagonists literally climbing over the faces of presidents. What psychological function does this setting serve according to research on emotion regulation (Gross, 2015)?

**Answer Choices:**
- A) Patriotic symbolism reduces viewer anxiety
- B) Familiar landmarks provide cognitive anchoring
- C) The iconic setting creates cognitive dissonance between safety associations and present danger, intensifying emotional response ✓
- D) Height phobia activation is universal across audiences

**Correct Answer: C**

**Rationale for Correct Answer:**
Gross's framework emphasizes how cognitive appraisals shape emotional responses. Mount Rushmore is associated with American stability, patriotism, and monumental permanence - all "safe" associations. Placing mortal danger in this context creates dissonance: the setting says "safety" while the action says "danger." This mismatch intensifies the emotional response because viewers cannot resolve the conflicting appraisals.

**Distractor Analysis:**
- **A** (Patriotism reduces anxiety) - If anything, the setting might INCREASE anxiety by threatening a cherished national symbol.
- **B** (Cognitive anchoring) - Too vague. Doesn't explain HOW the landmark affects emotional processing.
- **D** (Universal height phobia) - Acrophobia isn't universal, and this doesn't explain why Mount Rushmore specifically intensifies the response.

**Course Connection:**
- **Film:** North by Northwest - Mount Rushmore climax
- **Readings:** Gross (2015) on cognitive appraisal in emotion regulation
- **Integration:** Applies emotion theory to understand Hitchcock's filmmaking choices

---

*Last updated: January 2026*
*For Instructor Use Only*
