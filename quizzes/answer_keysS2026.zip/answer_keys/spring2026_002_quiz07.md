# PSYC 405 Section 002 - Quiz 7: Rain Man / K-PAX
## CONFIDENTIAL ANSWER KEY

---

## Quiz 7: Transition - Diagnosis and Uncertainty

---

### Question 1

**Question:** Both Raymond (Rain Man) and Prot (K-PAX) present diagnostic challenges. According to Matthews (2005), why might clinicians rationally disagree about unusual presentations?

**Answer Choices:**
- A) Psychiatric diagnosis is purely subjective
- B) Clinicians are randomly distributed in diagnostic tendencies
- C) Given ambiguous evidence, different prior beliefs (base rate expectations) lead to different rational conclusions - "weird" presentations challenge standard diagnostic inference ✓
- D) Only one diagnosis can ever be correct

**Correct Answer: C**

**Rationale for Correct Answer:**
Matthews' analysis of "rational inference from weird evidence" shows that prior beliefs (base rates) affect diagnostic conclusions. Clinicians with different priors can reach different conclusions, both rationally. For Prot: if your prior for "aliens exist" is zero, you conclude delusion; if non-zero, you might entertain alternatives. For unusual presentations, there's often no "obviously correct" answer - rational people can disagree because they weight evidence differently.

**Distractor Analysis:**
- **A** (Purely subjective) - Diagnosis involves subjective judgment but isn't arbitrary; there are rational constraints.
- **B** (Random distribution) - Disagreement reflects prior beliefs and evidence weighting, not randomness.
- **D** (Only one correct) - For ambiguous cases, "correct" may be underdetermined by available evidence.

**Course Connection:**
- **Film:** Rain Man and K-PAX - diagnostic challenges
- **Readings:** Matthews (2005) on rational inference
- **Integration:** Shows how "weird" cases challenge diagnostic certainty

---

### Question 2

**Question:** Raymond's savant abilities are genuine; Prot's claimed alien origin may or may not be delusional. According to Vrij et al. (2019), what makes distinguishing delusion from reality so difficult in Prot's case?

**Answer Choices:**
- A) Aliens might actually exist
- B) Behavioral cues cannot distinguish between sincere belief (delusion) and deliberate deception - and genuine delusion produces no "deception" cues at all ✓
- C) Psychiatrists lack training in alien detection
- D) Prot deliberately obscures diagnostic cues

**Correct Answer: B**

**Rationale for Correct Answer:**
Vrij et al.'s research shows deception detection relies on cues that are "faint and unreliable." But Prot's situation is even more complex: if he genuinely BELIEVES he's from K-PAX (delusion), he's not deceiving at all - he's sincere. Sincere delusion produces no deception cues because there's no deception. You can't detect "lies" in someone who believes what they're saying. The behavioral cues that might indicate deception simply don't appear.

**Distractor Analysis:**
- **A** (Aliens might exist) - While technically possible, this doesn't explain the diagnostic difficulty from a psychological perspective.
- **C** (Lack alien detection training) - Humorous but misses the point about sincere belief vs. deception.
- **D** (Deliberate obscuring) - If Prot is delusional, he's not deliberately obscuring anything.

**Course Connection:**
- **Film:** K-PAX - Is Prot delusional or alien?
- **Readings:** Vrij et al. (2019) on deception detection limits
- **Integration:** Applies deception research to show limitations in clinical assessment

---

### Question 3

**Question:** Both films explore how "different" minds relate to "normal" society. According to Pratto et al. (1994), how might social dominance orientation predict attitudes toward both Raymond and Prot?

**Answer Choices:**
- A) High SDO would predict acceptance of difference
- B) SDO is irrelevant to attitudes about neurodiversity
- C) High SDO correlates with preference for hierarchy; unusual minds may be seen as threats to social order or as requiring institutionalization rather than accommodation ✓
- D) Low SDO individuals reject all difference

**Correct Answer: C**

**Rationale for Correct Answer:**
Pratto et al. show that high SDO correlates with preference for established hierarchies and skepticism of those who don't fit. Both Raymond and Prot challenge normal social order - Raymond through autism, Prot through claimed alien status. High SDO orientation would predict seeing these individuals as problems to be managed (institutionalized) rather than accommodated. Low SDO would predict more acceptance of difference.

**Distractor Analysis:**
- **A** (High SDO predicts acceptance) - Opposite: high SDO correlates with hierarchy preference and skepticism of difference.
- **B** (SDO irrelevant) - SDO predicts attitudes toward many social groups including disabled individuals.
- **D** (Low SDO rejects difference) - Low SDO generally predicts more acceptance of diversity.

**Course Connection:**
- **Film:** Rain Man and K-PAX - social responses to difference
- **Readings:** Pratto et al. (1994) on SDO
- **Integration:** Applies dominance theory to attitudes about neurodiversity

---

### Question 4

**Question:** Dr. Powell (K-PAX) becomes personally invested in Prot's case. According to research on emotion differentiation (Kashdan et al., 2015), what risk does this personal investment create?

**Answer Choices:**
- A) Investment always improves clinical judgment
- B) Personal feelings have no effect on diagnosis
- C) Undifferentiated emotional investment may impair objective assessment; distinguishing professional concern from personal fascination requires high emotion differentiation ✓
- D) Only detached clinicians make accurate diagnoses

**Correct Answer: C**

**Rationale for Correct Answer:**
Kashdan et al.'s research on differentiation applies to clinicians: a clinician must distinguish between professional interest (appropriate), fascination with an unusual case (potentially distorting), rescue fantasy (countertransference), and intellectual excitement (could bias toward preferred explanation). Dr. Powell's investment creates risk because these distinct emotions might blend into undifferentiated "interest in Prot" that distorts judgment.

**Distractor Analysis:**
- **A** (Investment always improves) - Investment can bias as well as motivate; it's not uniformly positive.
- **B** (No effect) - Emotions clearly affect judgment; claiming no effect is naive.
- **D** (Only detached clinicians accurate) - Some investment is necessary for engagement; the issue is differentiated investment.

**Course Connection:**
- **Film:** K-PAX - Dr. Powell's personal investment
- **Readings:** Kashdan et al. (2015) on emotion differentiation
- **Integration:** Applies differentiation to clinical practice

---

### Question 5

**Question:** Charlie transforms from exploiting Raymond to genuinely caring for him. According to McKnight & Kashdan (2009), this transformation illustrates which characteristic of purpose as a "self-organizing system"?

**Answer Choices:**
- A) Purpose is externally imposed by circumstances
- B) Purpose creates conditions that sustain and strengthen itself - Charlie's initial positive experiences with Raymond generated further investment that became self-perpetuating ✓
- C) Purpose develops independently of experience
- D) Purpose cannot emerge from selfish beginnings

**Correct Answer: B**

**Rationale for Correct Answer:**
McKnight & Kashdan describe purpose as self-organizing - it creates conditions that sustain itself. Charlie's transformation shows this: initial positive moments with Raymond (the casino, shared jokes, physical affection) generated further investment. Each positive experience created motivation for more engagement, which created more positive experiences. Purpose didn't appear suddenly; it organized itself gradually through accumulating experiences.

**Distractor Analysis:**
- **A** (Externally imposed) - Charlie's purpose emerged from internal experience, not external imposition.
- **C** (Independent of experience) - Purpose clearly developed THROUGH experience with Raymond.
- **D** (Cannot emerge from selfishness) - Charlie's selfish start didn't prevent authentic purpose from developing.

**Course Connection:**
- **Film:** Rain Man - Charlie's character arc
- **Readings:** McKnight & Kashdan (2009) on self-organizing purpose
- **Integration:** Shows purpose development through the self-organization lens

---

*Last updated: January 2026*
*For Instructor Use Only*
