# PSYC 405 Section 002 - Quiz 4: Identity
## CONFIDENTIAL ANSWER KEY

---

## Quiz 4: Identity (2003)

---

### Question 1

**Question:** The motel guests in Identity are revealed to be Malcolm's alternate personalities. Each personality has distinct moral characteristics (prostitute, convict, actress, child). According to research on moral judgment and psychopathy (Marshall et al., 2018), what does the "murderous" personality suggest about moral understanding?

**Answer Choices:**
- A) Psychopathic traits eliminate moral understanding
- B) Multiple personalities cannot share moral knowledge
- C) Even personalities portrayed as "evil" demonstrate moral understanding - they know their actions are wrong but are unmoved by this knowledge ✓
- D) Moral judgment is irrelevant to DID

**Correct Answer: C**

**Rationale for Correct Answer:**
Marshall et al.'s meta-analysis shows that psychopaths generally UNDERSTAND moral distinctions - the deficit is in caring about them. The murderous personality in Identity knows that killing is wrong (evidenced by concealment, planning to avoid detection). The problem isn't moral knowledge but moral motivation. This distinction between moral understanding and moral motivation is crucial for both psychopathy and for understanding how "evil" can exist alongside moral awareness.

**Distractor Analysis:**
- **A** (Psychopathy eliminates understanding) - Research contradicts this; understanding is present.
- **B** (Personalities can't share knowledge) - The film actually shows personalities with apparently independent knowledge.
- **D** (Moral judgment irrelevant) - Moral functioning is highly relevant to understanding the murderous alter.

**Course Connection:**
- **Film:** Identity - The murderous personality
- **Readings:** Marshall et al. (2018) on psychopathy and moral judgment
- **Integration:** Applies moral psychology research to film character

---

### Question 2

**Question:** The psychiatrist believes that eliminating the dangerous personality will "cure" Malcolm. According to Morse (1992) on mens rea, what legal problem does Malcolm's case present?

**Answer Choices:**
- A) Insanity defenses are never valid
- B) If Malcolm cannot control which personality emerges, he may lack the "guilty mind" required for criminal responsibility - but this raises questions about which "self" is being tried ✓
- C) Multiple personalities cannot commit crimes
- D) Mental illness always eliminates criminal responsibility

**Correct Answer: B**

**Rationale for Correct Answer:**
Morse's analysis of mens rea requires that the defendant have a "guilty mind" - awareness of wrongdoing and intent to commit the act. If Malcolm's alter commits murder without "Malcolm" (the host) knowing or being able to prevent it, questions arise: Does the host have mens rea? Is the alter a separate legal entity? Can you punish one "person" for another's crime? DID cases challenge fundamental assumptions about unified selfhood underlying criminal law.

**Distractor Analysis:**
- **A** (Insanity defenses never valid) - Insanity defenses are valid legal mechanisms, just controversial and complex.
- **C** (Multiple personalities can't commit crimes) - Actions committed by alters ARE potentially criminal; the question is attribution.
- **D** (Mental illness always eliminates responsibility) - Mental illness affects but doesn't automatically eliminate responsibility.

**Course Connection:**
- **Film:** Identity - Malcolm's criminal case
- **Readings:** Morse (1992) on mens rea
- **Integration:** Applies legal theory to DID case

---

### Question 3

**Question:** The film's twist reveals that the "real" story is happening in Malcolm's mind during a competency hearing. According to Boudry et al. (2015), why do audiences initially accept the motel story as real?

**Answer Choices:**
- A) Audiences always believe what they see
- B) The motel setting is inherently believable
- C) The motel narrative satisfies cognitive expectations (linear causality, distinct characters, explicable events) more readily than the "mental" explanation ✓
- D) Film viewers suspend all critical judgment

**Correct Answer: C**

**Rationale for Correct Answer:**
Boudry et al. describe how beliefs spread partly because they fit cognitive expectations. The motel narrative works because it satisfies expectations: events have linear causality (storm traps people), characters are distinct individuals, events can be explained through normal logic. The "mental" explanation violates these expectations: causality is psychological, characters aren't really separate, events follow dream logic. We default to the explanation that fits existing schemas.

**Distractor Analysis:**
- **A** (Always believe what they see) - Audiences can be skeptical; the question is why THIS story is initially accepted.
- **B** (Motel inherently believable) - The setting isn't more believable than others; it's the narrative structure that works.
- **D** (All critical judgment suspended) - Audiences maintain some judgment; they accept the motel story because it makes sense, not because they're uncritical.

**Course Connection:**
- **Film:** Identity - narrative structure and twist
- **Readings:** Boudry et al. (2015) on cognitive expectations and belief
- **Integration:** Uses film narrative to illustrate belief formation mechanisms

---

### Question 4

**Question:** Each of Malcolm's personalities seems to have independent agency, goals, and fears. According to purpose research (Kashdan et al., 2024), can fragmented personality states have genuine purpose?

**Answer Choices:**
- A) Only integrated personalities can have purpose
- B) Dissociated states cannot have goals
- C) Purpose requires self-concordance with one's "authentic" values - fragmented states may have goals but lack the integration required for genuine purpose ✓
- D) Purpose is irrelevant to mental illness

**Correct Answer: C**

**Rationale for Correct Answer:**
Kashdan et al. emphasize self-concordance - goals aligned with one's authentic values. The film's alters have goals (survival, escape, even murder), but these goals exist within fragmented states rather than integrated identity. Genuine purpose in the McKnight & Kashdan framework requires a coherent self whose values generate self-concordant goals. Alters may have direction, but whether this constitutes PURPOSE depends on integration that Malcolm lacks.

**Distractor Analysis:**
- **A** (Only integrated have purpose) - Too absolute; some purpose-like functioning may exist, but it's incomplete.
- **B** (Dissociated states can't have goals) - The alters clearly have goals; the question is whether goals equal purpose.
- **D** (Purpose irrelevant to mental illness) - Purpose is highly relevant to recovery and well-being in mental illness.

**Course Connection:**
- **Film:** Identity - alters with apparent goals
- **Readings:** Kashdan et al. (2024) on self-concordance and purpose
- **Integration:** Tests understanding of purpose requirements

---

### Question 5

**Question:** The motel is revealed to be named after Malcolm Rivers himself. This detail suggests which psychological process?

**Answer Choices:**
- A) Random coincidence with no meaning
- B) Unconscious self-reference - even in dissociated states, the mind maintains connections to core identity ✓
- C) Deliberate choice by Malcolm's conscious mind
- D) Pure narrative convenience without psychological basis

**Correct Answer: B**

**Rationale for Correct Answer:**
The motel name reveals that even within dissociated fantasy, Malcolm's mind references his actual identity. This illustrates how the unconscious maintains connections to core self even when conscious awareness is fragmented. The detail isn't random or merely narrative convenient - it demonstrates that dissociated states remain connected to the generating mind, with identity markers leaking through. The unconscious keeps pointing toward integration even when the conscious system is fragmented.

**Distractor Analysis:**
- **A** (Random coincidence) - In psychological analysis, such details are typically meaningful, not random.
- **C** (Conscious deliberate choice) - Malcolm isn't consciously aware of his alters; this is unconscious processing.
- **D** (Narrative convenience) - While it serves the plot, it also represents genuine psychological phenomenon.

**Course Connection:**
- **Film:** Identity - the motel name detail
- **Readings:** Unconscious processing and identity
- **Integration:** Shows how unconscious self-reference operates in dissociation

---

*Last updated: January 2026*
*For Instructor Use Only*
