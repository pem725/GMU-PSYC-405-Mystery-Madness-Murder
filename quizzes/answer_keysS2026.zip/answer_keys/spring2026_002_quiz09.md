# PSYC 405 Section 002 - Quiz 9: Leaving Las Vegas
## CONFIDENTIAL ANSWER KEY

---

## Quiz 9: Leaving Las Vegas (1995)

---

### Question 1

**Question:** Ben Sanderson has made a deliberate decision to drink himself to death. According to Gross (2015), how should we understand this as an emotion regulation choice?

**Answer Choices:**
- A) Ben is successfully regulating his emotions
- B) Suicide is never related to emotion regulation
- C) Ben has abandoned adaptive regulation entirely; chronic alcohol use represents a maladaptive response-modulation strategy that provides temporary relief while ensuring long-term destruction ✓
- D) Ben's choice is purely rational without emotional components

**Correct Answer: C**

**Rationale for Correct Answer:**
Gross's framework includes response modulation - changing emotional responses after they occur. Alcohol provides temporary dampening of negative affect, making it a response-modulation strategy. However, Ben's use is so extreme it's abandoned adaptation entirely - he's not modulating to function better but to end functioning. This represents complete regulatory failure: short-term relief pursued at the cost of life itself.

**Distractor Analysis:**
- **A** (Successful regulation) - Success implies functionality; Ben is pursuing death.
- **B** (Suicide unrelated to regulation) - Suicide often relates to escape from unbearable emotional states.
- **D** (Purely rational) - Ben's choice emerges from emotional despair, not pure reason.

**Course Connection:**
- **Film:** Leaving Las Vegas - Ben's decision to drink to death
- **Readings:** Gross (2015) on response modulation
- **Integration:** Applies regulation framework to extreme case

---

### Question 2

**Question:** Sera agrees not to ask Ben to stop drinking. According to research on purpose (McKnight & Kashdan, 2009), what does this acceptance represent?

**Answer Choices:**
- A) Healthy unconditional love
- B) Standard codependency without complexity
- C) Sera's acceptance may reflect her own disrupted purpose system - lacking direction for herself, she organizes around Ben's death rather than challenging it ✓
- D) Optimal therapeutic support

**Correct Answer: C**

**Rationale for Correct Answer:**
McKnight & Kashdan describe purpose as providing direction and meaning. Sera lacks clear purpose before meeting Ben - her life as a prostitute controlled by a violent pimp offers little self-concordant direction. When Ben appears, she organizes her life around him, but this "purpose" is directed toward facilitating his death rather than preserving life. Her acceptance reflects her own purposelessness as much as love for Ben.

**Distractor Analysis:**
- **A** (Healthy love) - Facilitating death isn't healthy expression of love.
- **B** (Simple codependency) - While codependent elements exist, the purpose framework adds depth.
- **D** (Optimal support) - Supporting suicide isn't therapeutically optimal.

**Course Connection:**
- **Film:** Leaving Las Vegas - Sera's acceptance
- **Readings:** McKnight & Kashdan (2009) on purpose systems
- **Integration:** Applies purpose theory to understand Sera's choices

---

### Question 3

**Question:** Ben lost his family, his career, and his identity before the film begins. According to Kashdan et al. (2024), what does his subsequent inability to form new purpose suggest about purpose development?

**Answer Choices:**
- A) Purpose can only be developed once
- B) Career success is required for purpose
- C) Purpose requires some degree of positive emotional experience; profound anhedonia and depression may prevent the happiness that facilitates purpose formation ✓
- D) Ben has chosen purpose-rejection deliberately

**Correct Answer: C**

**Rationale for Correct Answer:**
Kashdan et al.'s work on purpose connects to McKnight et al. (2025) findings that happiness may facilitate purpose. Ben's profound depression and anhedonia (inability to experience pleasure) may prevent the positive emotional experiences needed to develop new purpose. He can't rebuild because he can't experience the positive emotions that would make rebuilding feel worthwhile. The emotional foundation for purpose is absent.

**Distractor Analysis:**
- **A** (Only developed once) - People can develop new purpose after loss; Ben's case is extreme.
- **B** (Career required) - Purpose can develop outside career contexts.
- **D** (Deliberate rejection) - Ben's inability seems driven by depression, not philosophical rejection.

**Course Connection:**
- **Film:** Leaving Las Vegas - Ben's inability to rebuild
- **Readings:** Kashdan et al. (2024); McKnight et al. (2025)
- **Integration:** Uses Ben's case to explore purpose-happiness connection

---

### Question 4

**Question:** The film refuses to offer hope for Ben's recovery. According to Boudry & Braeckman (2012), why might audiences find this refusal uncomfortable despite its realism?

**Answer Choices:**
- A) Audiences are inherently optimistic
- B) The film is poorly made
- C) We have self-validating beliefs about redemption narratives; stories without hope violate these schemas and create cognitive dissonance ✓
- D) All films should have happy endings

**Correct Answer: C**

**Rationale for Correct Answer:**
Boudry & Braeckman describe how cultural belief systems resist disconfirmation. Western culture has strong redemption schemas: people should be redeemable, love should save, rock bottom leads to recovery. The film violates these expectations, creating cognitive dissonance. Audiences hold self-validating beliefs that stories SHOULD offer hope; when they don't, the discomfort isn't just about the characters but about challenged beliefs.

**Distractor Analysis:**
- **A** (Inherent optimism) - Too general; the mechanism involves specific cultural narratives.
- **B** (Poorly made) - The film is critically acclaimed; the discomfort is intentional.
- **D** (Should have happy endings) - This is a prescription, not an explanation of psychological mechanism.

**Course Connection:**
- **Film:** Leaving Las Vegas - Refusal of redemption
- **Readings:** Boudry & Braeckman (2012) on self-validating beliefs
- **Integration:** Applies belief theory to audience response

---

### Question 5

**Question:** Ben and Sera form a genuine connection despite his self-destruction. According to emotion differentiation research (Kashdan et al., 2015), what does their relationship suggest about intimacy and emotional granularity?

**Answer Choices:**
- A) True connection requires sobriety
- B) Their relationship is not genuine
- C) Moments of differentiated emotional experience (tenderness, gratitude, acceptance) can exist alongside chronic dysregulation - connection does not require overall emotional health ✓
- D) Alcoholism enhances emotional connection

**Correct Answer: C**

**Rationale for Correct Answer:**
Kashdan et al.'s differentiation research suggests that emotional granularity isn't all-or-nothing. Ben, despite massive dysregulation, can still experience differentiated moments: tenderness toward Sera, gratitude for acceptance, genuine connection. These differentiated moments enable real intimacy even amid chaos. The relationship is genuine not because Ben is healthy but because moments of genuine emotional clarity punctuate the dysfunction.

**Distractor Analysis:**
- **A** (Requires sobriety) - Ben and Sera's connection suggests otherwise.
- **B** (Not genuine) - The film portrays their connection as authentic despite dysfunction.
- **D** (Alcoholism enhances) - Alcoholism destroys more than it enables; the connection exists despite, not because of, addiction.

**Course Connection:**
- **Film:** Leaving Las Vegas - Ben and Sera's relationship
- **Readings:** Kashdan et al. (2015) on emotion differentiation
- **Integration:** Shows differentiation can exist amid overall dysregulation

---

*Last updated: January 2026*
*For Instructor Use Only*
