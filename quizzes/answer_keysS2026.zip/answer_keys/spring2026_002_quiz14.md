# PSYC 405 Section 002 - Quiz 14: Final Reflection
## CONFIDENTIAL ANSWER KEY

---

## Quiz 14: Final Reflection - What Did You Learn?

---

### Question 1

**Question:** A colleague claims they can reliably detect when patients are lying based on body language. Based on Vrij et al. (2019) and the course material, what is the most scientifically accurate response?

**Answer Choices:**
- A) Support their confidence - clinical experience develops this skill
- B) Express skepticism - nonverbal deception cues are "faint and unreliable," and training does not significantly improve detection accuracy ✓
- C) Recommend they take a lie detection course to improve further
- D) Accept that some individuals have innate lie detection ability

**Correct Answer: B**

**Rationale for Correct Answer:**
Vrij et al.'s meta-analysis directly addresses this: detection accuracy is near chance (54%) regardless of training or experience. The colleague's confidence is unjustified by research. Clinical experience may increase CONFIDENCE without increasing ACCURACY - a dangerous combination. Nonverbal cues are "faint and unreliable," and no evidence supports innate superior detection ability or skill development through training.

**Distractor Analysis:**
- **A** (Experience develops skill) - Research contradicts this; experience increases confidence, not accuracy.
- **C** (Recommend training) - Training doesn't significantly improve detection accuracy.
- **D** (Innate ability) - No evidence for individuals with reliably superior detection.

**Course Connection:**
- **Film:** Primal Fear, K-PAX - detection failures
- **Readings:** Vrij et al. (2019)
- **Integration:** Applies research to real-world clinical practice

---

### Question 2

**Question:** A friend expresses frustration that their search for "purpose" hasn't made them happier. Based on McKnight et al. (2025), what empirically-supported advice would you offer?

**Answer Choices:**
- A) Search harder for the right purpose
- B) Purpose and happiness are unrelated
- C) Consider that the causal direction may be reversed - cultivating positive experiences might facilitate purpose development more effectively than directly pursuing purpose ✓
- D) Accept that some people cannot have purpose

**Correct Answer: C**

**Rationale for Correct Answer:**
McKnight et al. (2025) found that happiness at Time 1 predicted purpose at Time 2, but not vice versa. This suggests the friend may be searching in the wrong direction: directly pursuing purpose may be less effective than cultivating positive emotional experiences that then facilitate purpose development. The research supports trying happiness-promoting activities first, with purpose potentially emerging from those experiences.

**Distractor Analysis:**
- **A** (Search harder) - If the direction is reversed, more searching won't help.
- **B** (Unrelated) - The research shows they ARE related; the question is about direction.
- **D** (Some can't have purpose) - The research doesn't support this conclusion.

**Course Connection:**
- **Film:** Multiple character arcs
- **Readings:** McKnight et al. (2025)
- **Integration:** Applies research to personal advice

---

### Question 3

**Question:** You notice that an intelligent friend maintains a belief that contradicts scientific consensus. Based on Shermer (2002) and Boudry & Braeckman (2012), which approach is LEAST likely to change their mind?

**Answer Choices:**
- A) Understanding the emotional needs the belief serves
- B) Exploring what evidence would convince them they were wrong
- C) Presenting more facts contradicting their belief - self-validating belief systems reinterpret contradictory evidence as confirmation ✓
- D) Discussing the belief's origins and development

**Correct Answer: C**

**Rationale for Correct Answer:**
This is a "least likely" question testing understanding of why fact-bombing fails. Boudry & Braeckman's central insight is that self-validating beliefs REINTERPRET contradictory evidence as support. More facts don't help; they feed the system. Options A, B, and D might work by addressing the belief's function (A), testing falsifiability (B), or understanding its origins (D). Only C directly feeds the self-validating cycle.

**Distractor Analysis:**
- **A** (Emotional needs) - MIGHT help by addressing underlying motivations.
- **B** (Falsifiability) - MIGHT help by testing whether belief is even disprovable.
- **D** (Origins) - MIGHT help by revealing how belief was acquired.

**Course Connection:**
- **Film:** Multiple characters with resistant beliefs
- **Readings:** Shermer (2002); Boudry & Braeckman (2012)
- **Integration:** Applies belief research to interpersonal influence

---

### Question 4

**Question:** Based on emotion regulation research (Gross, 2015; Kashdan et al., 2015; Kalokerinos et al., 2019), which sequence represents the most adaptive response to overwhelming negative experience?

**Answer Choices:**
- A) Suppress → Avoid → Reappraise
- B) Act immediately → Reflect later → Repeat
- C) Differentiate (identify specific emotions) → Select appropriate strategy → Implement flexibly ✓
- D) Reappraise everything → Never experience negative emotion

**Correct Answer: C**

**Rationale for Correct Answer:**
The research synthesis suggests: First, differentiate - identify WHAT specifically you're feeling (Kashdan et al.). Then, select strategy - choose the appropriate regulation approach for that specific emotion (Gross). Finally, implement flexibly - adapt based on context and effectiveness (Kalokerinos et al.). This sequence respects the research showing that differentiation must precede effective strategy selection and implementation.

**Distractor Analysis:**
- **A** (Suppress → Avoid → Reappraise) - Order is wrong; suppression is generally least effective.
- **B** (Act → Reflect → Repeat) - Acting without differentiation can worsen problems.
- **D** (Reappraise everything) - Rigid reappraisal isn't always appropriate; flexibility is key.

**Course Connection:**
- **Film:** Characters with effective vs. ineffective regulation
- **Readings:** Gross (2015); Kashdan et al. (2015); Kalokerinos et al. (2019)
- **Integration:** Synthesizes regulation research into actionable sequence

---

### Question 5

**Question:** The course analyzed fictional portrayals alongside empirical research. What is the BEST reason for this approach?

**Answer Choices:**
- A) Fiction is always psychologically accurate
- B) Research findings are too abstract without illustration
- C) Entertainment value increases student engagement
- D) Comparing dramatized portrayals to scientific evidence develops critical evaluation skills and illuminates both accurate representation and common misconceptions about psychological phenomena ✓

**Correct Answer: D**

**Rationale for Correct Answer:**
The course's pedagogical value comes from COMPARISON. By analyzing fictional portrayals against empirical research, students develop: (1) critical evaluation skills - learning to assess accuracy claims, (2) understanding of accurate representation - seeing where fiction gets it right, and (3) awareness of misconceptions - recognizing where popular understanding diverges from science. The gap between fiction and research is itself instructive.

**Distractor Analysis:**
- **A** (Fiction always accurate) - The course showed fiction is often inaccurate; that's part of the point.
- **B** (Research too abstract) - While true, this misses the CRITICAL EVALUATION component.
- **C** (Entertainment increases engagement) - While true, engagement isn't the primary learning objective.

**Course Connection:**
- **Film:** Course methodology
- **Readings:** Course synthesis
- **Integration:** Articulates the course's pedagogical rationale

---

*Last updated: January 2026*
*For Instructor Use Only*
