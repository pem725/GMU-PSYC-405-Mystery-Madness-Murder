# PSYC 405 Section 001 - Quiz 7: Black Swan / Good Will Hunting
## CONFIDENTIAL ANSWER KEY

---

## Quiz 7: Transition - Madness and Therapy

---

### Question 1

**Question:** Both Nina Sayers and Will Hunting experience profound resistance to authentic emotional connection. According to Gross (2015), how do their primary emotion regulation strategies differ?

**Answer Choices:**
- A) Both primarily use cognitive reappraisal
- B) Nina suppresses while Will reappraises
- C) Nina uses maladaptive situation selection (isolation, control) while Will uses maladaptive response modulation (aggression, withdrawal) ✓
- D) Will suppresses while Nina floods

**Correct Answer: C**

**Rationale for Correct Answer:**
Gross's process model distinguishes WHERE in the emotion generation sequence regulation occurs. Nina regulates early through situation selection - she controls her environment obsessively, isolates from spontaneous social contact, and avoids any situation that might produce unexpected emotions. Will regulates late through response modulation - he allows situations to occur but then modulates his response through aggression (picking fights) or withdrawal (pushing people away). Same goal (avoiding vulnerability), different mechanisms.

**Distractor Analysis:**
- **A** (Both use reappraisal) - Neither primarily uses cognitive reappraisal. Reappraisal would involve changing the meaning of situations, not avoiding them or attacking.
- **B** (Nina suppresses, Will reappraises) - Will doesn't show much reappraisal; his "not your fault" breakthrough wouldn't be necessary if he were successfully reappraising.
- **D** (Will suppresses, Nina floods) - Nina doesn't flood; she maintains rigid control until she breaks down.

**Course Connection:**
- **Film:** Black Swan and Good Will Hunting - Nina's and Will's defensive patterns
- **Readings:** Gross (2015) on the process model of emotion regulation
- **Integration:** Compares two characters using the same theoretical framework to highlight different pathways to similar outcomes

---

### Question 2

**Question:** Nina's transformation occurs through art; Will's through therapy. McKnight & Kashdan (2009) propose that purpose functions as a "self-organizing system." What does the contrast between these characters reveal about purpose development?

**Answer Choices:**
- A) Artistic purpose is superior to interpersonal purpose
- B) Purpose can only develop through professional achievement
- C) Therapy is ineffective for purpose development
- D) Purpose requires integration of multiple life domains; Nina's exclusive focus on ballet and Will's avoidance of intimacy both represent fragmented rather than integrated purpose ✓

**Correct Answer: D**

**Rationale for Correct Answer:**
McKnight & Kashdan describe purpose as a self-organizing system that coordinates multiple life domains. Neither Nina nor Will has integrated purpose. Nina's purpose is exclusively artistic - she has no interpersonal purpose, no identity outside ballet. Will has intellectual gifts but avoids relationships that would give his abilities meaning. Both represent fragmented purpose that can't fully organize their lives because key domains are excluded.

**Distractor Analysis:**
- **A** (Artistic superior to interpersonal) - The framework doesn't rank purpose types; it emphasizes integration across domains.
- **B** (Only professional achievement) - Purpose can develop in any domain; professional achievement isn't privileged.
- **C** (Therapy ineffective) - Will's transformation through therapy contradicts this claim directly.

**Course Connection:**
- **Film:** Black Swan and Good Will Hunting - contrasting transformations
- **Readings:** McKnight & Kashdan (2009) on purpose as self-organizing system
- **Integration:** Uses two films to illustrate integrated vs. fragmented purpose

---

### Question 3

**Question:** Sean Maguire tells Will "It's not your fault" repeatedly until Will breaks down. From an emotion differentiation perspective (Kashdan et al., 2015), why is this intervention effective?

**Answer Choices:**
- A) Repetition overwhelms cognitive defenses
- B) Sean's authority makes the message believable
- C) The intervention helps Will differentiate between shame (deserved) and guilt (undeserved), enabling more adaptive emotional processing ✓
- D) Simple messages are easier to accept than complex ones

**Correct Answer: C**

**Rationale for Correct Answer:**
Will's undifferentiated negative affect includes both shame (I am bad) and guilt (I did something bad). But his guilt is misplaced - he didn't CAUSE his abuse. Sean's intervention helps Will differentiate: he can release the guilt (undeserved) while processing the shame (his identity formed under abuse). This differentiation enables more targeted emotional processing than the undifferentiated "I am damaged" belief he carried.

**Distractor Analysis:**
- **A** (Repetition overwhelms defenses) - Repetition alone doesn't produce therapeutic change. It's the CONTENT being repeated that matters.
- **B** (Sean's authority) - Will doesn't respect authority generally. His relationship with Sean is based on mutual respect, not authority.
- **D** (Simple messages easier) - The message is simple but the processing isn't. The intervention works because of differentiation, not simplicity.

**Course Connection:**
- **Film:** Good Will Hunting - Sean's therapeutic breakthrough
- **Readings:** Kashdan et al. (2015) on emotion differentiation
- **Integration:** Applies differentiation research to understand therapeutic change

---

### Question 4

**Question:** Thomas Leroy sexually manipulates Nina while claiming to help her artistry. What concept from social dominance theory (Pratto et al., 1994) best explains the power dynamic?

**Answer Choices:**
- A) Out-group derogation
- B) System justification theory
- C) Realistic group conflict
- D) Legitimizing exploitation through hierarchy-maintaining myths about artistic necessity ✓

**Correct Answer: D**

**Rationale for Correct Answer:**
Pratto et al. describe how "legitimizing myths" justify hierarchical exploitation. Thomas uses the myth that artistic greatness requires suffering and sexual awakening to justify his exploitation of Nina. The ballet hierarchy (director over dancer) is maintained through beliefs about what artistic development "requires." Nina accepts the exploitation because the myth frames it as necessary for her art, not as abuse.

**Distractor Analysis:**
- **A** (Out-group derogation) - There's no out-group here; Nina and Thomas are in the same artistic community.
- **B** (System justification) - This is about why people support systems that disadvantage them, but doesn't capture the specific exploitation mechanism.
- **C** (Realistic group conflict) - No intergroup conflict is involved in this dyadic exploitation.

**Course Connection:**
- **Film:** Black Swan - Thomas's manipulation of Nina
- **Readings:** Pratto et al. (1994) on legitimizing myths and hierarchy
- **Integration:** Applies social dominance theory to understand interpersonal exploitation

---

### Question 5

**Question:** Will's genius makes him valuable to institutions (MIT, NSA) that want to use his abilities. Nina's talent makes her valuable to the ballet company. According to research on purpose (Kashdan et al., 2024), what distinguishes authentic purpose from instrumental use?

**Answer Choices:**
- A) Authentic purpose requires financial independence
- B) External recognition invalidates internal purpose
- C) Authentic purpose involves self-concordance - goals aligned with one's own values rather than imposed by external systems ✓
- D) Purpose cannot develop within institutional contexts

**Correct Answer: C**

**Rationale for Correct Answer:**
Kashdan et al. (2024) emphasize self-concordance - the alignment between one's goals and one's authentic values. Both Will and Nina are being used by institutions that value their abilities for the institution's purposes. Authentic purpose would involve THEM choosing goals that align with THEIR values. Will begins moving toward self-concordance when he chooses Skylar over NSA career paths. Nina never achieves self-concordance because her goals remain her mother's and Thomas's, not her own.

**Distractor Analysis:**
- **A** (Financial independence required) - Purpose can exist regardless of financial status. The key is value alignment, not financial freedom.
- **B** (External recognition invalidates) - Recognition doesn't invalidate purpose; it's whether the goal itself is self-chosen that matters.
- **D** (Purpose can't develop institutionally) - Purpose can develop within institutions if the individual's values align with institutional goals authentically.

**Course Connection:**
- **Film:** Black Swan and Good Will Hunting - institutional use of talent
- **Readings:** Kashdan et al. (2024) on self-concordance and purpose
- **Integration:** Distinguishes external use of abilities from authentic purpose development

---

*Last updated: January 2026*
*For Instructor Use Only*
