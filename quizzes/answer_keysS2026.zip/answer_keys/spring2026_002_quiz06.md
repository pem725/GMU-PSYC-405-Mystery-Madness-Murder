# PSYC 405 Section 002 - Quiz 6: Rain Man
## CONFIDENTIAL ANSWER KEY

---

## Quiz 6: Rain Man (1988) - Part I

---

### Question 1

**Question:** Rain Man was released in 1988. Since then, our understanding of autism has shifted from viewing it as a single condition to understanding it as a spectrum. What does this change in diagnostic thinking illustrate about belief in science (Boudry et al., 2015)?

**Answer Choices:**
- A) Science never changes its mind
- B) Earlier researchers were incompetent
- C) Scientific beliefs are updated through systematic evidence accumulation; the "epidemiology" of scientific beliefs differs from pseudoscience by being responsive to disconfirmation ✓
- D) The autism spectrum is a pseudoscientific concept

**Correct Answer: C**

**Rationale for Correct Answer:**
Boudry et al. distinguish scientific from pseudoscientific beliefs partly by responsiveness to evidence. The shift from "autism" to "autism spectrum disorder" illustrates science updating its beliefs based on accumulated evidence: research showed autism presentations vary widely, so diagnostic concepts evolved. This contrasts with pseudoscientific beliefs that resist revision. Science changes; that's a feature, not a bug.

**Distractor Analysis:**
- **A** (Science never changes) - The autism example directly shows science changing.
- **B** (Earlier researchers incompetent) - They were working with available evidence; progress isn't about incompetence.
- **D** (Autism spectrum is pseudoscience) - The spectrum concept emerged from rigorous research; it's scientific.

**Course Connection:**
- **Film:** Rain Man - historical portrayal of autism
- **Readings:** Boudry et al. (2015) on scientific vs. pseudoscientific belief
- **Integration:** Uses diagnostic evolution to illustrate scientific belief dynamics

---

### Question 2

**Question:** Raymond demonstrates both severe social impairments and remarkable savant abilities. According to research on emotion (Feldman Barrett et al., 2001), how should we understand Raymond's emotional experience?

**Answer Choices:**
- A) Raymond has no emotional experience
- B) Raymond's emotions are identical to neurotypical experience
- C) Raymond likely experiences emotions but may process and express them differently; emotional differentiation may follow different developmental patterns in autism ✓
- D) Savant abilities eliminate emotion

**Correct Answer: C**

**Rationale for Correct Answer:**
Feldman Barrett's research on emotional experience emphasizes that emotion involves construction, not just recognition. People with autism often experience emotions but may process, differentiate, and express them differently. Raymond shows distress (when routines are broken), comfort (with Charlie by the end), and fear (of airplanes). His emotions are real but follow different expression patterns. Savant abilities have no relationship to emotional capacity.

**Distractor Analysis:**
- **A** (No emotional experience) - Raymond clearly shows emotional reactions throughout the film.
- **B** (Identical to neurotypical) - His expression and possibly processing differ; not identical.
- **D** (Savant abilities eliminate emotion) - No connection between savant skills and emotional capacity.

**Course Connection:**
- **Film:** Rain Man - Raymond's emotional functioning
- **Readings:** Feldman Barrett et al. (2001) on emotion construction
- **Integration:** Applies emotion theory to understand autism

---

### Question 3

**Question:** Charlie initially views Raymond as a means to access his inheritance. According to McKnight et al. (2025), what does the transformation in Charlie's motivation suggest about the relationship between purpose and happiness?

**Answer Choices:**
- A) Purpose always precedes positive emotional experience
- B) Charlie never develops genuine purpose regarding Raymond
- C) Positive emotional experiences with Raymond may have preceded and facilitated Charlie's developing sense of caring purpose ✓
- D) Money eliminates the possibility of purpose

**Correct Answer: C**

**Rationale for Correct Answer:**
McKnight et al. (2025) found happiness predicting subsequent purpose. Charlie's transformation fits this: his positive emotional experiences with Raymond (moments of connection, shared humor, growing affection) preceded his development of caring purpose. He didn't decide to care and then feel positive; he felt positive connections and then began caring. The happiness came first, facilitating purpose development.

**Distractor Analysis:**
- **A** (Purpose precedes happiness) - McKnight et al. found the opposite direction.
- **B** (Never develops purpose) - Charlie clearly transforms from exploiting to genuinely caring.
- **D** (Money eliminates purpose) - Charlie's initial money motivation transforms; money doesn't permanently block purpose.

**Course Connection:**
- **Film:** Rain Man - Charlie's transformation
- **Readings:** McKnight et al. (2025) on happiness-purpose direction
- **Integration:** Uses Charlie's arc to illustrate research findings

---

### Question 4

**Question:** The film emphasizes Raymond's routines (specific TV shows, food, bedtime). According to emotion regulation research (Gross, 2015), what function do these routines serve?

**Answer Choices:**
- A) They are meaningless behaviors without function
- B) They indicate low intelligence
- C) Routines represent situation selection - creating predictable environments that reduce anxiety by minimizing uncertainty and unexpected emotional demands ✓
- D) They are designed to irritate caregivers

**Correct Answer: C**

**Rationale for Correct Answer:**
Gross's situation selection involves choosing environments that regulate emotional responses. Raymond's routines create maximum predictability, minimizing unexpected events that would trigger distress. This is adaptive situation selection: he creates a psychological environment he can manage. When routines are disrupted (wrong airline, different underwear), he shows distress because his situation-selection strategy has failed.

**Distractor Analysis:**
- **A** (Meaningless) - The routines clearly serve emotional regulation function.
- **B** (Low intelligence) - Routines are unrelated to intelligence; Raymond shows savant abilities.
- **D** (Designed to irritate) - Routines serve Raymond's needs, not relational manipulation.

**Course Connection:**
- **Film:** Rain Man - Raymond's routines
- **Readings:** Gross (2015) on situation selection
- **Integration:** Applies regulation theory to autism-related behavior

---

### Question 5

**Question:** Raymond's father left his fortune to Raymond rather than Charlie. According to Boudry & Braeckman (2012), why might Charlie have initially constructed a narrative of injustice despite evidence that his father's decision was protective?

**Answer Choices:**
- A) Charlie is inherently irrational
- B) Inheritance disputes always cause irrationality
- C) Self-validating beliefs about unfair treatment are psychologically protective; reinterpreting the decision as unjust preserves Charlie's self-concept ✓
- D) Charlie's narrative was actually correct

**Correct Answer: C**

**Rationale for Correct Answer:**
Boudry & Braeckman describe how beliefs can be self-validating when they serve psychological functions. Charlie's "I was cheated" narrative protects his self-concept: if the decision was unjust, then Charlie is a victim, not a person his father didn't trust. The alternative - that his father recognized he wasn't trustworthy with an inheritance - threatens self-concept. The injustice narrative is self-validating because it preserves positive self-view.

**Distractor Analysis:**
- **A** (Inherently irrational) - Charlie's reasoning is motivated, not simply irrational.
- **B** (Inheritance always causes irrationality) - Too general; the mechanism is psychological protection.
- **D** (Narrative actually correct) - The film suggests the father was trying to protect Raymond.

**Course Connection:**
- **Film:** Rain Man - Charlie's initial grievance
- **Readings:** Boudry & Braeckman (2012) on self-validating beliefs
- **Integration:** Applies belief theory to family dynamics

---

*Last updated: January 2026*
*For Instructor Use Only*
