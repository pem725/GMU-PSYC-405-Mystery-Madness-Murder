# PSYC 405 Section 002 - Quiz 2: The Machinist
## CONFIDENTIAL ANSWER KEY

---

## Quiz 2: The Machinist (2004) - Part I

---

### Question 1

**Question:** Trevor Reznik has not slept for a year, and his body shows extreme physical deterioration. According to research on sleep deprivation and psychosis, which cognitive process is most impaired by prolonged insomnia?

**Answer Choices:**
- A) Long-term memory storage
- B) Basic motor function
- C) Reality monitoring - the ability to distinguish internally generated experiences from external events ✓
- D) Language production

**Correct Answer: C**

**Rationale for Correct Answer:**
Sleep deprivation research shows that reality monitoring is particularly vulnerable to sleep loss. Reality monitoring is the cognitive process that distinguishes between what we imagined, dreamed, or thought versus what actually happened externally. Trevor's hallucinations of Ivan represent failed reality monitoring - he cannot distinguish between internal mental creations and external reality. This is why sleep deprivation can produce psychotic-like symptoms.

**Distractor Analysis:**
- **A** (Long-term memory) - Sleep affects memory consolidation, but this isn't the central cognitive failure shown.
- **B** (Motor function) - Trevor maintains motor skills enough to work; motor function is impaired but not the primary deficit.
- **D** (Language production) - Trevor communicates effectively; language production is relatively preserved.

**Course Connection:**
- **Film:** The Machinist - Trevor's psychotic symptoms
- **Readings:** Sleep deprivation and reality testing research
- **Integration:** Applies cognitive neuroscience to understand film's portrayal of insomnia effects

---

### Question 2

**Question:** Trevor creates "Ivan" as an external figure who embodies his repressed guilt. According to Gross (2015), which emotion regulation strategy does this externalization represent?

**Answer Choices:**
- A) Cognitive reappraisal (reinterpreting the meaning of events)
- B) Response modulation (suppressing emotional expression)
- C) Situation selection gone pathological - creating an alternative psychological "situation" to avoid the actual one ✓
- D) Attentional deployment (focusing attention away from distress)

**Correct Answer: C**

**Rationale for Correct Answer:**
Gross's process model identifies situation selection as the earliest point of emotion regulation. Trevor's creation of Ivan represents an extreme, pathological form of situation selection - rather than selecting which REAL situations to enter, he creates an entirely alternative psychological reality. Ivan IS the situation; by focusing on the external threat of Ivan, Trevor avoids the internal situation of his guilt. This is situation construction, not just selection.

**Distractor Analysis:**
- **A** (Reappraisal) - Reappraisal would change interpretation of EXISTING events; Trevor creates NEW events.
- **B** (Response modulation) - This operates after emotion is generated; Trevor's mechanism operates earlier.
- **D** (Attentional deployment) - Redirecting attention within a situation; Trevor constructs a new situation entirely.

**Course Connection:**
- **Film:** The Machinist - Trevor's creation of Ivan
- **Readings:** Gross (2015) on emotion regulation strategies
- **Integration:** Extends the process model to extreme/pathological regulation

---

### Question 3

**Question:** The film reveals that Trevor killed a child in a hit-and-run accident. His subsequent guilt manifests as elaborate delusion rather than conscious memory. According to Boudry & Braeckman (2012), why might the unconscious mind construct such elaborate alternative realities?

**Answer Choices:**
- A) Delusions are random products of brain dysfunction
- B) Self-validating belief systems can serve protective functions, allowing the mind to process unbearable truth through symbolic displacement ✓
- C) Guilt always produces delusions
- D) The unconscious mind seeks entertainment

**Correct Answer: B**

**Rationale for Correct Answer:**
Boudry & Braeckman describe how belief systems resist disconfirmation. Trevor's delusion is a self-validating belief system that serves protective functions - it allows him to process guilt symbolically (through Ivan, the mysterious threat) without consciously acknowledging the unbearable truth. The delusion explains his distress without requiring him to accept responsibility. It's psychologically protective even while being pathological.

**Distractor Analysis:**
- **A** (Random dysfunction) - The delusion has psychological meaning and function; it's not random.
- **C** (Guilt always produces delusions) - Most guilt doesn't produce delusions; this is an extreme case.
- **D** (Unconscious seeks entertainment) - Anthropomorphizes the unconscious without explanatory value.

**Course Connection:**
- **Film:** The Machinist - Trevor's guilt delusion
- **Readings:** Boudry & Braeckman (2012) on self-validating beliefs
- **Integration:** Applies belief theory to understand defensive delusions

---

### Question 4

**Question:** Trevor interprets random events (a hangman game, license plates) as meaningful messages. This pattern represents which cognitive phenomenon relevant to belief formation?

**Answer Choices:**
- A) Normal pattern recognition
- B) Apophenia - perceiving meaningful connections in random information, enhanced by emotional distress and sleep deprivation ✓
- C) Superior intelligence detecting hidden patterns
- D) Deliberate self-deception

**Correct Answer: B**

**Rationale for Correct Answer:**
Apophenia is the tendency to perceive meaningful patterns in random data. Trevor's interpretation of the hangman game, license plates, and other coincidences as meaningful messages reflects heightened apophenia, which is exacerbated by both emotional distress and sleep deprivation. His mind is seeking explanation for his diffuse sense of wrongness, and it finds "messages" everywhere - but these connections are created by his mind, not detected in reality.

**Distractor Analysis:**
- **A** (Normal pattern recognition) - The patterns Trevor sees aren't real; this is pathological, not normal.
- **C** (Superior intelligence) - Trevor isn't detecting real patterns through intelligence; he's creating false patterns.
- **D** (Deliberate self-deception) - Apophenia is unconscious, not deliberate.

**Course Connection:**
- **Film:** The Machinist - Trevor's pattern seeking
- **Readings:** Shermer and belief formation research
- **Integration:** Applies cognitive research on pattern perception to film

---

### Question 5

**Question:** According to emotion differentiation research (Kashdan et al., 2015), Trevor's inability to identify the source of his distress represents which deficit?

**Answer Choices:**
- A) Emotional flooding that overwhelms processing capacity
- B) Alexithymia (inability to identify emotions)
- C) Low emotion differentiation - experiencing undifferentiated negative affect without distinguishing guilt, fear, shame, and anxiety ✓
- D) Complete emotional numbing

**Correct Answer: C**

**Rationale for Correct Answer:**
Trevor experiences intense negative affect but cannot identify its source or distinguish its components. Is it guilt? Fear? Shame? Anxiety? His inability to differentiate these distinct emotions prevents him from addressing the actual cause (guilt about the hit-and-run). Low differentiation leads to undifferentiated coping - he addresses "something wrong" rather than the specific emotion, which is why his regulation attempts fail.

**Distractor Analysis:**
- **A** (Flooding) - Flooding implies overwhelming intensity; Trevor shows more confusion than overwhelm.
- **B** (Alexithymia) - Related but alexithymia is difficulty identifying ANY emotion; Trevor clearly has emotional experience.
- **D** (Complete numbing) - Trevor shows emotional reactivity; he's not numb.

**Course Connection:**
- **Film:** The Machinist - Trevor's undifferentiated distress
- **Readings:** Kashdan et al. (2015) on emotion differentiation
- **Integration:** Applies differentiation research to explain Trevor's psychological state

---

*Last updated: January 2026*
*For Instructor Use Only*
