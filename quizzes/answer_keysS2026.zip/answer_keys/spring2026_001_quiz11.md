# PSYC 405 Section 001 - Quiz 11: Primal Fear / The Hurricane
## CONFIDENTIAL ANSWER KEY

---

## Quiz 11: Transition - Justice and Deception

---

### Question 1

**Question:** Aaron Stampler deceives everyone; Rubin Carter is deceived BY the system. According to Vrij et al. (2019), what do these cases together suggest about institutional deception detection?

**Answer Choices:**
- A) Legal systems are excellent at detecting individual deception
- B) Institutions cannot be deceived
- C) Neither individuals nor institutions reliably detect deception; the direction of deception (perpetrator vs. victim) does not predict detection accuracy ✓
- D) Only psychopaths can deceive institutions

**Correct Answer: C**

**Rationale for Correct Answer:**
The two cases together illustrate that deception detection fails regardless of direction. Aaron (guilty) successfully deceives the system claiming innocence. The witnesses against Carter (lying) successfully deceive the system to convict an innocent man. Vrij et al.'s finding that detection accuracy is near chance applies to both scenarios. Institutions don't detect deception better than individuals, and being on the "right side" doesn't improve detection.

**Distractor Analysis:**
- **A** (Legal systems excel at detection) - Both films contradict this directly. Aaron fools the system; false witnesses fool the system against Carter.
- **B** (Institutions can't be deceived) - The Carter case shows institutions CAN be deceived through false testimony.
- **D** (Only psychopaths deceive) - Carter's accusers weren't psychopaths; they were ordinary people who lied successfully.

**Course Connection:**
- **Film:** Primal Fear and The Hurricane - contrasting justice failures
- **Readings:** Vrij et al. (2019) on deception detection
- **Integration:** Uses two films to illustrate bidirectional deception detection failures

---

### Question 2

**Question:** Martin Vail discovers he was manipulated after the verdict is final. Rubin Carter knew he was being manipulated but was powerless to stop it. According to research on belief perseverance (Boudry & Braeckman, 2012), why did both men initially fail to recognize the truth?

**Answer Choices:**
- A) Intelligence does not protect against deception
- B) Emotional investment prevented objective evaluation
- C) Both operated within self-validating belief systems - Vail's about his client, Carter's accusers' about his guilt - that reinterpreted contradictory evidence to confirm existing beliefs ✓
- D) The legal system prevented truth-seeking

**Correct Answer: C**

**Rationale for Correct Answer:**
Boudry & Braeckman's framework explains both cases. Vail's belief in Aaron's innocence became self-validating - Aaron's consistent performance reinforced the belief, and any inconsistencies were interpreted as trauma symptoms. Carter's accusers held self-validating beliefs about his guilt - his race, reputation, and presence near the scene confirmed their expectations. Both belief systems processed contradictory evidence as confirmation.

**Distractor Analysis:**
- **A** (Intelligence doesn't protect) - True but doesn't explain the specific mechanism of belief maintenance.
- **B** (Emotional investment) - Partially correct but doesn't capture the SELF-VALIDATING nature of the beliefs.
- **D** (Legal system prevented truth) - The system was used, but the psychological mechanism was belief perseverance.

**Course Connection:**
- **Film:** Primal Fear and The Hurricane - different deception victims
- **Readings:** Boudry & Braeckman (2012) on self-validating beliefs
- **Integration:** Shows how the same psychological mechanism operates in different justice contexts

---

### Question 3

**Question:** Primal Fear depicts a guilty person escaping justice; The Hurricane depicts an innocent person denied justice. According to Diamond (1961) on criminal responsibility, what fundamental challenge does this contrast illustrate?

**Answer Choices:**
- A) The insanity defense should be abolished
- B) Mental illness always leads to injustice
- C) The legal system must balance two types of errors - convicting the innocent and acquitting the guilty - and mental illness complicates both determinations ✓
- D) Criminal responsibility can be objectively determined

**Correct Answer: C**

**Rationale for Correct Answer:**
Diamond's analysis of criminal responsibility acknowledges that legal systems must balance Type I errors (convicting innocents) against Type II errors (acquitting the guilty). Both films show these errors occurring: Aaron exploits mental illness claims to avoid accountability (Type II error); Carter is convicted despite innocence (Type I error). Mental illness complicates both because it's difficult to assess and can be feigned or ignored.

**Distractor Analysis:**
- **A** (Abolish insanity defense) - This wouldn't solve either problem and isn't supported by the films.
- **B** (Mental illness always causes injustice) - Too absolute. Mental illness is one complicating factor among many.
- **D** (Responsibility objectively determined) - Both films show that responsibility determination is subjective and error-prone.

**Course Connection:**
- **Film:** Primal Fear and The Hurricane - contrasting justice failures
- **Readings:** Diamond (1961) on criminal responsibility
- **Integration:** Uses contrasting cases to illustrate fundamental legal challenges

---

### Question 4

**Question:** Carter refused to wear prison clothes or participate in prison programs. According to McKnight & Kashdan (2009), how might this defiance relate to purpose maintenance?

**Answer Choices:**
- A) Defiance indicates purpose rejection
- B) Maintaining identity boundaries preserves the self-organizing system of purpose even when external circumstances are uncontrollable ✓
- C) Purpose cannot exist within incarceration
- D) Defiance is always maladaptive

**Correct Answer: B**

**Rationale for Correct Answer:**
McKnight & Kashdan describe purpose as a self-organizing system that maintains itself through consistent behavior aligned with core values. Carter's defiance maintains his identity as an innocent man, not a criminal. By refusing prison clothing and programs, he preserves the boundary between who he IS (innocent fighter) and what the system claims he is (convicted murderer). This boundary maintenance sustains his purpose even when he can't change his circumstances.

**Distractor Analysis:**
- **A** (Defiance rejects purpose) - The opposite: defiance MAINTAINS purpose by preserving identity.
- **C** (Purpose impossible in prison) - Carter demonstrates that purpose can persist in incarceration through identity maintenance.
- **D** (Defiance always maladaptive) - In this context, defiance served adaptive identity-protective functions.

**Course Connection:**
- **Film:** The Hurricane - Carter's prison resistance
- **Readings:** McKnight & Kashdan (2009) on purpose as self-organizing
- **Integration:** Shows how purpose maintenance can occur even in extreme constraints

---

### Question 5

**Question:** Both films feature attorneys who believe their clients. What does Shermer's (2002) analysis of "smart people believing weird things" suggest about expert vulnerability to deception?

**Answer Choices:**
- A) Legal training specifically protects against deception
- B) Attorneys are randomly selected for gullibility
- C) Expertise provides sophisticated tools for rationalizing conclusions reached through intuition and emotional investment ✓
- D) Smart people never believe false things

**Correct Answer: C**

**Rationale for Correct Answer:**
Shermer's core insight is that intelligence and expertise provide better tools for RATIONALIZATION, not better truth-detection. Vail's legal expertise allowed him to construct sophisticated justifications for believing Aaron. Carter's attorneys had expertise that helped them build an innocence case. In both directions, expertise serves to support pre-existing conclusions rather than objectively evaluate them. Smart professionals use their skills to defend their beliefs.

**Distractor Analysis:**
- **A** (Legal training protects) - The opposite: Vail's expertise was used to rationalize his belief in Aaron.
- **B** (Random gullibility) - Expertise isn't random; the point is that expertise doesn't protect against motivated reasoning.
- **D** (Smart people don't believe false things) - Directly contradicts Shermer's thesis.

**Course Connection:**
- **Film:** Primal Fear and The Hurricane - attorney belief in clients
- **Readings:** Shermer (2002) on expertise and rationalization
- **Integration:** Applies Shermer's framework to expert vulnerability

---

*Last updated: January 2026*
*For Instructor Use Only*
