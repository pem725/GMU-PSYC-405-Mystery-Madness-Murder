# PSYC 405 Section 002 - Quiz 12: Wind River
## CONFIDENTIAL ANSWER KEY

---

## Quiz 12: Wind River (2017)

---

### Question 1

**Question:** Wind River depicts violence against Indigenous women, a crisis that receives minimal mainstream attention. According to Boudry et al. (2015), why might this issue remain "invisible" despite extensive documentation?

**Answer Choices:**
- A) The crisis is not actually serious
- B) Media coverage has been adequate
- C) Beliefs about which lives matter are socially transmitted; issues affecting low-status groups may fail to achieve the salience required for widespread attention and action ✓
- D) Indigenous communities prefer privacy

**Correct Answer: C**

**Rationale for Correct Answer:**
Boudry et al.'s epidemiology of belief applies: beliefs spread based on their cognitive "stickiness" and social transmission. Beliefs that "these victims matter" require social transmission through media, politics, and culture. When victims are low-status (Indigenous women in remote areas), the transmission mechanisms are weaker. The issue can be extensively documented yet fail to achieve salience because the belief "this matters" doesn't spread effectively through dominant cultural channels.

**Distractor Analysis:**
- **A** (Not serious) - The crisis is well-documented as serious; the question is why it stays invisible despite this.
- **B** (Adequate coverage) - Coverage is demonstrably inadequate compared to similar crimes affecting high-status groups.
- **D** (Prefer privacy) - Indigenous advocacy groups actively seek attention; the issue isn't victim preference.

**Course Connection:**
- **Film:** Wind River - Invisible crisis
- **Readings:** Boudry et al. (2015) on belief epidemiology
- **Integration:** Applies belief transmission theory to media attention patterns

---

### Question 2

**Question:** Cory Lambert tracks predators both literally (as a hunter) and figuratively (as an investigator). According to Gross (2015), how might this dual role function as emotion regulation?

**Answer Choices:**
- A) Hunting and investigation are unrelated activities
- B) Both activities channel grief and rage into controlled, purposeful action - a form of response modulation that transforms overwhelming emotion into directed behavior ✓
- C) Lambert has no emotional investment in either activity
- D) Violence always represents failed regulation

**Correct Answer: B**

**Rationale for Correct Answer:**
Gross's response modulation involves changing emotional responses after they've been generated. Lambert's overwhelming grief and rage (over his daughter's death) are channeled into controlled, purposeful action. Hunting requires calm precision; investigation requires methodical thinking. Both activities transform raw emotion into directed behavior. This is adaptive response modulation - not suppression but transformation of emotion into action.

**Distractor Analysis:**
- **A** (Unrelated activities) - Both serve similar psychological functions of channeling emotion.
- **C** (No emotional investment) - The film makes clear Lambert's deep emotional connection to justice.
- **D** (Violence = failed regulation) - Controlled, purposeful action can represent successful regulation even when violent.

**Course Connection:**
- **Film:** Wind River - Lambert's dual role
- **Readings:** Gross (2015) on response modulation
- **Integration:** Applies regulation theory to understand coping through action

---

### Question 3

**Question:** FBI Agent Banner initially underestimates the reservation environment. According to research on belief formation (Shermer, 2002), what does her learning curve illustrate?

**Answer Choices:**
- A) FBI training is inadequate
- B) Urban agents cannot work rural areas
- C) Prior beliefs based on different contexts (urban crime, federal jurisdiction) led to initially incorrect expectations - updating these beliefs required direct contradictory experience ✓
- D) Banner is uniquely ignorant

**Correct Answer: C**

**Rationale for Correct Answer:**
Shermer describes how beliefs form from experience and resist revision. Banner's prior experience (urban FBI work) created expectations that didn't match reservation reality. She believed normal investigative resources would be available; they weren't. She believed jurisdiction would be clear; it wasn't. Updating these prior beliefs required direct, contradictory experience - the kind of evidence that forces belief revision even in resistant systems.

**Distractor Analysis:**
- **A** (Inadequate training) - Training can't prepare for every context; the issue is belief updating.
- **B** (Urban agents can't work rural) - Banner adapts successfully; the issue is initial adjustment.
- **D** (Uniquely ignorant) - Banner represents typical urban law enforcement, not unique ignorance.

**Course Connection:**
- **Film:** Wind River - Banner's learning curve
- **Readings:** Shermer (2002) on belief formation and revision
- **Integration:** Shows how prior beliefs shape initial expectations

---

### Question 4

**Question:** The film reveals that Natalie died running for help after being assaulted at a drilling camp. According to emotion research (Kashdan et al., 2015), what does the medical examiner's difficulty in classifying her death illustrate?

**Answer Choices:**
- A) Medical examiners lack training
- B) Systemic categories (homicide, exposure) may fail to capture deaths caused by multiple factors - just as low emotion differentiation fails to distinguish between multiple emotional causes of distress ✓
- C) Classification is always straightforward
- D) The answer choice was missing in the quiz

**Correct Answer: B**

**Rationale for Correct Answer:**
The medical examiner struggles because Natalie technically died of exposure (cold) but was running from assault (violence). The categories "homicide" and "accident" don't capture the multi-causal reality. This parallels Kashdan et al.'s work on differentiation: just as undifferentiated emotional experience fails to distinguish between multiple causes of distress, undifferentiated legal categories fail to capture complex causation. The system lacks the granularity to represent the truth.

**Distractor Analysis:**
- **A** (Lack training) - The examiner is competent; the categories themselves are inadequate.
- **C** (Always straightforward) - The film explicitly shows classification is NOT straightforward in this case.

**Course Connection:**
- **Film:** Wind River - Cause of death classification
- **Readings:** Kashdan et al. (2015) on differentiation
- **Integration:** Applies differentiation concept to institutional categorization

---

### Question 5

**Question:** The film ends without cathartic revenge - the surviving perpetrator is given "a fighting chance" to freeze to death. According to McKnight & Kashdan (2009), why might Lambert choose this ambiguous justice over clear execution?

**Answer Choices:**
- A) Lambert lacks the capacity for violence
- B) The choice is random without psychological meaning
- C) Allowing the perpetrator to experience what Natalie experienced may serve Lambert's purpose more than simple revenge - justice through experiential symmetry rather than death ✓
- D) Lambert is legally prohibited from killing

**Correct Answer: C**

**Rationale for Correct Answer:**
McKnight & Kashdan describe purpose as providing meaning and direction. Simple execution would be revenge; making the perpetrator experience what Natalie experienced serves deeper purpose. By forcing the man to run in the cold, Lambert creates experiential justice - the perpetrator now knows what Natalie knew in her final moments. This serves Lambert's purpose (honoring Natalie, achieving justice) more meaningfully than simple death would.

**Distractor Analysis:**
- **A** (Lacks capacity) - Lambert demonstrates capacity for violence throughout the film.
- **B** (Random choice) - The specific choice is highly meaningful and deliberate.
- **D** (Legal prohibition) - Lambert has already operated outside strict legal bounds; this isn't about legal compliance.

**Course Connection:**
- **Film:** Wind River - Lambert's choice of justice
- **Readings:** McKnight & Kashdan (2009) on purpose and meaning
- **Integration:** Shows how purpose shapes the form of justice sought

---

*Last updated: January 2026*
*For Instructor Use Only*
