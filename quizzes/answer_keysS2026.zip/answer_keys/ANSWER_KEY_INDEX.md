# PSYC 405: Mystery, Madness & Murder
## CONFIDENTIAL ANSWER KEY INDEX
### Spring 2026 - Patrick E. McKnight

---

**⚠️ DO NOT DISTRIBUTE TO STUDENTS ⚠️**
**FOR INSTRUCTOR USE ONLY**

---

## Directory Structure

Files are named using the format: `{semester}{year}_{section}_quiz{number}.md`

This directory contains complete answer keys for all 28 quizzes across both sections. Each file includes:

- Full question text
- All answer choices (correct marked with ✓)
- Rationale for correct answer
- Distractor analysis (why each wrong answer is wrong)
- Course connection (film, readings, integration)

---

## Quick Reference: Correct Answers

### Spring 2026 Section 001
| Quiz | Q1 | Q2 | Q3 | Q4 | Q5 | Topic |
|------|----|----|----|----|----| ------|
| 1 | B | C | C | C | D | Course Introduction |
| 2 | B | C | B | C | C | Shutter Island |
| 3 | B | C | C | B | C | Shutter Island / North by Northwest |
| 4 | B | B | C | B | C | North by Northwest |
| 5 | B | C | B | C | C | Sunset Boulevard |
| 6 | B | C | C | C | C | Black Swan |
| 7 | C | D | C | D | C | Black Swan / Good Will Hunting |
| 8 | B | C | D | C | B | Good Will Hunting |
| 9 | B | B | C | B | C | What's Eating Gilbert Grape |
| 10 | C | C | C | B | B | Primal Fear |
| 11 | C | C | C | B | C | Primal Fear / The Hurricane |
| 12 | C | C | C | C | C | The Hurricane |
| 13 | C | C | B | C | D | Course Integration |
| 14 | C | C | D | D | C | Final Reflection |

### Spring 2026 Section 002
| Quiz | Q1 | Q2 | Q3 | Q4 | Q5 | Topic |
|------|----|----|----|----|----| ------|
| 1 | C | C | C | C | C | Course Introduction |
| 2 | C | C | B | B | C | The Machinist |
| 3 | C | C | C | C | B | The Machinist / Identity |
| 4 | C | B | C | C | B | Identity |
| 5 | C | C | C | B | C | Fight Club |
| 6 | C | C | C | C | C | Rain Man |
| 7 | C | B | C | C | B | Rain Man / K-PAX |
| 8 | C | C | C | C | C | K-PAX |
| 9 | C | C | C | C | C | Leaving Las Vegas |
| 10 | C | C | C | C | B | Nuremberg |
| 11 | C | C | C | C | C | Nuremberg / Wind River |
| 12 | C | B | C | B | C | Wind River |
| 13 | B | C | C | C | D | Course Integration |
| 14 | B | C | C | C | D | Final Reflection |

---

## Spring 2026 Section 001 Answer Keys

### Films: Shutter Island, North by Northwest, Sunset Boulevard, Black Swan, Good Will Hunting, What's Eating Gilbert Grape, Primal Fear, The Hurricane

| Quiz | Topic | Link |
|------|-------|------|
| 1 | Course Introduction | [spring2026_001_quiz01.md](spring2026_001_quiz01.md) |
| 2 | Shutter Island | [spring2026_001_quiz02.md](spring2026_001_quiz02.md) |
| 3 | Shutter Island / North by Northwest | [spring2026_001_quiz03.md](spring2026_001_quiz03.md) |
| 4 | North by Northwest | [spring2026_001_quiz04.md](spring2026_001_quiz04.md) |
| 5 | Sunset Boulevard | [spring2026_001_quiz05.md](spring2026_001_quiz05.md) |
| 6 | Black Swan | [spring2026_001_quiz06.md](spring2026_001_quiz06.md) |
| 7 | Black Swan / Good Will Hunting | [spring2026_001_quiz07.md](spring2026_001_quiz07.md) |
| 8 | Good Will Hunting | [spring2026_001_quiz08.md](spring2026_001_quiz08.md) |
| 9 | What's Eating Gilbert Grape | [spring2026_001_quiz09.md](spring2026_001_quiz09.md) |
| 10 | Primal Fear | [spring2026_001_quiz10.md](spring2026_001_quiz10.md) |
| 11 | Primal Fear / The Hurricane | [spring2026_001_quiz11.md](spring2026_001_quiz11.md) |
| 12 | The Hurricane | [spring2026_001_quiz12.md](spring2026_001_quiz12.md) |
| 13 | Course Integration | [spring2026_001_quiz13.md](spring2026_001_quiz13.md) |
| 14 | Final Reflection | [spring2026_001_quiz14.md](spring2026_001_quiz14.md) |

---

## Spring 2026 Section 002 Answer Keys

### Films: The Machinist, Identity, Fight Club, Rain Man, K-PAX, Leaving Las Vegas, Nuremberg, Wind River

| Quiz | Topic | Link |
|------|-------|------|
| 1 | Course Introduction | [spring2026_002_quiz01.md](spring2026_002_quiz01.md) |
| 2 | The Machinist | [spring2026_002_quiz02.md](spring2026_002_quiz02.md) |
| 3 | The Machinist / Identity | [spring2026_002_quiz03.md](spring2026_002_quiz03.md) |
| 4 | Identity | [spring2026_002_quiz04.md](spring2026_002_quiz04.md) |
| 5 | Fight Club | [spring2026_002_quiz05.md](spring2026_002_quiz05.md) |
| 6 | Rain Man | [spring2026_002_quiz06.md](spring2026_002_quiz06.md) |
| 7 | Rain Man / K-PAX | [spring2026_002_quiz07.md](spring2026_002_quiz07.md) |
| 8 | K-PAX | [spring2026_002_quiz08.md](spring2026_002_quiz08.md) |
| 9 | Leaving Las Vegas | [spring2026_002_quiz09.md](spring2026_002_quiz09.md) |
| 10 | Nuremberg | [spring2026_002_quiz10.md](spring2026_002_quiz10.md) |
| 11 | Nuremberg / Wind River | [spring2026_002_quiz11.md](spring2026_002_quiz11.md) |
| 12 | Wind River | [spring2026_002_quiz12.md](spring2026_002_quiz12.md) |
| 13 | Course Integration | [spring2026_002_quiz13.md](spring2026_002_quiz13.md) |
| 14 | Final Reflection | [spring2026_002_quiz14.md](spring2026_002_quiz14.md) |

---

## Key Readings Referenced

The following readings are frequently cited in quiz rationales:

### BELIEF Construct
- **Shermer (2002)** - "Why Smart People Believe Weird Things"
- **Boudry & Braeckman (2012)** - "Immunizing Strategies and Epistemic Defense Mechanisms"
- **Boudry et al. (2015)** - "The Epidemiology of Pseudoscience"
- **Matthews (2005)** - "Rational Inference from Weird Evidence"

### PURPOSE Construct
- **McKnight & Kashdan (2009)** - Purpose as self-organizing system
- **Kashdan et al. (2024)** - Self-concordance and purpose
- **McKnight et al. (2025)** - Happiness predicts purpose

### EMOTION Construct
- **Gross (2015)** - Emotion regulation framework
- **Kashdan et al. (2015)** - Emotion differentiation
- **Kalokerinos et al. (2019)** - Differentiation and regulation effectiveness
- **Feldman Barrett et al. (2001)** - Knowing what you're feeling

### MOTIVATION & SOCIAL CONSTRUCTS
- **Pratto et al. (1994)** - Social dominance orientation
- **Vrij et al. (2019)** - Deception detection
- **Marshall et al. (2018)** - Psychopathy and moral judgment

### LEGAL/RESPONSIBILITY
- **Morse (1992)** - Mens rea
- **Diamond (1961)** - Criminal responsibility of mentally ill
- **Diamantis (2015)** - Corporate criminal minds

---

## Canvas Import Format

Each quiz question can be copied directly into Canvas Quiz question banks.

**Recommended Canvas settings:**
- Time limit: 15 minutes per quiz
- One question at a time: Yes
- Lock after answering: Yes
- Show results: After submission
- Points per question: 2 points

---

## Backup and Portability

This directory is designed for easy portability:

1. **Copy to thumb drive**: Copy the entire `answer_keys/` directory
2. **Upload to Google Drive**: Drag the folder to Drive for cloud backup
3. **All links are relative**: Files link to each other within the directory

The `.gitignore` excludes this directory from version control to maintain confidentiality.

---

*Last updated: January 2026*
*Created by: Claude Code for Patrick E. McKnight, Ph.D.*
*Confidential - For Instructor Use Only*
