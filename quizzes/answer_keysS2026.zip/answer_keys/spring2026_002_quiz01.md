# PSYC 405 Section 002 - Quiz 1: Course Introduction
## CONFIDENTIAL ANSWER KEY

---

## Quiz 1: Foundations of Psychological Inquiry

---

### Question 1

**Question:** The course examines "Mystery, Madness, and Murder" through the lens of psychological science. According to Boudry et al. (2015), why do pseudoscientific explanations of human behavior persist despite scientific alternatives?

**Answer Choices:**
- A) Scientists fail to communicate effectively with the public
- B) Pseudoscience is more accurate than science
- C) Pseudoscientific beliefs have features that make them cognitively "sticky" - they appeal to intuition, provide simple explanations, and resist disconfirmation ✓
- D) The public intentionally rejects science

**Correct Answer: C**

**Rationale for Correct Answer:**
Boudry et al.'s "epidemiology of pseudoscience" explains that certain beliefs spread because they have cognitive features that make them easy to acquire and hard to dislodge. These include: (1) intuitive appeal - matching existing cognitive biases, (2) simplicity - offering clear explanations for complex phenomena, and (3) self-validation - resisting disconfirmation through immunizing strategies. Science often lacks these "sticky" features, making it harder to spread even when more accurate.

**Distractor Analysis:**
- **A** (Scientists fail to communicate) - While sometimes true, this doesn't explain WHY pseudoscience is "stickier" than science.
- **B** (Pseudoscience more accurate) - Empirically false; the question is why inaccurate beliefs persist.
- **D** (Public intentionally rejects) - People don't consciously choose pseudoscience; cognitive features drive spread.

**Course Connection:**
- **Readings:** Boudry et al. (2015) "The Epidemiology of Pseudoscience"
- **Course Framework:** Establishes why we study belief formation - understanding persistence of inaccurate ideas about psychology

---

### Question 2

**Question:** Shermer (2002) argues that intelligent people are not protected from irrational beliefs. What mechanism does he propose to explain this paradox?

**Answer Choices:**
- A) Intelligence and rationality are negatively correlated
- B) Education exposes people to more false information
- C) Intelligent people are more skilled at constructing post-hoc rationalizations for beliefs acquired through non-rational means ✓
- D) Smart people have more irrational beliefs overall

**Correct Answer: C**

**Rationale for Correct Answer:**
Shermer's key insight is that everyone acquires beliefs through similar non-rational processes (emotion, social influence, pattern-seeking). Intelligence doesn't change HOW beliefs are acquired; it changes how well they're DEFENDED. Smart people can construct more elaborate, sophisticated justifications for whatever they believe, making their irrational beliefs harder to challenge and more resistant to change.

**Distractor Analysis:**
- **A** (Negative correlation) - Intelligence and rationality correlate positively; the paradox is that correlation doesn't equal protection.
- **B** (Education exposes to false information) - No evidence education increases pseudoscience exposure; typically the opposite.
- **D** (Smart people have more irrational beliefs) - Not the claim; they have EQUALLY irrational beliefs, just better defended.

**Course Connection:**
- **Readings:** Shermer (2002) "Why Smart People Believe Weird Things"
- **Course Framework:** Foundational for understanding how characters in films maintain beliefs despite contradictory evidence

---

### Question 3

**Question:** The six "governing areas of inquiry" (BELIEF, PURPOSE, MOTIVATION, UNCERTAINTY, DISCOMFORT, EMOTION) represent overlapping psychological constructs. According to current research, which relationship is MOST supported by evidence?

**Answer Choices:**
- A) These constructs are entirely independent
- B) BELIEF determines all other constructs
- C) These constructs interact bidirectionally - for example, emotion influences belief while belief shapes emotional interpretation ✓
- D) Only EMOTION is scientifically measurable

**Correct Answer: C**

**Rationale for Correct Answer:**
Contemporary psychological research emphasizes bidirectional relationships among these constructs. Emotions influence what we believe (confirmation bias, motivated reasoning); beliefs shape how we interpret emotional experiences (emotion concepts, appraisal). Purpose affects motivation; uncertainty triggers emotional responses; discomfort motivates belief change. These aren't separate modules but an integrated system.

**Distractor Analysis:**
- **A** (Entirely independent) - Contradicts extensive research on interconnections.
- **B** (Belief determines all) - No single construct is primary; relationships are bidirectional.
- **D** (Only emotion measurable) - All constructs have valid measurement approaches.

**Course Connection:**
- **Readings:** Course framework and multiple sources
- **Course Framework:** Establishes the integrated nature of the six inquiry areas

---

### Question 4

**Question:** McKnight & Kashdan (2009) propose that purpose in life functions as a "self-organizing system." What does this theoretical framework predict about purpose?

**Answer Choices:**
- A) Purpose is fixed and unchangeable once established
- B) Purpose requires external validation to exist
- C) Purpose actively creates conditions that sustain itself, influencing perception, motivation, and behavior in self-perpetuating patterns ✓
- D) Purpose is synonymous with happiness

**Correct Answer: C**

**Rationale for Correct Answer:**
The "self-organizing system" concept means purpose doesn't just exist passively - it actively shapes the person's psychology to maintain itself. Purpose influences: (1) what we notice (perception), (2) what we want (motivation), (3) what we do (behavior). These effects, in turn, reinforce the purpose, creating a self-sustaining loop. Purpose organizes the psychological system around itself.

**Distractor Analysis:**
- **A** (Fixed and unchangeable) - Self-organizing systems can evolve and adapt; they're not static.
- **B** (Requires external validation) - Purpose can be entirely internal; external validation is not required.
- **D** (Synonymous with happiness) - Related but distinct constructs; McKnight et al. (2025) showed they have different temporal patterns.

**Course Connection:**
- **Readings:** McKnight & Kashdan (2009) on purpose as self-organizing
- **Course Framework:** PURPOSE construct foundation

---

### Question 5

**Question:** When analyzing films depicting psychological phenomena, what methodological principle should guide interpretation?

**Answer Choices:**
- A) Fictional portrayals should be accepted as accurate representations
- B) Entertainment value invalidates psychological analysis
- C) Fictional portrayals should be evaluated against empirical evidence, recognizing that dramatic necessity often distorts psychological accuracy ✓
- D) Only documentaries can inform psychological understanding

**Correct Answer: C**

**Rationale for Correct Answer:**
The course method involves COMPARING fiction to research. Films are valuable precisely because they show popular understanding, which can be compared to scientific evidence. The comparison reveals: (1) what films get right, (2) where dramatic necessity creates distortion, and (3) how popular understanding differs from scientific knowledge. This comparison develops critical thinking about psychological claims.

**Distractor Analysis:**
- **A** (Accept as accurate) - Films frequently distort for drama; uncritical acceptance would be error.
- **B** (Entertainment invalidates analysis) - Entertainment value doesn't preclude analytical value.
- **D** (Only documentaries) - Fiction can illuminate psychological principles through contrast with research.

**Course Connection:**
- **Readings:** Course methodology
- **Course Framework:** Establishes analytical approach for film analysis

---

*Last updated: January 2026*
*For Instructor Use Only*
