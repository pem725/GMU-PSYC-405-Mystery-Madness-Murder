# PSYC 405 Section 001 - Quiz 10: Primal Fear
## CONFIDENTIAL ANSWER KEY

---

## Quiz 10: Primal Fear (1996) - Part I

---

### Question 1

**Question:** Aaron Stampler convincingly presents with apparent dissociative identity disorder (DID). According to the meta-analytic findings in Marshall et al. (2018), what does research suggest about the relationship between psychopathy and moral understanding?

**Answer Choices:**
- A) Psychopaths completely lack moral understanding
- B) Psychopaths have inverted moral values
- C) The relationship between psychopathy and moral judgment is smaller than commonly believed; psychopaths often understand morality but are unmoved by it ✓
- D) Psychopathy and moral judgment are unrelated constructs

**Correct Answer: C**

**Rationale for Correct Answer:**
Marshall et al.'s meta-analysis revealed that psychopaths generally UNDERSTAND moral distinctions - they know what's right and wrong. The deficit is in caring about these distinctions. Aaron/Roy demonstrates this: he understands that murder is wrong (he constructs an elaborate defense), understands what would be convincing to others (including feigned DID), but is emotionally unmoved by moral considerations. The problem isn't moral knowledge; it's moral motivation.

**Distractor Analysis:**
- **A** (Completely lack understanding) - The research shows moral understanding is present. Complete lack would make Aaron's manipulation impossible.
- **B** (Inverted values) - Psychopaths don't value the opposite of normal morality; they're indifferent to moral considerations.
- **D** (Unrelated constructs) - The constructs ARE related; the relationship is just smaller than assumed.

**Course Connection:**
- **Film:** Primal Fear - Aaron/Roy's moral functioning
- **Readings:** Marshall et al. (2018) on psychopathy and moral judgment
- **Integration:** Applies meta-analytic findings to understand a film character's psychology

---

### Question 2

**Question:** Martin Vail accepts Aaron's case initially for publicity and career advancement. His motivation transforms throughout the trial. According to Pratto et al. (1994), what does Vail's initial motivation reveal about social dominance orientation?

**Answer Choices:**
- A) High SDO individuals avoid legal professions
- B) Vail demonstrates low SDO through his defense of the accused
- C) Defense attorneys may be motivated by hierarchy-enhancing goals (fame, status) while using hierarchy-attenuating rhetoric (defending the powerless) ✓
- D) SDO is irrelevant to legal practice

**Correct Answer: C**

**Rationale for Correct Answer:**
Pratto et al. describe how SDO can manifest through various career choices. Defense work APPEARS to challenge hierarchy by defending those accused by the state. But Vail's motivation is hierarchy-enhancing: he wants fame, status, and career advancement. He uses the rhetoric of justice while pursuing personal power. This illustrates how hierarchy-challenging work can serve hierarchy-enhancing goals.

**Distractor Analysis:**
- **A** (High SDO avoids law) - No evidence for this. High SDO individuals might be drawn to law for its power and status.
- **B** (Low SDO through defense work) - Defending the accused doesn't automatically indicate low SDO; motivation matters.
- **D** (SDO irrelevant) - SDO is relevant to understanding motivations in any profession involving power.

**Course Connection:**
- **Film:** Primal Fear - Vail's motivations
- **Readings:** Pratto et al. (1994) on social dominance orientation
- **Integration:** Shows how SDO analysis can reveal hidden motivations

---

### Question 3

**Question:** The film's forensic psychiatrist must distinguish between genuine DID and malingering. According to Vrij et al. (2019), why is this distinction so difficult?

**Answer Choices:**
- A) DID and malingering produce identical brain scans
- B) Psychiatrists receive no training in deception detection
- C) Behavioral cues to deception are "faint and unreliable," and clinical training does not significantly improve detection accuracy ✓
- D) Malingerers always eventually confess

**Correct Answer: C**

**Rationale for Correct Answer:**
Vrij et al.'s research shows that deception detection accuracy is near chance for everyone, including trained professionals. Psychiatrists may believe they can detect malingering, but research doesn't support this confidence. Aaron succeeds in fooling the psychiatrist because there are no reliable behavioral cues to distinguish genuine symptoms from convincing performance, and clinical training doesn't improve detection.

**Distractor Analysis:**
- **A** (Identical brain scans) - The issue isn't neuroimaging; it's behavioral assessment.
- **B** (No training) - Psychiatrists DO receive training in malingering assessment; it just doesn't significantly improve accuracy.
- **D** (Malingerers confess) - No evidence for this claim; Aaron only reveals the truth when he chooses to.

**Course Connection:**
- **Film:** Primal Fear - Psychiatric evaluation of Aaron
- **Readings:** Vrij et al. (2019) on deception detection
- **Integration:** Applies deception research to clinical forensic contexts

---

### Question 4

**Question:** Morse (1992) describes *mens rea* (guilty mind) as central to criminal liability. If Aaron truly had DID, which legal concept would be most relevant to his defense?

**Answer Choices:**
- A) Not guilty by reason of insanity (complete defense)
- B) Diminished capacity - the argument that mental illness prevented formation of specific intent required for first-degree murder ✓
- C) Automatism (involuntary action)
- D) Self-defense (justification)

**Correct Answer: B**

**Rationale for Correct Answer:**
Diminished capacity is the legal doctrine that mental illness can prevent the formation of the specific intent required for certain crimes. First-degree murder requires premeditation and specific intent to kill. If an alter personality committed the crime without the host personality's knowledge, the argument would be that the defendant couldn't form the required specific intent. This reduces (diminishes) culpability without eliminating it entirely.

**Distractor Analysis:**
- **A** (Insanity defense) - Insanity is a complete defense, but DID doesn't automatically meet insanity standards (must not understand wrongfulness).
- **C** (Automatism) - Automatism involves involuntary physical actions. DID involves separate conscious entities, not involuntary action.
- **D** (Self-defense) - No evidence in the film supports a self-defense claim.

**Course Connection:**
- **Film:** Primal Fear - Legal defense strategy
- **Readings:** Morse (1992) on mens rea
- **Integration:** Applies legal concepts to understand film's courtroom dynamics

---

### Question 5

**Question:** The film's twist reveals that "Aaron" was the performance and "Roy" was the true personality. This revelation challenges which assumption about deception?

**Answer Choices:**
- A) Deception requires conscious effort and shows behavioral leakage
- B) The most effective deception involves becoming the deceptive persona, making traditional cue-based detection impossible ✓
- C) Psychiatric evaluation can always detect deception
- D) Multiple personalities cannot be fabricated

**Correct Answer: B**

**Rationale for Correct Answer:**
Aaron's deception succeeds because he doesn't show "deception cues" - he fully inhabits the innocent persona. Traditional deception detection assumes liars experience cognitive load and emotional leakage. But if the deceiver fully BECOMES the persona, these cues don't appear. Aaron isn't lying about being innocent; he's performing a character so completely that the performance IS his reality during examination.

**Distractor Analysis:**
- **A** (Deception shows leakage) - This is exactly what the twist contradicts. Aaron shows no leakage because his deception is complete immersion.
- **C** (Psychiatry always detects) - The film directly contradicts this by showing successful deception of psychiatrists.
- **D** (Cannot fabricate DID) - The film suggests DID CAN be fabricated convincingly, which raises real clinical concerns.

**Course Connection:**
- **Film:** Primal Fear - The twist ending
- **Readings:** Vrij et al. (2019) on deception mechanisms
- **Integration:** Uses the film's twist to illustrate limitations of traditional deception detection theory

---

*Last updated: January 2026*
*For Instructor Use Only*
