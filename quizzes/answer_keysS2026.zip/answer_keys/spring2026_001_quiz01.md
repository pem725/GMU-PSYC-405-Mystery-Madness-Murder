# PSYC 405 Section 001 - Quiz 1: Course Introduction
## CONFIDENTIAL ANSWER KEY

---

## Quiz 1: Foundations of Psychological Inquiry

---

### Question 1

**Question:** According to Shermer's research on belief formation, why might highly intelligent individuals be *more* susceptible to believing "weird things" rather than less?

**Answer Choices:**
- A) Intelligence correlates negatively with critical thinking skills
- B) Smart people are better at constructing sophisticated rationalizations for beliefs they arrived at for non-smart reasons ✓
- C) Higher education exposes people to more pseudoscientific content
- D) Intelligent people have less need for empirical evidence

**Correct Answer: B**

**Rationale for Correct Answer:**
Shermer's (2002) key insight is that intelligence doesn't protect against irrational belief - it actually enhances the ability to defend such beliefs. Smart people don't arrive at beliefs more rationally; they arrive at them for the same emotional and social reasons as everyone else. However, their cognitive sophistication allows them to construct more elaborate and convincing post-hoc justifications. This is the "smart people rationalization" phenomenon: intelligence is a tool that can be used to defend any position, not just accurate ones.

**Distractor Analysis:**
- **A** (Intelligence correlates negatively with critical thinking) - Empirically false. Intelligence and critical thinking correlate positively (r ≈ 0.30-0.50). This option appeals because it offers a simple inverse relationship.
- **C** (Higher education exposes to pseudoscience) - Reverses the actual relationship. Education generally reduces pseudoscientific belief through exposure to scientific methodology.
- **D** (Intelligent people need less evidence) - Contradicts research showing intelligent people often demand MORE evidence. The problem is they then use that evidence selectively.

**Course Connection:**
- **Readings:** Directly tests Shermer (2002) "Why Smart People Believe Weird Things" - foundational text for the BELIEF construct
- **Course Framework:** Establishes that intelligence ≠ rationality, setting up analysis of intelligent characters (Will Hunting, Norma Desmond) who hold irrational beliefs

---

### Question 2

**Question:** The course explores six "governing areas of inquiry." Which of the following accurately describes the relationship between UNCERTAINTY and BELIEF as psychological constructs?

**Answer Choices:**
- A) Uncertainty always leads to stronger beliefs as a compensatory mechanism
- B) Belief and uncertainty are independent constructs with no psychological relationship
- C) Uncertainty can paradoxically strengthen beliefs when evidence is ambiguous, as people seek cognitive closure ✓
- D) High certainty eliminates the need for belief systems entirely

**Correct Answer: C**

**Rationale for Correct Answer:**
Research on need for closure (Kruglanski & Webster, 1996) and uncertainty management (Van den Bos, 2009) demonstrates that uncertainty is aversive and motivates belief adoption. When evidence is ambiguous, people often become MORE committed to existing beliefs rather than revising them - a paradoxical effect. This connects to Boudry & Braeckman's work on how self-validating belief systems exploit uncertainty to maintain adherence.

**Distractor Analysis:**
- **A** (Uncertainty always strengthens beliefs) - Too absolute. Sometimes uncertainty leads to belief revision, especially when disconfirmation is clear and personally relevant.
- **B** (Independent constructs) - Empirically incorrect. Extensive research shows bidirectional relationships between uncertainty tolerance and belief rigidity.
- **D** (High certainty eliminates beliefs) - Logically flawed. Certainty IS a belief state; you can't have certainty without believing something.

**Course Connection:**
- **Readings:** Integrates Boudry & Braeckman (2012) on self-validating beliefs with broader uncertainty research
- **Course Framework:** Introduces the UNCERTAINTY construct as interacting with BELIEF, preparing students for analysis of characters who maintain beliefs despite contradictory evidence (Teddy Daniels, Norma Desmond)

---

### Question 3

**Question:** Boudry and Braeckman (2012) argue that "weird" belief systems exhibit surprising resilience because they are "self-validating." Which psychological mechanism does NOT contribute to this self-validation?

**Answer Choices:**
- A) Confirmation bias in seeking supporting evidence
- B) Motivated reasoning to preserve existing beliefs
- C) Systematic falsification testing of core assumptions ✓
- D) Immunizing strategies that reinterpret contradictory evidence

**Correct Answer: C**

**Rationale for Correct Answer:**
This is a "reverse" question testing whether students understand what self-validation IS by identifying what it is NOT. Systematic falsification testing (Popper's scientific method) would UNDERMINE self-validation by exposing beliefs to genuine disconfirmation. Self-validating belief systems specifically AVOID falsification by using confirmation bias (A), motivated reasoning (B), and immunizing strategies (D). The correct answer is the one that breaks the self-validation cycle.

**Distractor Analysis:**
- **A** (Confirmation bias) - DOES contribute to self-validation. Seeking confirming evidence while ignoring disconfirming evidence protects beliefs.
- **B** (Motivated reasoning) - DOES contribute. The desire to maintain beliefs shapes how evidence is processed.
- **D** (Immunizing strategies) - DOES contribute. Boudry & Braeckman explicitly identify these as key to self-validation.

**Course Connection:**
- **Readings:** Directly tests Boudry & Braeckman (2012) "Immunizing Strategies and Epistemic Defense Mechanisms"
- **Film Relevance:** Prepares students to identify immunizing strategies in characters like Teddy Daniels (Shutter Island) who reinterpret contradictory evidence as part of the "conspiracy"

---

### Question 4

**Question:** When analyzing fictional portrayals of human behavior in film, which methodological consideration from psychological science is MOST critical?

**Answer Choices:**
- A) Films accurately represent base rates of psychological disorders in the population
- B) Dramatic necessity often conflicts with psychological accuracy, requiring viewers to distinguish artistic license from scientific validity
- C) Both the ecological validity of portrayed behaviors AND the theoretical mechanisms driving those behaviors must be evaluated ✓
- D) Film portrayals should be dismissed entirely as entertainment with no psychological relevance

**Correct Answer: C**

**Rationale for Correct Answer:**
This answer captures the dual evaluation required for scientific film analysis: (1) ecological validity - does the behavior look realistic in context? and (2) theoretical mechanism - does the portrayed psychological process match what research tells us? Neither alone is sufficient. A behavior might look realistic but operate through fictional mechanisms, or might accurately portray mechanisms in unrealistic contexts.

**Distractor Analysis:**
- **A** (Films represent base rates accurately) - Empirically false. Films dramatically over-represent rare conditions (DID, violent psychosis) and under-represent common ones (depression, anxiety).
- **B** (Dramatic necessity conflicts with accuracy) - Partially correct but incomplete. It notes the conflict without specifying HOW to evaluate films productively.
- **D** (Dismiss fiction entirely) - Throws away valuable data. Fiction can illuminate psychological processes even when specific details are inaccurate - this is the value of the course.

**Course Connection:**
- **Readings:** Applies scientific methodology to course approach
- **Course Framework:** Establishes the analytical framework students will use throughout the semester - neither uncritical acceptance nor wholesale rejection of film portrayals

---

### Question 5

**Question:** The Mason Apex learning objectives emphasize "integrating skills, abilities, theories, or methodologies." In the context of this course, integration means:

**Answer Choices:**
- A) Memorizing psychological terminology to apply to film analysis
- B) Accepting film portrayals as accurate representations of psychological phenomena
- C) Separating entertainment value from scientific analysis
- D) Synthesizing observational skills, theoretical frameworks, and critical evaluation to analyze complex human behavior in context ✓

**Correct Answer: D**

**Rationale for Correct Answer:**
Integration in the Mason Apex context means combining multiple skills into a coherent analytical approach. This answer correctly identifies three components that must work together: (1) observational skills - noticing details of behavior in film, (2) theoretical frameworks - psychological science from readings, and (3) critical evaluation - assessing accuracy and relevance. The word "synthesizing" is key - not just using these skills separately but combining them.

**Distractor Analysis:**
- **A** (Memorizing terminology) - Rote learning, not integration. Knowing terms without applying them misses the point.
- **B** (Accepting portrayals as accurate) - Uncritical acceptance contradicts the critical evaluation component.
- **C** (Separating entertainment from analysis) - False dichotomy. The course shows how entertainment and analysis can enhance each other.

**Course Connection:**
- **Readings:** Connects to Mason Apex learning outcomes and course goals
- **Course Framework:** Articulates what "success" looks like in this course - the ability to bring together observation, theory, and evaluation

---

*Last updated: January 2026*
*For Instructor Use Only*
