# PSYC 405 Section 002 - Quiz 13: Course Integration
## CONFIDENTIAL ANSWER KEY

---

## Quiz 13: Wrap-up and Review

---

### Question 1

**Question:** Across the films we studied (The Machinist, Identity, Fight Club, Rain Man, K-PAX, Leaving Las Vegas, Nuremberg, Wind River), which psychological theme appeared most consistently?

**Answer Choices:**
- A) Genetic determination of behavior
- B) Identity fragmentation or distortion - whether through dissociation, delusion, trauma, or institutional dehumanization ✓
- C) Financial motivation for all actions
- D) Random chance determining outcomes

**Correct Answer: B**

**Rationale for Correct Answer:**
Across all eight films, identity disturbance is the central theme:
- The Machinist: Trevor creates Ivan to fragment guilty self
- Identity: Malcolm's personality fragmentation
- Fight Club: Narrator/Tyler dissociation
- Rain Man: Raymond's autism affecting identity/connection
- K-PAX: Prot's possible trauma-induced identity
- Leaving Las Vegas: Ben's dissolved identity through alcoholism
- Nuremberg: How ideology fragments moral identity
- Wind River: Natalie's dehumanization; institutional erasure of Indigenous identity

**Distractor Analysis:**
- **A** (Genetic determination) - Genetics rarely discussed; psychological and social factors predominate.
- **C** (Financial motivation) - While present in some films, not the central theme.
- **D** (Random chance) - Films show meaningful psychological causation, not randomness.

**Course Connection:**
- **Film:** All semester films
- **Readings:** Course synthesis
- **Integration:** Tests ability to identify cross-film patterns

---

### Question 2

**Question:** According to emotion differentiation research (Kashdan et al., 2015; Kalokerinos et al., 2019), which character demonstrated the MOST impaired emotion differentiation?

**Answer Choices:**
- A) Raymond Babbitt (followed clear routines)
- B) Ben Ferencz (channeled grief into purpose)
- C) Trevor Reznik (could not identify the source of overwhelming distress, leading to complete reality distortion) ✓
- D) Prot (maintained consistent alternative identity)

**Correct Answer: C**

**Rationale for Correct Answer:**
Kalokerinos et al.'s research shows low differentiators struggle to identify what they're feeling and show ineffective regulation. Trevor exemplifies this: he experiences overwhelming negative affect but cannot identify its source (guilt about the hit-and-run). This undifferentiated distress led to maladaptive regulation (insomnia, delusion, projection). He literally cannot tell what he's feeling, which is why he creates Ivan - a concrete, external "cause" for his nameless distress.

**Distractor Analysis:**
- **A** (Raymond) - Raymond's routines suggest functional regulation, even if atypical.
- **B** (Ben Ferencz) - He successfully channeled specific emotion (grief, outrage) into purpose.
- **D** (Prot) - Whether delusional or alien, Prot maintains coherent emotional presentation.

**Course Connection:**
- **Film:** The Machinist - Trevor's undifferentiated distress
- **Readings:** Kashdan et al. (2015); Kalokerinos et al. (2019)
- **Integration:** Identifies best exemplar of low differentiation

---

### Question 3

**Question:** McKnight & Kashdan (2009) propose that purpose functions as a self-organizing system. Which character's trajectory best demonstrates how trauma can either destroy OR reorganize purpose?

**Answer Choices:**
- A) Ben Sanderson (purpose destroyed without reorganization)
- B) Malcolm Rivers (purpose fragmented into competing systems)
- C) Cory Lambert (trauma reorganized into justice-seeking purpose) ✓
- D) The Narrator/Tyler Durden (purpose fragmented into competing identities)

**Correct Answer: C**

**Rationale for Correct Answer:**
The question asks about trauma reorganizing purpose, which implies successful (if painful) adaptation. Cory Lambert demonstrates this: his daughter's death could have destroyed him (like Ben) or fragmented him (like Malcolm). Instead, the trauma reorganized his purpose system around justice - protecting other vulnerable people, honoring his daughter's memory through action. His purpose is painful but functional, directed, and meaning-generating.

**Distractor Analysis:**
- **A** (Ben Sanderson) - Shows purpose destruction, not reorganization.
- **B** (Malcolm Rivers) - Shows fragmentation, not reorganization into coherent new purpose.
- **D** (Narrator/Tyler) - Shows fragmentation and dysfunction, not reorganization.

**Course Connection:**
- **Film:** Wind River - Lambert's trauma-organized purpose
- **Readings:** McKnight & Kashdan (2009) on purpose reorganization
- **Integration:** Shows successful (if painful) purpose reorganization

---

### Question 4

**Question:** Boudry & Braeckman (2012) describe how self-validating belief systems resist disconfirmation. Which film most clearly demonstrated institutional (rather than individual) self-validating beliefs?

**Answer Choices:**
- A) K-PAX (individual delusion)
- B) Fight Club (individual dissociation)
- C) Nuremberg (Nazi ideology as systematically self-validating institutional belief) ✓
- D) Rain Man (individual autism)

**Correct Answer: C**

**Rationale for Correct Answer:**
Nuremberg most clearly shows INSTITUTIONAL self-validating beliefs. Nazi ideology wasn't just individual delusion - it was a systematic belief system that operated at institutional level, with built-in immunizing strategies: racial science "proved" Aryan superiority, Jewish conspiracy theories explained any challenges, state legitimacy justified any action. The belief system was self-validating at the societal level, making individual resistance extremely difficult.

**Distractor Analysis:**
- **A** (K-PAX) - Individual delusion, not institutional.
- **B** (Fight Club) - Individual dissociation, not institutional belief.
- **D** (Rain Man) - Autism is neurological, not a belief system.

**Course Connection:**
- **Film:** Nuremberg - Nazi ideology as institutional belief
- **Readings:** Boudry & Braeckman (2012) applied to institutions
- **Integration:** Extends belief theory from individual to institutional level

---

### Question 5

**Question:** The course examined six governing areas of inquiry: BELIEF, PURPOSE, MOTIVATION, UNCERTAINTY, DISCOMFORT, and EMOTION. Based on all films and readings, which statement best captures their relationship?

**Answer Choices:**
- A) Each operates independently in isolated psychological modules
- B) BELIEF is the master construct determining all others
- C) These are merely different words for the same phenomenon
- D) They form an interconnected system - beliefs shape emotional interpretation, emotions drive motivation, uncertainty threatens purpose, and discomfort motivates belief change - requiring integrated analysis ✓

**Correct Answer: D**

**Rationale for Correct Answer:**
The course demonstrated interconnection throughout:
- Beliefs shape emotional interpretation (Teddy's delusion structures his emotional life)
- Emotions drive motivation (Charlie's growing affection motivates care for Raymond)
- Uncertainty threatens purpose (Lambert's certainty about justice enables purpose)
- Discomfort motivates belief change (or belief defense - the Nuremberg defendants)
The six areas require integrated analysis because changes in one ripple through others.

**Distractor Analysis:**
- **A** (Independent modules) - The films consistently showed interconnection.
- **B** (Belief is master) - No single construct is primary; relationships are bidirectional.
- **C** (Same phenomenon) - The constructs are related but meaningfully distinct.

**Course Connection:**
- **Film:** All semester films
- **Readings:** Course synthesis
- **Integration:** Tests understanding of course framework as integrated system

---

*Last updated: January 2026*
*For Instructor Use Only*
