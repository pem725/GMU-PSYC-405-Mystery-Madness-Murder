# PSYC 405 Section 002 - Quiz 10: Nuremberg
## CONFIDENTIAL ANSWER KEY

---

## Quiz 10: Nuremberg (2000) - Part I

---

### Question 1

**Question:** The Nuremberg trials established that "following orders" does not excuse atrocities. According to research on social dominance (Pratto et al., 1994), what psychological mechanism allows ordinary people to participate in extraordinary evil?

**Answer Choices:**
- A) Only psychopaths commit atrocities
- B) Soldiers lack moral reasoning capacity
- C) High SDO combined with legitimizing myths and hierarchical structure allows individuals to defer moral responsibility to authority, enabling atrocity participation without experiencing cognitive dissonance ✓
- D) War automatically eliminates moral judgment

**Correct Answer: C**

**Rationale for Correct Answer:**
Pratto et al.'s SDO theory explains how ordinary people commit extraordinary acts. High SDO provides comfort with hierarchy and dominance. Legitimizing myths (racial superiority, state necessity) justify actions within the hierarchy. The combination allows individuals to commit atrocities while believing they're fulfilling duties, not making moral choices. Responsibility is deferred upward to authority, protecting individual perpetrators from cognitive dissonance.

**Distractor Analysis:**
- **A** (Only psychopaths) - Most perpetrators weren't psychopaths; normal psychological processes enabled their actions.
- **B** (Soldiers lack moral capacity) - Soldiers have moral capacity; they defer rather than lack judgment.
- **D** (War eliminates judgment) - War changes context but doesn't eliminate moral reasoning.

**Course Connection:**
- **Film:** Nuremberg - Defendants' "following orders" defense
- **Readings:** Pratto et al. (1994) on SDO
- **Integration:** Applies dominance theory to explain atrocity participation

---

### Question 2

**Question:** Hannah Arendt famously described Eichmann as embodying "the banality of evil." According to Marshall et al. (2018), what does research suggest about the moral understanding of those who commit atrocities?

**Answer Choices:**
- A) Perpetrators completely lack moral understanding
- B) Atrocity is always psychopathic
- C) Perpetrators often demonstrate intact moral understanding - they know their actions are wrong but compartmentalize or rationalize their behavior ✓
- D) Moral judgment is irrelevant to mass violence

**Correct Answer: C**

**Rationale for Correct Answer:**
Marshall et al.'s research shows that moral understanding is often INTACT in perpetrators; they know right from wrong. What's disturbed is the connection between knowledge and action. Perpetrators compartmentalize (this is war, not normal life) or rationalize (necessity, obedience, greater good). The Nuremberg defendants demonstrated moral understanding when evaluating OTHERS' behavior while exempting their own. Understanding exists but is disconnected from self-evaluation.

**Distractor Analysis:**
- **A** (Completely lack understanding) - The defendants could articulate moral principles; they just didn't apply them to themselves.
- **B** (Always psychopathic) - Most Nuremberg defendants weren't clinical psychopaths.
- **D** (Irrelevant) - Moral judgment is highly relevant; its disconnection from behavior is the puzzle.

**Course Connection:**
- **Film:** Nuremberg - Defendants' moral reasoning
- **Readings:** Marshall et al. (2018) on moral understanding
- **Integration:** Applies moral psychology to war crimes

---

### Question 3

**Question:** The defendants at Nuremberg used various psychological defenses: denial, rationalization, and diffusion of responsibility. According to Boudry & Braeckman (2012), these represent which broader phenomenon?

**Answer Choices:**
- A) Unique Nazi psychology
- B) Normal human confession-avoidance
- C) Self-validating belief systems that protect perpetrators from confronting the moral implications of their actions - "immunizing strategies" against guilt ✓
- D) Deliberate legal strategy without psychological basis

**Correct Answer: C**

**Rationale for Correct Answer:**
Boudry & Braeckman's immunizing strategies apply: the defendants constructed belief systems that protected them from guilt. Denial ("I didn't know"), rationalization ("I had no choice"), and diffusion ("I was just one small part") all function as immunizing strategies - they reinterpret evidence of wrongdoing in ways that preserve self-image. These aren't unique to Nazis but are general human psychological mechanisms for protecting against unbearable truths.

**Distractor Analysis:**
- **A** (Unique Nazi psychology) - These mechanisms are universal, not unique to Nazis.
- **B** (Normal confession-avoidance) - Too simplistic; the mechanisms involve complex belief maintenance.
- **D** (Legal strategy only) - The defenses had genuine psychological basis; they weren't pure strategy.

**Course Connection:**
- **Film:** Nuremberg - Defendants' defenses
- **Readings:** Boudry & Braeckman (2012) on immunizing strategies
- **Integration:** Applies belief theory to war crimes psychology

---

### Question 4

**Question:** Morse (1992) argues that mens rea (guilty mind) is central to criminal liability. What unique challenge did the Nuremberg trials face regarding criminal intent?

**Answer Choices:**
- A) The defendants lacked intent entirely
- B) War crimes have no mens rea requirement
- C) The defendants acted with intent but within systems that redefined murder as acceptable policy - raising questions about how institutional context shapes individual criminal responsibility ✓
- D) International law ignores psychological considerations

**Correct Answer: C**

**Rationale for Correct Answer:**
Morse's mens rea analysis is complicated at Nuremberg by institutional context. The defendants DID intend their actions - they weren't accidents or unwitting. But they acted within systems that redefined mass murder as policy implementation. This raises questions: Can mens rea be assessed in isolation from institutional context? If the state says killing is legal, does individual intent become less "guilty"? Nuremberg answered that institutional context doesn't eliminate individual responsibility.

**Distractor Analysis:**
- **A** (Lacked intent) - They clearly intended their administrative actions; the issue is the moral framing.
- **B** (No mens rea requirement) - War crimes do require mens rea; the question is how it's assessed.
- **D** (International law ignores psychology) - Nuremberg explicitly engaged with psychological questions.

**Course Connection:**
- **Film:** Nuremberg - Mens rea in institutional context
- **Readings:** Morse (1992) on mens rea
- **Integration:** Applies legal philosophy to international war crimes

---

### Question 5

**Question:** According to Diamond (1961) on criminal responsibility of the mentally ill, what principle would argue AGAINST using "psychological pressure" as a defense for war crimes?

**Answer Choices:**
- A) Mental illness defenses are never valid
- B) Criminal responsibility requires only that the defendant understood the nature of their actions and could have chosen otherwise - ideological commitment does not eliminate this capacity ✓
- C) War creates automatic insanity
- D) Psychology has no relevance to law

**Correct Answer: B**

**Rationale for Correct Answer:**
Diamond's analysis of criminal responsibility requires: (1) understanding the nature of actions and (2) capacity to choose otherwise. The Nuremberg defendants understood what they were doing (organizing deportations, managing camps) and could have chosen otherwise (some Germans refused; some protected victims). Ideological commitment or "pressure" doesn't eliminate cognitive capacity or choice capacity - it influences how that capacity is exercised, but doesn't remove it.

**Distractor Analysis:**
- **A** (Never valid) - Mental illness defenses can be valid; the issue is whether ideology qualifies.
- **C** (War creates insanity) - War doesn't automatically remove criminal responsibility.
- **D** (Psychology irrelevant) - Psychology IS relevant; that's why the defendants tried psychological defenses.

**Course Connection:**
- **Film:** Nuremberg - Psychological pressure defense
- **Readings:** Diamond (1961) on criminal responsibility
- **Integration:** Applies responsibility theory to reject "pressure" defense

---

*Last updated: January 2026*
*For Instructor Use Only*
