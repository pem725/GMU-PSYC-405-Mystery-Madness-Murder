# PSYC 405 Section 001 - Quiz 6: Black Swan
## CONFIDENTIAL ANSWER KEY

---

## Quiz 6: Black Swan (2010) - Part I

---

### Question 1

**Question:** Nina's perfectionism drives her to practice until she bleeds. According to Feldman Barrett et al. (2001), how does her apparent inability to distinguish between productive striving and self-destruction relate to emotion differentiation?

**Answer Choices:**
- A) High differentiation allows her to push through pain signals
- B) Low differentiation prevents her from recognizing when anxiety has crossed into harmful territory, impairing adaptive regulation ✓
- C) Dancers are trained to suppress emotion differentiation
- D) Physical pain and emotional satisfaction are inherently undifferentiated

**Correct Answer: B**

**Rationale for Correct Answer:**
Feldman Barrett et al.'s research on emotion differentiation shows that people who can distinguish between similar emotional states make better self-regulatory decisions. Nina cannot differentiate between productive anxiety (motivating practice) and destructive anxiety (driving self-harm). Her low differentiation means all anxiety feels the same, preventing her from recognizing when she's crossed from healthy striving into pathology. She can't tell when "enough" becomes "too much."

**Distractor Analysis:**
- **A** (High differentiation allows pushing through) - Reverses the relationship. HIGH differentiation would help her recognize when to stop, not continue.
- **C** (Dancers trained to suppress differentiation) - No evidence for this claim. If anything, artistic training might enhance emotional awareness.
- **D** (Pain and satisfaction inherently undifferentiated) - These are distinguishable for most people. Nina's inability to distinguish is pathological, not universal.

**Course Connection:**
- **Film:** Black Swan - Nina's self-destructive perfectionism
- **Readings:** Feldman Barrett et al. (2001) on emotion differentiation
- **Integration:** Applies differentiation research to understand Nina's inability to self-regulate

---

### Question 2

**Question:** Nina's hallucinations escalate throughout the film. According to Kalokerinos et al. (2019), why might low negative emotion differentiation predict more severe symptom progression?

**Answer Choices:**
- A) Undifferentiated emotions are inherently more intense
- B) Low differentiators seek more extreme stimulation
- C) Low differentiators use emotion regulation strategies ineffectively, with all strategies associated with INCREASED rather than decreased negative affect ✓
- D) Differentiation protects against genetic vulnerability to psychosis

**Correct Answer: C**

**Rationale for Correct Answer:**
Kalokerinos et al.'s (2019) key finding is that low differentiators don't just struggle with one regulation strategy - they struggle with ALL strategies. For low differentiators, even typically adaptive strategies like reappraisal are associated with increased negative affect. Nina tries everything: distraction, suppression, situation avoidance - but nothing works because she can't accurately identify what she's feeling. Each failed regulation attempt may contribute to symptom escalation.

**Distractor Analysis:**
- **A** (Undifferentiated emotions more intense) - Not what the research shows. The intensity isn't necessarily higher; the regulation is less effective.
- **B** (Low differentiators seek stimulation) - This describes sensation-seeking, not differentiation. These are separate constructs.
- **D** (Differentiation protects against genetics) - No evidence for gene-environment interaction involving differentiation and psychosis specifically.

**Course Connection:**
- **Film:** Black Swan - Nina's symptom escalation
- **Readings:** Kalokerinos et al. (2019) on differentiation and regulation strategy effectiveness
- **Integration:** Explains why Nina's attempts to cope fail and symptoms worsen

---

### Question 3

**Question:** Erica Sayers (Nina's mother) gave up her ballet career to raise Nina and now lives vicariously through her. Which psychological mechanism best explains how this dynamic contributes to Nina's pathology?

**Answer Choices:**
- A) Genetic transmission of anxiety disorders
- B) Modeling of maladaptive perfectionism
- C) Fusion of identities preventing Nina from developing autonomous purpose and self-regulation ✓
- D) Classical conditioning of dance with punishment

**Correct Answer: C**

**Rationale for Correct Answer:**
Erica's vicarious living through Nina creates a fusion of identities that prevents Nina from developing autonomous purpose. Nina's goals aren't truly hers - they're her mother's goals imposed on her. This lack of self-concordance (Kashdan et al., 2024) means Nina pursues achievement without genuine personal investment, making self-regulation harder because she's regulating for someone else's dream, not her own.

**Distractor Analysis:**
- **A** (Genetic transmission) - While anxiety may have genetic components, this doesn't explain the MECHANISM by which the mother-daughter dynamic contributes.
- **B** (Modeling perfectionism) - Partially relevant, but modeling explains learning patterns, not the deeper identity fusion.
- **D** (Classical conditioning) - Oversimplifies the psychological dynamic. The relationship is about identity, not conditioned associations.

**Course Connection:**
- **Film:** Black Swan - Erica and Nina's enmeshed relationship
- **Readings:** McKnight & Kashdan (2009) on autonomous vs. imposed purpose
- **Integration:** Shows how lack of self-concordant purpose contributes to psychopathology

---

### Question 4

**Question:** Thomas Leroy tells Nina she must "lose herself" to embody the Black Swan. This artistic directive is psychologically dangerous because:

**Answer Choices:**
- A) Method acting always produces mental illness
- B) The Black Swan role is inherently traumatizing
- C) Nina interprets metaphorical instruction literally, believing actual identity dissolution is required rather than emotional access ✓
- D) Directors intentionally destabilize performers

**Correct Answer: C**

**Rationale for Correct Answer:**
Thomas means "lose yourself" metaphorically - access emotions you normally suppress. Nina interprets it literally - actually dissolve your identity. This literalization of metaphor reflects her concrete thinking and poor reality testing. When Thomas says "seduce me," he means perform seduction; Nina considers actually seducing him. Her inability to process figurative artistic language as figurative pushes her toward actual identity dissolution.

**Distractor Analysis:**
- **A** (Method acting always causes illness) - Many actors use method techniques without developing psychosis. It's Nina's interpretation, not the technique itself.
- **B** (Role inherently traumatizing) - The role itself is demanding but not inherently pathogenic. Many dancers perform it without harm.
- **D** (Directors intentionally destabilize) - Thomas may be exploitative, but there's no evidence he intends to cause psychosis.

**Course Connection:**
- **Film:** Black Swan - Thomas's directing of Nina
- **Readings:** Connects to reality testing and literal vs. figurative processing
- **Integration:** Shows how pre-existing psychological vulnerabilities interact with situational demands

---

### Question 5

**Question:** Nina sees her own face on other dancers and in mirrors with distorted features. This symptom most specifically suggests which psychological process?

**Answer Choices:**
- A) Generalized anxiety about competition
- B) Projection of unwanted characteristics onto others
- C) Disturbed self-representation and body image with features of depersonalization ✓
- D) Normal performance anxiety under pressure

**Correct Answer: C**

**Rationale for Correct Answer:**
Nina's visual experiences specifically involve SELF-representation - she sees her own face on others, her reflection transforms, her body morphs. This pattern suggests disturbance in the neural systems that maintain stable self-representation. The term "depersonalization" captures the sense of self becoming unfamiliar or unreal. This goes beyond anxiety or projection to suggest a fundamental disturbance in how she perceives and represents herself.

**Distractor Analysis:**
- **A** (Generalized anxiety) - Anxiety doesn't typically produce these specific visual disturbances of self-perception.
- **B** (Projection) - Projection would involve seeing HER unwanted traits in OTHERS. She sees herself IN others - a different mechanism.
- **D** (Normal performance anxiety) - Hallucinations and visual distortions are not normal aspects of performance anxiety.

**Course Connection:**
- **Film:** Black Swan - Nina's mirror and doppelganger experiences
- **Readings:** Self-representation and depersonalization literature
- **Integration:** Identifies specific psychological mechanisms underlying Nina's symptoms

---

*Last updated: January 2026*
*For Instructor Use Only*
