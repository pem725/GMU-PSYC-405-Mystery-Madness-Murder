# PSYC 405 Section 001 - Quiz 8: Good Will Hunting
## CONFIDENTIAL ANSWER KEY

---

## Quiz 8: Good Will Hunting (1997)

---

### Question 1

**Question:** Will Hunting pushes away everyone who gets close - Skylar, his friends, and initially Sean. According to attachment theory and emotion regulation research (Gross, 2015), which regulatory strategy does this pattern represent?

**Answer Choices:**
- A) Cognitive reappraisal of relationship value
- B) Situation selection that avoids emotional contexts entirely ✓
- C) Expressive suppression of positive emotions
- D) Attentional deployment toward threat cues

**Correct Answer: B**

**Rationale for Correct Answer:**
Will's pattern is consistent with situation selection - he prevents emotionally demanding situations from occurring in the first place. By pushing people away before they get close, he avoids the situation of being vulnerable. This is an antecedent-focused strategy in Gross's model - it operates before the emotional response is fully generated. Will doesn't just suppress emotions that arise; he prevents the situations that would generate them.

**Distractor Analysis:**
- **A** (Reappraisal of relationship value) - Reappraisal would involve changing how he thinks about relationships, not avoiding them entirely.
- **C** (Suppression of positive emotions) - Suppression occurs AFTER emotions arise. Will prevents the relationship situations that would generate emotions.
- **D** (Attentional deployment to threat) - Will doesn't redirect attention within situations; he eliminates the situations entirely.

**Course Connection:**
- **Film:** Good Will Hunting - Will's relationship patterns
- **Readings:** Gross (2015) on situation selection as emotion regulation
- **Integration:** Identifies Will's specific regulatory strategy within the theoretical framework

---

### Question 2

**Question:** Will's foster father burned him with cigarettes, yet Will questions whether he "deserved" the abuse. According to Boudry and Braeckman (2012), why might abuse victims develop self-blaming beliefs despite evidence to the contrary?

**Answer Choices:**
- A) Children lack cognitive capacity to assign blame appropriately
- B) Self-blame provides an illusion of control and predictability
- C) Self-validating belief systems develop where self-blame is more psychologically tolerable than acknowledging complete powerlessness ✓
- D) Abusers explicitly teach victims to accept blame

**Correct Answer: C**

**Rationale for Correct Answer:**
Boudry & Braeckman's framework applies to any self-validating belief. Self-blame for abuse is "self-validating" because it serves psychological functions: if I caused the abuse, then I have some control (I could have prevented it by being "better"). Acknowledging complete powerlessness is more terrifying than accepting undeserved blame. The belief system validates itself by providing an explanatory framework, even if that framework is painful.

**Distractor Analysis:**
- **A** (Children lack cognitive capacity) - Will is an adult still maintaining these beliefs. Cognitive capacity isn't the issue.
- **B** (Illusion of control) - This is partially correct but doesn't capture the SELF-VALIDATING aspect - how the belief resists disconfirmation.
- **D** (Abusers teach blame) - While abusers may do this, the question is about why victims MAINTAIN the belief. The self-validating nature explains persistence.

**Course Connection:**
- **Film:** Good Will Hunting - Will's internalized self-blame
- **Readings:** Boudry & Braeckman (2012) on self-validating beliefs
- **Integration:** Applies belief theory to understand trauma psychology

---

### Question 3

**Question:** Sean shares his own pain with Will (his wife's death, his imperfections). According to research on therapeutic relationships, why does this self-disclosure succeed where previous therapists failed?

**Answer Choices:**
- A) Professional boundaries should always be violated in effective therapy
- B) Shared suffering creates automatic rapport
- C) Will needed to feel superior to his therapist
- D) The disclosure models emotional differentiation - acknowledging multiple simultaneous feelings - and demonstrates that vulnerability does not equal weakness ✓

**Correct Answer: D**

**Rationale for Correct Answer:**
Sean's disclosure serves multiple functions: it MODELS differentiation (he can feel grief AND acceptance, love AND loss simultaneously) and demonstrates that vulnerability doesn't destroy you (Sean is wounded but functional). Will has learned that showing pain means being weak and exploited. Sean's example contradicts this by showing differentiated emotional experience combined with strength. This is more instructive than any cognitive technique.

**Distractor Analysis:**
- **A** (Boundaries should be violated) - Too extreme. The self-disclosure is JUDICIOUS and therapeutic, not a general endorsement of boundary violation.
- **B** (Shared suffering creates rapport) - Superficial. Shared suffering might create connection, but it's the MODELING of differentiation that creates change.
- **C** (Will needed superiority) - Contradicts what happens. Will doesn't feel superior to Sean; he respects him.

**Course Connection:**
- **Film:** Good Will Hunting - Sean's therapeutic approach
- **Readings:** Kashdan et al. (2015) on emotion differentiation; therapeutic relationship research
- **Integration:** Explains successful therapy through modeling of differentiated emotional experience

---

### Question 4

**Question:** Lambeau wants Will to use his mathematical genius for prestigious careers. Will resists, eventually choosing to pursue Skylar to California. According to McKnight et al. (2025), what does this choice suggest about the relationship between purpose and happiness?

**Answer Choices:**
- A) Will sacrifices purpose for happiness
- B) Intellectual purpose is less valid than relational purpose
- C) Happiness (connection with Skylar) may be facilitating his emerging sense of purpose rather than competing with it ✓
- D) Will's choice demonstrates purpose avoidance

**Correct Answer: C**

**Rationale for Correct Answer:**
McKnight et al. (2025) found that happiness predicts subsequent purpose, not vice versa. Will's positive emotional experiences with Skylar and Sean may be creating the conditions for purpose to develop. He's not choosing happiness OVER purpose; he's experiencing happiness that may ENABLE purpose. Following Skylar isn't abandoning purpose - it's pursuing the emotional experiences that facilitate purpose development.

**Distractor Analysis:**
- **A** (Sacrifices purpose for happiness) - Assumes purpose and happiness are in competition. The research suggests happiness facilitates purpose.
- **B** (Relational more valid than intellectual) - The framework doesn't rank purpose types. Will may integrate intellectual purpose later.
- **D** (Purpose avoidance) - Will isn't avoiding purpose; he's pursuing emotional experiences that may enable it.

**Course Connection:**
- **Film:** Good Will Hunting - Will's final choice
- **Readings:** McKnight et al. (2025) on happiness predicting purpose
- **Integration:** Applies recent research to interpret Will's character arc

---

### Question 5

**Question:** Will can solve complex mathematical proofs but cannot solve his own psychological problems. This dissociation illustrates which limitation in the "smart people believe weird things" phenomenon (Shermer, 2002)?

**Answer Choices:**
- A) Mathematical intelligence differs from emotional intelligence
- B) Intellectual sophistication enables rationalization of emotional avoidance, making smart people more effective at constructing defenses ✓
- C) Genius exempts people from normal psychological processes
- D) Will's problems are too complex for anyone to solve

**Correct Answer: B**

**Rationale for Correct Answer:**
Shermer's insight is that intelligence provides better tools for rationalization, not better outcomes. Will's genius allows him to construct sophisticated justifications for his emotional avoidance. When challenged, he can argue circles around therapists. His intelligence doesn't help him overcome his defenses - it strengthens them by providing better defensive arguments. Smart people aren't protected from irrationality; they're better at defending it.

**Distractor Analysis:**
- **A** (Mathematical vs. emotional intelligence) - While this distinction exists, it doesn't capture Shermer's point about rationalization.
- **C** (Genius exempts from psychology) - The opposite - Will is fully subject to psychological processes. His genius doesn't protect him.
- **D** (Problems too complex) - Will's problems are solvable, as the film demonstrates. Complexity isn't the issue.

**Course Connection:**
- **Film:** Good Will Hunting - Will's intellectual defenses
- **Readings:** Shermer (2002) on smart people and irrational beliefs
- **Integration:** Shows how intellectual ability can serve defensive functions

---

*Last updated: January 2026*
*For Instructor Use Only*
