# PSYC 405 Section 001 - Quiz 2: Shutter Island
## CONFIDENTIAL ANSWER KEY

---

## Quiz 2: Shutter Island (2010) - Part I

---

### Question 1

**Question:** Teddy Daniels constructs an elaborate delusional system to avoid confronting his role in his wife's death. According to Gross's (2015) emotion regulation framework, which strategy does this represent?

**Answer Choices:**
- A) Cognitive reappraisal of the traumatic event
- B) Situation modification through complete reality reconstruction ✓
- C) Attentional deployment to alternative stimuli
- D) Response-focused suppression of emotional expression

**Correct Answer: B**

**Rationale for Correct Answer:**
Gross's process model identifies five emotion regulation strategies occurring at different points in the emotion generation sequence. Teddy's delusion represents an extreme form of situation modification - he literally constructs a new psychological situation (being a U.S. Marshal investigating) rather than inhabiting the actual situation (being a patient who killed his wife). This goes beyond cognitive reappraisal because he doesn't just reinterpret events; he creates entirely new events.

**Distractor Analysis:**
- **A** (Cognitive reappraisal) - Reappraisal changes the MEANING of an existing situation. Teddy creates an entirely NEW situation. Reappraisal would be: "I had to do it to end her suffering." Teddy's version is: "It never happened."
- **C** (Attentional deployment) - Merely redirecting attention to different aspects of reality. Teddy constructs an alternative reality entirely.
- **D** (Response-focused suppression) - Suppression operates on emotional expression AFTER emotion is generated. Teddy's strategy operates earlier, preventing the emotion-generating situation from being acknowledged.

**Course Connection:**
- **Film:** Shutter Island (2010) - Teddy/Andrew's elaborate Marshal identity
- **Readings:** Gross (2015) emotion regulation framework - tests whether students can apply the process model to extreme cases
- **Integration:** Requires students to recognize that delusion CAN function as emotion regulation, even though it's maladaptive

---

### Question 2

**Question:** Dr. Cawley's therapeutic approach on Shutter Island involves allowing Teddy to "play out" his delusion. This controversial technique most directly conflicts with which evidence-based principle?

**Answer Choices:**
- A) The therapeutic alliance is essential for treatment outcomes
- B) Patients should be allowed autonomy in treatment decisions
- C) Reinforcing delusional content may strengthen rather than weaken false beliefs ✓
- D) Insight-oriented therapy is superior to behavioral approaches

**Correct Answer: C**

**Rationale for Correct Answer:**
Dr. Cawley's "role-play" approach is ethically and clinically controversial because it risks reinforcing the delusion. Research on delusions (Freeman et al., 2015) suggests that engaging with delusional content without challenging it can strengthen the belief system. By allowing Andrew to fully inhabit the "Teddy" identity, Cawley may be making it harder, not easier, to return to reality.

**Distractor Analysis:**
- **A** (Therapeutic alliance essential) - True in general, but the alliance can exist without role-playing delusions. Cawley maintains alliance throughout.
- **B** (Patient autonomy) - Cawley isn't restricting autonomy; if anything, he's allowing too much autonomy in choosing to inhabit the delusion.
- **D** (Insight vs. behavioral therapy) - This isn't the relevant dimension. The question is about whether engaging with delusions helps or harms.

**Course Connection:**
- **Film:** Shutter Island - Dr. Cawley's experimental therapeutic approach
- **Readings:** Connects to research on delusion treatment and belief change
- **Integration:** Challenges students to evaluate a fictional therapeutic approach against actual clinical evidence

---

### Question 3

**Question:** When Teddy experiences flashbacks to the Dachau liberation, these intrusive memories demonstrate which characteristic that distinguishes trauma-related intrusions from ordinary memories?

**Answer Choices:**
- A) They are stored in explicit declarative memory systems
- B) They have a "here and now" quality with reduced temporal context ✓
- C) They are easily integrated into autobiographical narrative
- D) They require conscious effort to retrieve

**Correct Answer: B**

**Rationale for Correct Answer:**
Trauma memories differ from ordinary autobiographical memories in their phenomenology. They are experienced as happening NOW rather than as past events. Brewin's dual-representation theory and van der Kolk's work on trauma describe this "timeless" quality - the memory lacks temporal context, creating the experience of reliving rather than remembering. This is why Teddy experiences the Dachau memories as intrusions rather than recalled narratives.

**Distractor Analysis:**
- **A** (Explicit declarative memory) - Trauma memories often have significant IMPLICIT/sensory components. They're not purely declarative.
- **C** (Easily integrated into narrative) - The OPPOSITE is true. Trauma memories are fragmented and resist narrative integration - this is part of what makes them traumatic.
- **D** (Require conscious effort) - Intrusive trauma memories are definitionally INVOLUNTARY. They appear without conscious retrieval.

**Course Connection:**
- **Film:** Shutter Island - Teddy's Dachau flashbacks
- **Readings:** Trauma memory research, emotion regulation following trauma
- **Integration:** Applies memory science to understand how the film portrays trauma - testing whether the portrayal matches research

---

### Question 4

**Question:** The film presents two possible "realities" - Teddy as U.S. Marshal or Andrew as patient. According to research on belief perseverance (Boudry & Braeckman, 2012), what makes the Marshal identity so resistant to disconfirmation?

**Answer Choices:**
- A) The identity was formed before the traumatic event
- B) External validators (Chuck/Dr. Sheehan) reinforce the belief
- C) The belief system includes built-in explanations for contradictory evidence (conspiracy theories) ✓
- D) Delusional identities are inherently more stable than accurate self-concepts

**Correct Answer: C**

**Rationale for Correct Answer:**
The Marshal identity persists because it's a self-validating belief system with what Boudry & Braeckman call "immunizing strategies." When Teddy encounters evidence that he's a patient (his real name on the gate, staff calling him "Andrew"), the belief system reinterprets this as PART OF THE CONSPIRACY. The more evidence against him, the bigger the conspiracy must be. This is the hallmark of self-validating beliefs - contradictory evidence strengthens rather than weakens the core belief.

**Distractor Analysis:**
- **A** (Formed before trauma) - The Marshal identity was constructed AFTER the trauma as a defensive mechanism. Timeline is wrong.
- **B** (Chuck reinforces belief) - Actually, Chuck/Dr. Sheehan is trying to CHALLENGE the belief through the role-play. He's not reinforcing it.
- **D** (Delusional identities inherently stable) - No evidence for inherent stability. Stability comes from the immunizing strategies, not from delusion per se.

**Course Connection:**
- **Film:** Shutter Island - Teddy's conspiracy theory framework
- **Readings:** Boudry & Braeckman (2012) on self-validating beliefs and immunizing strategies
- **Integration:** The film provides a vivid illustration of how immunizing strategies work in practice

---

### Question 5

**Question:** Teddy's inability to accurately recall key details while simultaneously constructing elaborate false narratives illustrates which dissociation between memory systems?

**Answer Choices:**
- A) Semantic memory preserved while procedural memory is impaired
- B) Working memory intact while long-term consolidation fails
- C) Reconstructive memory processes operating on fragmented episodic traces ✓
- D) Implicit memory guiding behavior while explicit recall is absent

**Correct Answer: C**

**Rationale for Correct Answer:**
Teddy demonstrates the reconstructive nature of memory - his mind takes fragmentary true elements (he was at Dachau, his wife died, there was water) and reconstructs them into coherent but false narratives. This reflects research showing memory isn't like a video recording but an active reconstruction that can combine true elements into false configurations. The fragmented episodic traces (actual memories) are woven into a coherent but fictional story (the Marshal investigation).

**Distractor Analysis:**
- **A** (Semantic preserved, procedural impaired) - Wrong memory systems entirely. The issue is episodic/autobiographical memory, not semantic or procedural.
- **B** (Working memory intact, consolidation fails) - Doesn't explain confabulation. Failed consolidation would produce amnesia, not false memories.
- **D** (Implicit guides, explicit absent) - Partially relevant but doesn't capture the RECONSTRUCTION process. This answer describes a dissociation but not the active construction of false memories.

**Course Connection:**
- **Film:** Shutter Island - Teddy's elaborate but false memory narratives
- **Readings:** Memory reconstruction research, false memory science
- **Integration:** Applies memory science to explain HOW Teddy creates convincing false memories from true fragments

---

*Last updated: January 2026*
*For Instructor Use Only*
