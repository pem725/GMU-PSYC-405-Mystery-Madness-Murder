# PSYC 405 Section 002 - Quiz 8: K-PAX
## CONFIDENTIAL ANSWER KEY

---

## Quiz 8: K-PAX (2001)

---

### Question 1

**Question:** The film deliberately maintains ambiguity about whether Prot is an alien or a man with trauma-induced delusion. According to Shermer (2002), why might viewers PREFER the alien explanation despite its implausibility?

**Answer Choices:**
- A) Alien explanations are scientifically more defensible
- B) Viewers are unintelligent
- C) The alien explanation is more emotionally satisfying and cognitively simpler than the complex trauma narrative - characteristics that make beliefs "sticky" ✓
- D) Psychiatric explanations are always wrong

**Correct Answer: C**

**Rationale for Correct Answer:**
Shermer describes how "sticky" beliefs appeal to emotion and provide cognitive simplicity. The alien explanation: (1) is emotionally satisfying (magic is more fun than mental illness), (2) is cognitively simpler (he's from K-PAX, end of story, vs. complex trauma history), and (3) fits narrative expectations (sci-fi is a recognized genre). The trauma explanation is more likely but less emotionally and cognitively appealing.

**Distractor Analysis:**
- **A** (Aliens more defensible) - Scientifically, the simpler explanation (delusion) is more defensible.
- **B** (Viewers unintelligent) - The appeal isn't about intelligence; it's about cognitive features.
- **D** (Psychiatric explanations wrong) - Psychiatric explanations have strong scientific support.

**Course Connection:**
- **Film:** K-PAX - viewer preference for alien explanation
- **Readings:** Shermer (2002) on "sticky" beliefs
- **Integration:** Applies belief stickiness theory to audience response

---

### Question 2

**Question:** Prot describes K-PAX as a planet without families, laws, or violence. According to research on belief systems (Boudry & Braeckman, 2012), what psychological function might this utopian vision serve?

**Answer Choices:**
- A) Accurate memory of alien society
- B) Random confabulation without meaning
- C) A self-validating alternative reality that provides escape from the trauma of his actual life - the "K-PAX" belief immunizes against unbearable earthly truths ✓
- D) Deliberate deception of the psychiatrist

**Correct Answer: C**

**Rationale for Correct Answer:**
If Robert Porter's family was murdered (the trauma hypothesis), then K-PAX as a concept serves psychological protection. The K-PAX identity allows him to: (1) escape the pain of his actual history, (2) explain his disconnection from human relationships, (3) provide meaning for his existence. The belief is self-validating because any evidence against it can be dismissed ("you humans wouldn't understand"). It immunizes against the trauma he can't face.

**Distractor Analysis:**
- **A** (Accurate memory) - Within the film's ambiguity, this can't be confirmed; psychologically, the protective function is more relevant.
- **B** (Random confabulation) - The K-PAX details are too coherent and functionally meaningful to be random.
- **D** (Deliberate deception) - If Prot genuinely believes he's from K-PAX, he's not deliberately deceiving.

**Course Connection:**
- **Film:** K-PAX - Prot's K-PAX descriptions
- **Readings:** Boudry & Braeckman (2012) on protective belief systems
- **Integration:** Applies self-validating belief theory to understand Prot's psychology

---

### Question 3

**Question:** The other psychiatric patients improve when interacting with Prot. According to emotion research (Gross, 2015), what mechanism might explain this effect?

**Answer Choices:**
- A) Prot has supernatural healing powers
- B) Mental illness spontaneously remits
- C) Prot provides a form of cognitive reappraisal - his alternative perspective helps patients reinterpret their situations, and his apparent belief models hope ✓
- D) The patients are faking improvement

**Correct Answer: C**

**Rationale for Correct Answer:**
Gross identifies cognitive reappraisal as an effective emotion regulation strategy. Prot offers patients alternative frameworks for understanding their situations: the depressed patient sees new possibilities, the anxious patient gains perspective, the isolated patient feels connection. Prot's certainty about K-PAX, regardless of its truth, models hope and conviction that patients can borrow. He provides reappraisal resources they lacked.

**Distractor Analysis:**
- **A** (Supernatural powers) - Even if Prot were alien, the mechanism would still be psychological, not supernatural.
- **B** (Spontaneous remission) - The improvements are too synchronized with Prot's presence to be random remission.
- **D** (Faking improvement) - The improvements appear genuine within the film's narrative.

**Course Connection:**
- **Film:** K-PAX - Other patients' improvement
- **Readings:** Gross (2015) on cognitive reappraisal
- **Integration:** Applies regulation theory to therapeutic effects

---

### Question 4

**Question:** Dr. Powell eventually uncovers evidence that "Prot" may be Robert Porter, a man whose family was murdered. According to Kalokerinos et al. (2019), how might trauma contribute to identity fragmentation?

**Answer Choices:**
- A) All trauma survivors develop alternate identities
- B) Trauma has no effect on identity
- C) Low negative emotion differentiation following trauma may make adaptive processing impossible, leading to maladaptive strategies including dissociation and identity transformation ✓
- D) Only childhood trauma affects identity

**Correct Answer: C**

**Rationale for Correct Answer:**
Kalokerinos et al.'s research on differentiation and regulation suggests a pathway: when overwhelming trauma produces undifferentiated negative affect, adaptive regulation strategies fail (all strategies increase rather than decrease distress). Identity fragmentation or transformation may emerge as a last-resort mechanism - create a new identity that isn't experiencing the trauma. "Prot" may be Robert Porter's solution when Robert Porter's emotions became unprocessable.

**Distractor Analysis:**
- **A** (All trauma survivors fragment) - Most trauma survivors don't develop alternate identities; this is extreme.
- **B** (No effect on identity) - Trauma clearly can affect identity construction and stability.
- **D** (Only childhood trauma) - Adult trauma (like family murder) can also produce identity effects.

**Course Connection:**
- **Film:** K-PAX - Robert Porter/Prot identity question
- **Readings:** Kalokerinos et al. (2019) on differentiation and trauma
- **Integration:** Uses differentiation research to explain identity fragmentation

---

### Question 5

**Question:** Prot claims he will return to K-PAX at a specific time, and another patient disappears at that moment. The film does not resolve whether this is coincidence, suggestion, or proof of alien nature. According to Matthews (2005), what does this ambiguity illustrate about "rational" belief?

**Answer Choices:**
- A) The audience should conclude Prot is definitely an alien
- B) The audience should conclude Prot is definitely human
- C) Given ambiguous evidence, multiple interpretations can be rationally defended; "irrationality" often reflects different prior beliefs rather than cognitive defects ✓
- D) The film's ambiguity is a narrative flaw

**Correct Answer: C**

**Rationale for Correct Answer:**
Matthews' framework for "rational inference from weird evidence" applies: given the ambiguous evidence (Prot's knowledge, the patient's disappearance, the timing), multiple interpretations are rationally defensible. Those who start with "aliens don't exist" priors will interpret differently than those with non-zero alien priors. The film demonstrates that "rationality" depends on prior beliefs; two people can reach different conclusions, both reasoning validly from different starting points.

**Distractor Analysis:**
- **A** (Definitely alien) - The evidence is deliberately ambiguous; certain conclusion isn't supported.
- **B** (Definitely human) - Equally, certain human conclusion isn't forced by the evidence.
- **D** (Narrative flaw) - The ambiguity is intentional and serves the film's themes about certainty and belief.

**Course Connection:**
- **Film:** K-PAX - Deliberate ambiguous ending
- **Readings:** Matthews (2005) on rational inference
- **Integration:** Uses film's ambiguity to illustrate how prior beliefs affect conclusions

---

*Last updated: January 2026*
*For Instructor Use Only*
