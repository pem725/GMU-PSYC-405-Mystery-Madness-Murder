# PSYC 405 Section 002 - Quiz 11: Nuremberg / Wind River
## CONFIDENTIAL ANSWER KEY

---

## Quiz 11: Transition - Justice and Injustice

---

### Question 1

**Question:** Nuremberg addressed systematic state-sponsored violence; Wind River addresses violence against marginalized communities that falls through jurisdictional cracks. According to Pratto et al. (1994), what do both cases reveal about social dominance?

**Answer Choices:**
- A) Violence is equally distributed across social groups
- B) Only states commit violence
- C) Both represent hierarchy-maintaining patterns - whether through active state violence or through neglect of violence against low-status groups ✓
- D) SDO is irrelevant to violence against marginalized groups

**Correct Answer: C**

**Rationale for Correct Answer:**
Pratto et al.'s SDO theory predicts that violence follows hierarchical patterns. Nuremberg shows active state violence against designated "inferior" groups. Wind River shows passive neglect - violence against Indigenous women isn't prevented, investigated, or punished. Both maintain hierarchy: one through commission, one through omission. High-status groups are protected; low-status groups are victimized or neglected. Different mechanisms, same hierarchical outcome.

**Distractor Analysis:**
- **A** (Equally distributed) - Both films show violence concentrated against low-status groups.
- **B** (Only states) - Wind River shows non-state violence that the state fails to address.
- **D** (SDO irrelevant) - SDO directly predicts differential treatment by status.

**Course Connection:**
- **Film:** Nuremberg and Wind River - different manifestations of hierarchy
- **Readings:** Pratto et al. (1994) on SDO and violence
- **Integration:** Shows how SDO explains both active and passive hierarchy maintenance

---

### Question 2

**Question:** The Nuremberg defendants claimed they were following a legitimate government's orders. Violence on reservations often involves perpetrators who face no consequences due to jurisdictional confusion. According to research on belief (Matthews, 2005), what common factor enables both situations?

**Answer Choices:**
- A) Criminal personality traits
- B) Deliberate evil intent
- C) Systems that allow individuals to diffuse responsibility create conditions where violence becomes "no one's fault" - whether through hierarchy or through jurisdictional gaps ✓
- D) Random chance

**Correct Answer: C**

**Rationale for Correct Answer:**
Matthews' analysis of reasoning under uncertainty extends to moral responsibility. Both cases involve systems that allow responsibility diffusion. At Nuremberg: "I was following orders; someone above me made the decision." On reservations: "It's not my jurisdiction; someone else should handle it." In both cases, the system creates gaps where violence can occur without anyone bearing clear responsibility. The violence becomes systemic, not attributed to individuals.

**Distractor Analysis:**
- **A** (Criminal personality) - The perpetrators aren't unusually criminal; the systems enable normal people.
- **B** (Evil intent) - Individual evil intent isn't required when systems enable violence.
- **D** (Random chance) - The patterns are systematic, not random.

**Course Connection:**
- **Film:** Nuremberg and Wind River - responsibility diffusion
- **Readings:** Matthews (2005) on reasoning and responsibility
- **Integration:** Identifies common mechanism across very different contexts

---

### Question 3

**Question:** Both films involve investigators seeking truth against institutional resistance. According to Vrij et al. (2019), what does research suggest about deception in institutional contexts?

**Answer Choices:**
- A) Institutions cannot deceive
- B) Only individuals lie; institutions are truthful
- C) Institutional deception often involves withholding and misdirection rather than active lying - making traditional "lie detection" approaches inadequate ✓
- D) Investigators always succeed against institutional resistance

**Correct Answer: C**

**Rationale for Correct Answer:**
Vrij et al.'s research focuses on individual deception cues, but institutional deception operates differently. Institutions deceive through omission (not collecting data), misdirection (focusing on wrong questions), and bureaucratic obstruction (making information hard to access). These don't produce the individual behavioral cues that lie detection research examines. Investigators in both films face institutional resistance that can't be detected through traditional cue-based methods.

**Distractor Analysis:**
- **A** (Institutions can't deceive) - Both films show institutional deception clearly.
- **B** (Only individuals lie) - Institutions can lie through their representatives and systems.
- **D** (Investigators always succeed) - Success requires overcoming institutional resistance, which isn't guaranteed.

**Course Connection:**
- **Film:** Nuremberg and Wind River - institutional deception
- **Readings:** Vrij et al. (2019) extended to institutional contexts
- **Integration:** Shows limitations of individual-focused deception research

---

### Question 4

**Question:** Nuremberg established international human rights law; Wind River depicts how domestic law fails to protect Indigenous women. According to Diamantis (2015) on corporate criminal minds, what parallel exists?

**Answer Choices:**
- A) Corporations and governments are identical
- B) Only individuals can commit crimes
- C) Both cases raise questions about how systems (governments, corporations) can possess criminal intent - and how individuals within systems can escape responsibility for systemic harm ✓
- D) Legal systems always succeed at assigning responsibility

**Correct Answer: C**

**Rationale for Correct Answer:**
Diamantis asks whether corporations can have "criminal minds" - can a system possess mens rea? The same question applies: Can a government have criminal intent? Can a jurisdictional system be criminally negligent? Both films show harm caused by systems, not just individuals. Nuremberg tried to hold individuals responsible for systemic harm; Wind River shows how systemic failures prevent any individual accountability. The legal challenge is attributing responsibility when harm is systemic.

**Distractor Analysis:**
- **A** (Corporations = governments) - They differ but face similar legal-philosophical questions.
- **B** (Only individuals) - Systems can cause harm beyond individual actions.
- **D** (Legal systems always succeed) - Wind River shows failure to assign responsibility.

**Course Connection:**
- **Film:** Nuremberg and Wind River - systemic responsibility
- **Readings:** Diamantis (2015) on corporate mens rea
- **Integration:** Applies corporate law theory to government and systemic failures

---

### Question 5

**Question:** Ben Ferencz (Nuremberg prosecutor) was haunted by what he witnessed. Cory Lambert (Wind River) is driven by his own daughter's death. According to McKnight & Kashdan (2009), how does trauma relate to purpose in these characters?

**Answer Choices:**
- A) Trauma always destroys purpose
- B) Purpose requires trauma to develop
- C) Trauma can reorganize purpose systems - directing energy toward preventing similar harm to others while potentially providing meaning from otherwise senseless suffering ✓
- D) Purpose and trauma are unrelated

**Correct Answer: C**

**Rationale for Correct Answer:**
McKnight & Kashdan's self-organizing purpose framework suggests purpose can develop or reorganize around any significant experience, including trauma. Ferencz organized his life around preventing future atrocities; Lambert organized his around protecting others from what happened to his daughter. Neither trauma destroyed nor required purpose, but both reorganized existing purpose systems. Trauma provides something to organize around: preventing recurrence, finding meaning in suffering.

**Distractor Analysis:**
- **A** (Trauma destroys purpose) - Both characters developed stronger, clearer purpose after trauma.
- **B** (Purpose requires trauma) - Purpose can develop without trauma; trauma is one possible catalyst.
- **D** (Unrelated) - The characters clearly demonstrate relationship between trauma and purpose.

**Course Connection:**
- **Film:** Nuremberg and Wind River - investigators' motivations
- **Readings:** McKnight & Kashdan (2009) on purpose reorganization
- **Integration:** Shows how trauma can reorganize purpose systems

---

*Last updated: January 2026*
*For Instructor Use Only*
