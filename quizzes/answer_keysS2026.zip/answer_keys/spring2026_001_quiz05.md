# PSYC 405 Section 001 - Quiz 5: Sunset Boulevard
## CONFIDENTIAL ANSWER KEY

---

## Quiz 5: Sunset Boulevard (1950)

---

### Question 1

**Question:** Norma Desmond maintains her belief that she is still a great star despite overwhelming evidence to the contrary. According to Boudry and Braeckman (2012), which "immunizing strategy" is most evident in her belief system?

**Answer Choices:**
- A) Redefining success criteria to match current status
- B) Reinterpreting contradictory evidence (fan mail, phone calls) as confirmation rather than disconfirmation ✓
- C) Attacking the credibility of critics
- D) Appealing to future vindication

**Correct Answer: B**

**Rationale for Correct Answer:**
Norma's belief system is sustained by reinterpreting evidence. The fake fan mail Max sends becomes "proof" of her enduring stardom. When Cecil B. DeMille's studio calls about using her car (not her), she interprets it as them wanting HER. Every piece of evidence that could disconfirm her star status is reinterpreted as confirmation. This is classic immunizing strategy - the belief system processes information in a way that makes disconfirmation impossible.

**Distractor Analysis:**
- **A** (Redefining success) - Norma doesn't redefine what stardom means; she maintains the original definition and insists she still meets it.
- **C** (Attacking critics) - While Norma dismisses the studio system, she doesn't primarily use attacks on critics as her defense mechanism.
- **D** (Future vindication) - Norma believes she IS still a star NOW, not that she will be vindicated later.

**Course Connection:**
- **Film:** Sunset Boulevard - Norma's delusional stardom
- **Readings:** Boudry & Braeckman (2012) on immunizing strategies
- **Integration:** Norma provides a case study of how self-validating beliefs resist disconfirmation

---

### Question 2

**Question:** Max von Mayerling's devotion to Norma - including writing her fake fan mail - represents which psychological dynamic?

**Answer Choices:**
- A) Stockholm syndrome from prolonged captivity
- B) Codependent enabling that maintains pathological equilibrium
- C) Purpose-driven behavior (McKnight & Kashdan, 2009) where his identity and meaning derive entirely from serving Norma ✓
- D) Instrumental caregiving for financial benefit

**Correct Answer: C**

**Rationale for Correct Answer:**
Max's behavior exemplifies McKnight & Kashdan's concept of purpose as a self-organizing system - but organized around another person rather than autonomous goals. Max's entire identity and meaning derive from serving Norma. This is purpose, but it's externally-located purpose that maintains another's delusion. His fake fan mail, his butler role (despite being her ex-husband and former director), all serve to sustain her and thereby sustain his reason for existing.

**Distractor Analysis:**
- **A** (Stockholm syndrome) - Max isn't a captive; he freely chooses to stay and serve. His devotion is volitional, not coerced.
- **B** (Codependent enabling) - While codependency is present, "purpose-driven behavior" better captures Max's active construction of meaning through service.
- **D** (Instrumental caregiving) - Max isn't financially motivated; he could have wealth and status elsewhere as a former director.

**Course Connection:**
- **Film:** Sunset Boulevard - Max's devotion to Norma
- **Readings:** McKnight & Kashdan (2009) on purpose systems
- **Integration:** Illustrates how purpose can be authentic yet directed toward maintaining another's pathology

---

### Question 3

**Question:** Joe Gillis recognizes Norma's delusions but remains in the mansion. According to emotion differentiation research (Kashdan et al., 2015), what does his inability to leave suggest about his emotional processing?

**Answer Choices:**
- A) High emotion differentiation leading to analysis paralysis
- B) Low emotion differentiation, unable to distinguish between comfort, fear, pity, and self-interest, leading to maladaptive behavior ✓
- C) Successful emotion suppression enabling rational decision-making
- D) Emotional flooding preventing any cognitive evaluation

**Correct Answer: B**

**Rationale for Correct Answer:**
Joe experiences multiple emotions (comfort from luxury, fear of Norma's instability, pity for her situation, self-interest in her money) but cannot differentiate them clearly enough to make adaptive decisions. Kashdan et al.'s research shows that low differentiators struggle to select appropriate responses because they can't identify which specific emotion requires addressing. Joe's paralysis reflects this undifferentiated emotional experience.

**Distractor Analysis:**
- **A** (High differentiation causing paralysis) - High differentiation typically enables better decisions, not paralysis. Analysis paralysis from too much information is different from undifferentiated emotional confusion.
- **C** (Successful suppression) - Joe's decisions are clearly NOT rational; successful suppression would produce better outcomes.
- **D** (Emotional flooding) - Flooding implies overwhelming intensity. Joe seems numb rather than overwhelmed.

**Course Connection:**
- **Film:** Sunset Boulevard - Joe's inability to leave
- **Readings:** Kashdan et al. (2015) on emotion differentiation and decision-making
- **Integration:** Applies differentiation research to explain seemingly irrational character choices

---

### Question 4

**Question:** The film's famous final line - "All right, Mr. DeMille, I'm ready for my close-up" - represents Norma's complete break from reality. Which psychological construct best explains why this delusion provides her relief rather than distress?

**Answer Choices:**
- A) Depersonalization reduces emotional pain
- B) Psychotic states are inherently pleasurable
- C) The delusion resolves cognitive dissonance between her self-concept and reality, eliminating the painful gap ✓
- D) Audience attention activates reward circuits regardless of context

**Correct Answer: C**

**Rationale for Correct Answer:**
Throughout the film, Norma experiences the painful gap between her self-concept (great star) and reality (forgotten relic). Her final delusion eliminates this gap entirely - she IS making her comeback, the cameras ARE rolling for her, she IS descending a staircase for her adoring audience. By fully inhabiting the delusion, she resolves the cognitive dissonance that caused her suffering. The delusion is "successful" emotion regulation, even though it's completely maladaptive.

**Distractor Analysis:**
- **A** (Depersonalization) - Norma doesn't show depersonalization; she's MORE identified with her star persona, not less connected to self.
- **B** (Psychosis inherently pleasurable) - Psychotic states are often terrifying. The pleasure here is specific to the CONTENT of the delusion, not psychosis generally.
- **D** (Audience attention activates reward) - While true, this doesn't explain why DELUSIONAL attention would work the same way.

**Course Connection:**
- **Film:** Sunset Boulevard - Norma's final scene
- **Readings:** Research on cognitive dissonance and delusion function
- **Integration:** Shows how delusion can serve protective psychological functions even when pathological

---

### Question 5

**Question:** Norma's belief system exhibits what Shermer calls "smart person's folly" - the use of sophisticated reasoning to defend irrational beliefs. Which element of her background makes this particularly applicable?

**Answer Choices:**
- A) Her advanced age and cognitive decline
- B) Her isolation from contradictory information
- C) Her genuine past expertise and success, which she uses to construct elaborate justifications for her current status ✓
- D) Her financial resources that insulate her from consequences

**Correct Answer: C**

**Rationale for Correct Answer:**
Shermer's "smart person's folly" applies specifically to people who have genuine expertise and use it to rationalize irrational beliefs. Norma WAS a great star - her knowledge of film, performance, and stardom is real. She uses this expertise to construct elaborate justifications: she understands what stardom SHOULD look like and can explain why silent film was superior, why she's "ready for her return," why the industry has declined. Her expertise makes her rationalizations more sophisticated and harder to challenge.

**Distractor Analysis:**
- **A** (Age and cognitive decline) - No evidence of cognitive decline; Norma is sharp and articulate. Age alone doesn't explain "smart person's folly."
- **B** (Isolation from contradiction) - While true, isolation doesn't explain the sophisticated USE of reasoning to defend beliefs.
- **D** (Financial insulation) - Money protects her from consequences but doesn't explain the cognitive mechanism of rationalization.

**Course Connection:**
- **Film:** Sunset Boulevard - Norma's past as a genuine star
- **Readings:** Shermer (2002) on intelligent people defending irrational beliefs
- **Integration:** Shows how real expertise can be deployed to defend delusion

---

*Last updated: January 2026*
*For Instructor Use Only*
